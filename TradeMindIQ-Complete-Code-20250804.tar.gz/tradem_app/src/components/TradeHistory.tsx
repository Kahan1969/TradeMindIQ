import React, { useEffect, useState, useCallback } from 'react';
import { API_BASE } from '../config';
import { useAuth } from '../contexts/AuthContext';

interface Trade {
  id: number;
  timestamp: string;
  symbol: string;
  side: 'buy' | 'sell';
  quantity: number;
  price: number;
  total: number;
  status: 'filled' | 'pending';
}

const TradeHistory: React.FC = () => {
  const { getAuthHeaders } = useAuth();
  const [trades, setTrades] = useState<Trade[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  const fetchTradeHistory = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const response = await fetch(`${API_BASE}/history`, {
        headers: {
          ...getAuthHeaders()
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setTrades(data.trades || []);
        setLastUpdated(new Date());
      } else {
        // Demo data fallback
        const demoTrades = [
          {
            id: 1,
            timestamp: new Date().toISOString(),
            symbol: 'AAPL',
            side: 'buy' as const,
            quantity: 10,
            price: 170.50,
            total: 1705.00,
            status: 'filled' as const
          },
          {
            id: 2,
            timestamp: new Date(Date.now() - 3600000).toISOString(),
            symbol: 'TSLA',
            side: 'sell' as const,
            quantity: 5,
            price: 245.00,
            total: 1225.00,
            status: 'filled' as const
          }
        ];
        setTrades(demoTrades);
        setLastUpdated(new Date());
        setError('Using demo data - backend not available');
      }
    } catch (err) {
      setError('Unable to fetch trade history. Using demo data.');
      const demoTrades = [
        {
          id: 1,
          timestamp: new Date().toISOString(),
          symbol: 'AAPL',
          side: 'buy' as const,
          quantity: 10,
          price: 170.50,
          total: 1705.00,
          status: 'filled' as const
        }
      ];
      setTrades(demoTrades);
      setLastUpdated(new Date());
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchTradeHistory();
    
    // Set up interval to refresh trade history every 60 seconds
    const interval = setInterval(() => {
      fetchTradeHistory();
    }, 60000);
    
    return () => clearInterval(interval);
  }, [fetchTradeHistory]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const formatDateTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatLastUpdated = (date: Date | null) => {
    if (!date) return '';
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  if (loading) {
    return (
      <div className="p-3 sm:p-4 border rounded shadow bg-white">
        <h2 className="text-lg sm:text-xl font-bold mb-3">📈 Trade History</h2>
        <div className="text-center py-8">
          <p>Loading trade history...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-3 sm:p-4 border rounded shadow bg-white">
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-4 space-y-2 sm:space-y-0">
        <div>
          <h2 className="text-lg sm:text-xl font-bold">📈 Trade History</h2>
          {lastUpdated && (
            <p className="text-xs text-gray-500">
              Last updated: {formatLastUpdated(lastUpdated)}
            </p>
          )}
        </div>
        <button
          onClick={fetchTradeHistory}
          className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded text-sm w-full sm:w-auto"
        >
          Refresh
        </button>
      </div>

      {error && (
        <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded text-sm">
          ❌ {error}
        </div>
      )}

      {/* Trade History Table/Cards */}
      {trades.length > 0 ? (
        <>
          {/* Desktop Table */}
          <div className="hidden sm:block overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-gray-50">
                  <th className="text-left p-2">Date/Time</th>
                  <th className="text-left p-2">Symbol</th>
                  <th className="text-center p-2">Side</th>
                  <th className="text-right p-2">Quantity</th>
                  <th className="text-right p-2">Price</th>
                  <th className="text-right p-2">Total</th>
                  <th className="text-center p-2">Status</th>
                </tr>
              </thead>
              <tbody>
                {trades.map((trade) => (
                  <tr key={trade.id} className="border-b hover:bg-gray-50">
                    <td className="p-2 text-gray-600">{formatDateTime(trade.timestamp)}</td>
                    <td className="p-2 font-medium">{trade.symbol}</td>
                    <td className="p-2 text-center">
                      <span className={`px-2 py-1 rounded text-xs font-medium ${
                        trade.side === 'buy' 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {trade.side.toUpperCase()}
                      </span>
                    </td>
                    <td className="p-2 text-right">{trade.quantity}</td>
                    <td className="p-2 text-right">{formatCurrency(trade.price)}</td>
                    <td className="p-2 text-right font-medium">{formatCurrency(trade.total)}</td>
                    <td className="p-2 text-center">
                      <span className={`px-2 py-1 rounded text-xs font-medium ${
                        trade.status === 'filled' 
                          ? 'bg-blue-100 text-blue-800' 
                          : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {trade.status.toUpperCase()}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile Cards */}
          <div className="sm:hidden space-y-3">
            {trades.map((trade) => (
              <div key={trade.id} className="bg-gray-50 rounded-lg p-3 border">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="font-bold text-lg">{trade.symbol}</h3>
                    <p className="text-sm text-gray-600">{formatDateTime(trade.timestamp)}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">{formatCurrency(trade.total)}</p>
                    <div className="flex gap-1 justify-end mt-1">
                      <span className={`px-2 py-1 rounded text-xs font-medium ${
                        trade.side === 'buy' 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {trade.side.toUpperCase()}
                      </span>
                      <span className={`px-2 py-1 rounded text-xs font-medium ${
                        trade.status === 'filled' 
                          ? 'bg-blue-100 text-blue-800' 
                          : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {trade.status.toUpperCase()}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <span className="text-gray-600">Quantity:</span>
                    <span className="ml-1 font-medium">{trade.quantity}</span>
                  </div>
                  <div>
                    <span className="text-gray-600">Price:</span>
                    <span className="ml-1 font-medium">{formatCurrency(trade.price)}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </>
      ) : (
        <div className="text-center py-8 text-gray-500">
          <p>No trades found</p>
          <p className="text-sm">Start trading to see your history here</p>
        </div>
      )}

      {trades.length > 0 && (
        <div className="mt-4 text-sm text-gray-500 text-center">
          Total trades: {trades.length}
        </div>
      )}
    </div>
  );
};

export default TradeHistory;
