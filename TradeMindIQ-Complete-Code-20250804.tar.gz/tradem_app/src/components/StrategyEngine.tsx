import React, { useState, useEffect, useCallback } from 'react';
import { API_BASE } from '../config';
import { useAuth } from '../contexts/AuthContext';
import { analyzeSentiment, aggregateMarketSentiment, generateTradingSignal } from '../utils/sentimentAnalysis';
import { BacktestEngine } from '../utils/backtestEngine';

interface StrategyConfig {
  type: 'momentum' | 'swing' | 'scalp';
  riskLevel: 'low' | 'medium' | 'high';
  timeframe: '1m' | '5m' | '15m' | '1h' | '4h' | '1d';
  indicators: string[];
  sentimentWeight: number;
  maxPositions: number;
  stopLoss: number;
  takeProfit: number;
}

interface BacktestResult {
  totalReturn: number;
  sharpeRatio: number;
  maxDrawdown: number;
  winRate: number;
  totalTrades: number;
  avgReturn: number;
  startDate: string;
  endDate: string;
  equity: Array<{ date: string; value: number }>;
}

interface TradingSignal {
  symbol: string;
  action: 'buy' | 'sell' | 'hold';
  confidence: number;
  price: number;
  timestamp: string;
  strategy: string;
  reasoning: string;
  sentimentScore: number;
  technicalScore: number;
}

interface NewsItem {
  title: string;
  summary: string;
  sentiment: number;
  relevance: number;
  source: string;
  timestamp: string;
  category?: string;
  confidence?: number;
}

const StrategyEngine: React.FC = () => {
  const { getAuthHeaders } = useAuth();
  
  const [activeStrategy, setActiveStrategy] = useState<StrategyConfig>({
    type: 'momentum',
    riskLevel: 'medium',
    timeframe: '1h',
    indicators: ['EMA', 'RSI', 'MACD'],
    sentimentWeight: 0.3,
    maxPositions: 5,
    stopLoss: 5,
    takeProfit: 10
  });

  const [signals, setSignals] = useState<TradingSignal[]>([]);
  const [backtestResults, setBacktestResults] = useState<BacktestResult | null>(null);
  const [news, setNews] = useState<NewsItem[]>([]);
  const [isBacktesting, setIsBacktesting] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  // Strategy type configurations
  const strategyTypes = {
    momentum: {
      name: 'Momentum Trading',
      description: 'Capitalizes on strong price movements and trending markets',
      defaultTimeframes: ['5m', '15m', '1h'],
      defaultIndicators: ['EMA', 'RSI', 'MACD', 'Volume'],
      riskProfile: 'medium',
      holdingPeriod: 'Hours to Days'
    },
    swing: {
      name: 'Swing Trading',
      description: 'Captures price swings over several days to weeks',
      defaultTimeframes: ['1h', '4h', '1d'],
      defaultIndicators: ['SMA', 'RSI', 'Bollinger Bands', 'Stochastic'],
      riskProfile: 'low',
      holdingPeriod: 'Days to Weeks'
    },
    scalp: {
      name: 'Scalping',
      description: 'Quick trades for small profits on short timeframes',
      defaultTimeframes: ['1m', '5m'],
      defaultIndicators: ['EMA', 'Volume', 'Order Flow', 'Level II'],
      riskProfile: 'high',
      holdingPeriod: 'Seconds to Minutes'
    }
  };

  const fetchSignals = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const response = await fetch(`${API_BASE}/strategy/signals`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders()
        },
        body: JSON.stringify(activeStrategy)
      });

      if (response.ok) {
        const data = await response.json();
        setSignals(data.signals || []);
        setNews(data.news || []);
      } else {
        // Demo data for signals
        const demoSignals: TradingSignal[] = [
          {
            symbol: 'AAPL',
            action: 'buy',
            confidence: 0.82,
            price: 175.25,
            timestamp: new Date().toISOString(),
            strategy: `${activeStrategy.type}_${activeStrategy.timeframe}`,
            reasoning: 'Strong momentum confirmed by EMA crossover and positive sentiment',
            sentimentScore: 0.7,
            technicalScore: 0.85
          },
          {
            symbol: 'TSLA',
            action: 'sell',
            confidence: 0.75,
            price: 245.80,
            timestamp: new Date(Date.now() - 300000).toISOString(),
            strategy: `${activeStrategy.type}_${activeStrategy.timeframe}`,
            reasoning: 'Overbought conditions with negative news sentiment',
            sentimentScore: -0.4,
            technicalScore: 0.6
          },
          {
            symbol: 'MSFT',
            action: 'hold',
            confidence: 0.65,
            price: 338.50,
            timestamp: new Date(Date.now() - 600000).toISOString(),
            strategy: `${activeStrategy.type}_${activeStrategy.timeframe}`,
            reasoning: 'Mixed signals, waiting for clearer direction',
            sentimentScore: 0.1,
            technicalScore: 0.55
          }
        ];

        const demoNews: NewsItem[] = [
          {
            title: 'Apple Reports Strong Q3 Earnings Beat Expectations',
            summary: 'Apple exceeded expectations with record iPhone sales and services revenue growth',
            sentiment: 0.8,
            relevance: 0.9,
            source: 'MarketWatch',
            timestamp: new Date(Date.now() - 3600000).toISOString()
          },
          {
            title: 'Tesla Faces Production Challenges Due to Supply Chain',
            summary: 'Tesla reports slower than expected Model 3 production due to supply chain issues and regulatory concerns',
            sentiment: -0.5,
            relevance: 0.85,
            source: 'Reuters',
            timestamp: new Date(Date.now() - 7200000).toISOString()
          },
          {
            title: 'Microsoft Azure Growth Continues Strong Momentum',
            summary: 'Cloud services drive Microsoft revenue growth in latest quarter with positive outlook',
            sentiment: 0.6,
            relevance: 0.8,
            source: 'TechCrunch',
            timestamp: new Date(Date.now() - 10800000).toISOString()
          },
          {
            title: 'Federal Reserve Signals Potential Rate Cuts Ahead',
            summary: 'Fed chair indicates dovish stance on monetary policy amid economic uncertainty',
            sentiment: 0.3,
            relevance: 0.95,
            source: 'CNBC',
            timestamp: new Date(Date.now() - 14400000).toISOString()
          },
          {
            title: 'NVIDIA AI Chip Demand Surges Beyond Expectations',
            summary: 'NVIDIA reports unprecedented demand for AI chips with strong guidance for next quarter',
            sentiment: 0.9,
            relevance: 0.88,
            source: 'Bloomberg',
            timestamp: new Date(Date.now() - 18000000).toISOString()
          }
        ];

        // Enhance news with sentiment analysis
        const enhancedNews = demoNews.map(item => {
          const analysis = analyzeSentiment(item.title + ' ' + item.summary);
          return {
            ...item,
            sentiment: analysis.score,
            category: analysis.category,
            confidence: analysis.confidence
          };
        });

        // Generate enhanced trading signals using sentiment
        const enhancedSignals = demoSignals.map(signal => {
          const relevantNews = enhancedNews.filter(news => 
            news.title.toLowerCase().includes(signal.symbol.toLowerCase()) ||
            (signal.symbol === 'AAPL' && news.title.toLowerCase().includes('apple')) ||
            (signal.symbol === 'TSLA' && news.title.toLowerCase().includes('tesla')) ||
            (signal.symbol === 'MSFT' && news.title.toLowerCase().includes('microsoft'))
          );

          const marketSentiment = aggregateMarketSentiment(relevantNews.map(news => ({
            score: news.sentiment,
            magnitude: news.relevance,
            confidence: news.confidence || 0.8,
            keywords: [],
            category: news.category || 'market'
          })));

          const enhancedSignal = generateTradingSignal({
            technicalScore: signal.technicalScore,
            sentimentScore: marketSentiment.overall,
            sentimentWeight: activeStrategy.sentimentWeight,
            price: signal.price,
            volume: Math.random() * 2000000 + 500000,
            volatility: Math.random() * 0.3 + 0.1
          });

          return {
            ...signal,
            action: enhancedSignal.action,
            confidence: enhancedSignal.confidence,
            reasoning: enhancedSignal.reasoning,
            sentimentScore: marketSentiment.overall
          };
        });

        setSignals(enhancedSignals);
        setNews(enhancedNews);
        setError('Using demo data - strategy engine not connected to live feeds');
      }
      setLastUpdated(new Date());
    } catch (err) {
      setError('Failed to fetch strategy signals');
      console.error('Strategy fetch error:', err);
    } finally {
      setLoading(false);
    }
  }, [activeStrategy]);

  const runBacktest = useCallback(async (startDate: string, endDate: string) => {
    setIsBacktesting(true);
    setError('');
    try {
      const response = await fetch(`${API_BASE}/strategy/backtest`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders()
        },
        body: JSON.stringify({
          strategy: activeStrategy,
          startDate,
          endDate
        })
      });

      if (response.ok) {
        const data = await response.json();
        setBacktestResults(data);
      } else {
        // Generate comprehensive demo backtest using BacktestEngine
        const backtestEngine = new BacktestEngine({
          startDate,
          endDate,
          initialCapital: 10000,
          commissionRate: 0.1, // 0.1% commission
          slippageRate: 0.05, // 0.05% slippage
          maxPositions: activeStrategy.maxPositions,
          riskPerTrade: 2 // 2% risk per trade
        });

        // Generate demo historical data
        const historicalData = generateDemoHistoricalData(startDate, endDate);
        
        // Generate demo signals based on strategy
        const demoSignals = generateDemoSignals(historicalData, activeStrategy);
        
        // Run the backtest
        const backtestResult = await backtestEngine.runBacktest(historicalData, demoSignals);
        
        // Convert to expected format
        const formattedResults: BacktestResult = {
          totalReturn: backtestResult.metrics.totalReturn,
          sharpeRatio: backtestResult.metrics.sharpeRatio,
          maxDrawdown: backtestResult.metrics.maxDrawdown,
          winRate: backtestResult.metrics.winRate,
          totalTrades: backtestResult.metrics.totalTrades,
          avgReturn: backtestResult.metrics.avgWin,
          startDate,
          endDate,
          equity: backtestResult.equity.map(e => ({ date: e.date, value: e.equity }))
        };
        
        setBacktestResults(formattedResults);
        setError('Using advanced demo backtest engine - strategy engine not connected to historical data');
      }
    } catch (err) {
      setError('Failed to run backtest');
      console.error('Backtest error:', err);
    } finally {
      setIsBacktesting(false);
    }
  }, [activeStrategy, getAuthHeaders]);

  const generateEquityCurve = (startDate: string, endDate: string, totalReturn: number): Array<{ date: string; value: number }> => {
    const start = new Date(startDate);
    const end = new Date(endDate);
    const days = Math.floor((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
    const curve = [];
    
    let currentValue = 10000; // Starting capital
    const dailyReturn = Math.pow(1 + totalReturn / 100, 1 / days) - 1;
    
    for (let i = 0; i <= days; i += Math.ceil(days / 50)) {
      const date = new Date(start);
      date.setDate(date.getDate() + i);
      
      // Add some volatility
      const volatility = (Math.random() - 0.5) * 0.02;
      currentValue *= (1 + dailyReturn + volatility);
      
      curve.push({
        date: date.toISOString().split('T')[0],
        value: Math.round(currentValue)
      });
    }
    
    return curve;
  };

  const generateDemoHistoricalData = (startDate: string, endDate: string) => {
    const data: Array<{
      date: string;
      symbol: string;
      open: number;
      high: number;
      low: number;
      close: number;
      volume: number;
    }> = [];

    const symbols = ['AAPL', 'TSLA', 'MSFT', 'GOOGL', 'NVDA'];
    const start = new Date(startDate);
    const end = new Date(endDate);
    const days = Math.floor((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));

    symbols.forEach(symbol => {
      let basePrice = symbol === 'AAPL' ? 170 : symbol === 'TSLA' ? 250 : symbol === 'MSFT' ? 340 : symbol === 'GOOGL' ? 140 : 450;
      
      for (let i = 0; i <= days; i++) {
        const date = new Date(start);
        date.setDate(date.getDate() + i);
        
        const volatility = 0.02;
        const trend = Math.sin(i * 0.1) * 0.005;
        const random = (Math.random() - 0.5) * volatility;
        
        const open = basePrice;
        const changePercent = trend + random;
        const high = open * (1 + Math.abs(changePercent) + Math.random() * 0.01);
        const low = open * (1 - Math.abs(changePercent) - Math.random() * 0.01);
        const close = open * (1 + changePercent);
        
        data.push({
          date: date.toISOString().split('T')[0],
          symbol,
          open: Number(open.toFixed(2)),
          high: Number(high.toFixed(2)),
          low: Number(low.toFixed(2)),
          close: Number(close.toFixed(2)),
          volume: Math.floor(Math.random() * 5000000) + 1000000
        });
        
        basePrice = close;
      }
    });

    return data;
  };

  const generateDemoSignals = (historicalData: any[], strategy: StrategyConfig) => {
    const signals: Array<{
      date: string;
      symbol: string;
      action: 'buy' | 'sell' | 'hold';
      confidence: number;
      price: number;
    }> = [];

    const symbols = ['AAPL', 'TSLA', 'MSFT', 'GOOGL', 'NVDA'];
    const dataBySymbol = historicalData.reduce((acc, item) => {
      if (!acc[item.symbol]) acc[item.symbol] = [];
      acc[item.symbol].push(item);
      return acc;
    }, {});

    symbols.forEach(symbol => {
      const symbolData = dataBySymbol[symbol] || [];
      
      for (let i = 20; i < symbolData.length; i += 5) { // Generate signals every 5 days
        const currentData = symbolData[i];
        const pastData = symbolData.slice(Math.max(0, i - 20), i);
        
        // Simple momentum strategy
        const recentPrices = pastData.slice(-10).map((d: any) => d.close);
        const olderPrices = pastData.slice(-20, -10).map((d: any) => d.close);
        
        const recentAvg = recentPrices.reduce((sum: number, p: number) => sum + p, 0) / recentPrices.length;
        const olderAvg = olderPrices.reduce((sum: number, p: number) => sum + p, 0) / olderPrices.length;
        
        const momentum = (recentAvg - olderAvg) / olderAvg;
        const volatility = Math.sqrt(recentPrices.reduce((sum: number, p: number) => sum + Math.pow(p - recentAvg, 2), 0) / recentPrices.length) / recentAvg;
        
        let action: 'buy' | 'sell' | 'hold' = 'hold';
        let confidence = 0.5;
        
        // Strategy-specific logic
        if (strategy.type === 'momentum') {
          if (momentum > 0.03) {
            action = 'buy';
            confidence = Math.min(0.9, 0.6 + momentum * 10);
          } else if (momentum < -0.03) {
            action = 'sell';
            confidence = Math.min(0.9, 0.6 + Math.abs(momentum) * 10);
          }
        } else if (strategy.type === 'swing') {
          // Mean reversion for swing strategy
          if (momentum < -0.05) {
            action = 'buy';
            confidence = Math.min(0.8, 0.5 + Math.abs(momentum) * 8);
          } else if (momentum > 0.05) {
            action = 'sell';
            confidence = Math.min(0.8, 0.5 + momentum * 8);
          }
        } else if (strategy.type === 'scalp') {
          // Quick trades based on short-term movements
          const shortMomentum = (currentData.close - pastData[pastData.length - 2].close) / pastData[pastData.length - 2].close;
          if (Math.abs(shortMomentum) > 0.01) {
            action = shortMomentum > 0 ? 'buy' : 'sell';
            confidence = Math.min(0.7, 0.5 + Math.abs(shortMomentum) * 20);
          }
        }
        
        // Adjust confidence based on volatility
        confidence *= Math.max(0.5, 1 - volatility);
        
        if (action !== 'hold') {
          signals.push({
            date: currentData.date,
            symbol,
            action,
            confidence,
            price: currentData.close
          });
        }
      }
    });

    return signals;
  };

  useEffect(() => {
    fetchSignals();
    const interval = setInterval(fetchSignals, 60000); // Update every minute
    return () => clearInterval(interval);
  }, [fetchSignals]);

  const updateStrategy = (updates: Partial<StrategyConfig>) => {
    setActiveStrategy(prev => ({ ...prev, ...updates }));
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const formatPercentage = (percentage: number) => {
    return `${percentage >= 0 ? '+' : ''}${percentage.toFixed(2)}%`;
  };

  const formatDateTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getSentimentColor = (sentiment: number) => {
    if (sentiment > 0.3) return 'text-green-600';
    if (sentiment < -0.3) return 'text-red-600';
    return 'text-gray-600';
  };

  const getSentimentLabel = (sentiment: number) => {
    if (sentiment > 0.5) return 'Very Positive';
    if (sentiment > 0.2) return 'Positive';
    if (sentiment > -0.2) return 'Neutral';
    if (sentiment > -0.5) return 'Negative';
    return 'Very Negative';
  };

  return (
    <div className="p-3 sm:p-4 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-2 sm:space-y-0">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-gray-800">🤖 AI Strategy Engine</h1>
          <p className="text-sm text-gray-600">Advanced algorithmic trading with sentiment analysis</p>
          {lastUpdated && (
            <p className="text-xs text-gray-500">
              Last updated: {formatDateTime(lastUpdated.toISOString())}
            </p>
          )}
        </div>
        <button
          onClick={fetchSignals}
          disabled={loading}
          className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white px-4 py-2 rounded text-sm"
        >
          {loading ? 'Updating...' : 'Refresh Signals'}
        </button>
      </div>

      {error && (
        <div className="p-3 bg-yellow-100 border border-yellow-400 text-yellow-800 rounded text-sm">
          ⚠️ {error}
        </div>
      )}

      {/* Strategy Configuration */}
      <div className="bg-white border rounded-lg p-4 shadow-sm">
        <h2 className="text-lg font-semibold mb-4">Strategy Configuration</h2>
        
        {/* Strategy Type Selection */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
          {Object.entries(strategyTypes).map(([key, strategy]) => (
            <div
              key={key}
              className={`p-4 border rounded-lg cursor-pointer transition-all ${
                activeStrategy.type === key
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
              onClick={() => updateStrategy({ type: key as any })}
            >
              <h3 className="font-semibold text-sm">{strategy.name}</h3>
              <p className="text-xs text-gray-600 mt-1">{strategy.description}</p>
              <div className="mt-2 space-y-1">
                <div className="text-xs text-gray-500">
                  <span className="font-medium">Risk:</span> {strategy.riskProfile}
                </div>
                <div className="text-xs text-gray-500">
                  <span className="font-medium">Period:</span> {strategy.holdingPeriod}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Strategy Parameters */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Risk Level</label>
            <select
              value={activeStrategy.riskLevel}
              onChange={(e) => updateStrategy({ riskLevel: e.target.value as any })}
              className="w-full p-2 border rounded text-sm"
            >
              <option value="low">Low Risk</option>
              <option value="medium">Medium Risk</option>
              <option value="high">High Risk</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Timeframe</label>
            <select
              value={activeStrategy.timeframe}
              onChange={(e) => updateStrategy({ timeframe: e.target.value as any })}
              className="w-full p-2 border rounded text-sm"
            >
              <option value="1m">1 Minute</option>
              <option value="5m">5 Minutes</option>
              <option value="15m">15 Minutes</option>
              <option value="1h">1 Hour</option>
              <option value="4h">4 Hours</option>
              <option value="1d">1 Day</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Sentiment Weight</label>
            <input
              type="range"
              min="0"
              max="1"
              step="0.1"
              value={activeStrategy.sentimentWeight}
              onChange={(e) => updateStrategy({ sentimentWeight: parseFloat(e.target.value) })}
              className="w-full"
            />
            <div className="text-xs text-gray-500 mt-1">
              {Math.round(activeStrategy.sentimentWeight * 100)}% sentiment influence
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Max Positions</label>
            <input
              type="number"
              min="1"
              max="20"
              value={activeStrategy.maxPositions}
              onChange={(e) => updateStrategy({ maxPositions: parseInt(e.target.value) })}
              className="w-full p-2 border rounded text-sm"
            />
          </div>
        </div>
      </div>

      {/* Trading Signals */}
      <div className="bg-white border rounded-lg p-4 shadow-sm">
        <h2 className="text-lg font-semibold mb-4">Current Trading Signals</h2>
        
        {signals.length === 0 ? (
          <p className="text-gray-500 text-center py-4">No trading signals available</p>
        ) : (
          <div className="space-y-3">
            {signals.map((signal, index) => (
              <div
                key={index}
                className={`p-3 border rounded-lg ${
                  signal.action === 'buy'
                    ? 'bg-green-50 border-green-200'
                    : signal.action === 'sell'
                    ? 'bg-red-50 border-red-200'
                    : 'bg-gray-50 border-gray-200'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start space-y-2 sm:space-y-0">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2">
                      <span className="font-bold text-lg">{signal.symbol}</span>
                      <span
                        className={`px-2 py-1 rounded text-xs font-medium ${
                          signal.action === 'buy'
                            ? 'bg-green-600 text-white'
                            : signal.action === 'sell'
                            ? 'bg-red-600 text-white'
                            : 'bg-gray-600 text-white'
                        }`}
                      >
                        {signal.action.toUpperCase()}
                      </span>
                      <span className="text-sm text-gray-600">
                        {formatCurrency(signal.price)}
                      </span>
                    </div>
                    
                    <div className="mt-2 space-y-1">
                      <p className="text-sm text-gray-700">{signal.reasoning}</p>
                      <div className="flex flex-col sm:flex-row sm:space-x-4 space-y-1 sm:space-y-0 text-xs text-gray-500">
                        <span>Confidence: {Math.round(signal.confidence * 100)}%</span>
                        <span>Technical: {Math.round(signal.technicalScore * 100)}%</span>
                        <span className={getSentimentColor(signal.sentimentScore)}>
                          Sentiment: {getSentimentLabel(signal.sentimentScore)}
                        </span>
                        <span>Strategy: {signal.strategy}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <div className="text-xs text-gray-500">
                      {formatDateTime(signal.timestamp)}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* News Sentiment */}
      <div className="bg-white border rounded-lg p-4 shadow-sm">
        <h2 className="text-lg font-semibold mb-4">Market Sentiment from News</h2>
        
        {news.length === 0 ? (
          <p className="text-gray-500 text-center py-4">No news data available</p>
        ) : (
          <div className="space-y-3">
            {news.slice(0, 5).map((item, index) => (
              <div key={index} className="p-3 border rounded-lg">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <h3 className="font-medium text-sm">{item.title}</h3>
                    <p className="text-xs text-gray-600 mt-1">{item.summary}</p>
                    <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                      <span>Source: {item.source}</span>
                      <span>Relevance: {Math.round(item.relevance * 100)}%</span>
                      <span className={getSentimentColor(item.sentiment)}>
                        {getSentimentLabel(item.sentiment)}
                      </span>
                    </div>
                  </div>
                  <div className="text-right ml-4">
                    <div className="text-xs text-gray-500">
                      {formatDateTime(item.timestamp)}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Backtest Section */}
      <div className="bg-white border rounded-lg p-4 shadow-sm">
        <h2 className="text-lg font-semibold mb-4">Strategy Backtesting</h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Start Date</label>
            <input
              type="date"
              className="w-full p-2 border rounded text-sm"
              defaultValue="2024-01-01"
              id="backtest-start"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">End Date</label>
            <input
              type="date"
              className="w-full p-2 border rounded text-sm"
              defaultValue="2024-12-31"
              id="backtest-end"
            />
          </div>
          <div className="flex items-end">
            <button
              onClick={() => {
                const startEl = document.getElementById('backtest-start') as HTMLInputElement;
                const endEl = document.getElementById('backtest-end') as HTMLInputElement;
                runBacktest(startEl.value, endEl.value);
              }}
              disabled={isBacktesting}
              className="w-full bg-purple-600 hover:bg-purple-700 disabled:bg-gray-400 text-white px-4 py-2 rounded text-sm"
            >
              {isBacktesting ? 'Running...' : 'Run Backtest'}
            </button>
          </div>
        </div>

        {backtestResults && (
          <div className="mt-6 space-y-4">
            <h3 className="font-semibold">Backtest Results</h3>
            
            {/* Performance Metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="text-center p-3 bg-gray-50 rounded">
                <div className="text-lg font-bold text-green-600">
                  {formatPercentage(backtestResults.totalReturn)}
                </div>
                <div className="text-xs text-gray-600">Total Return</div>
              </div>
              <div className="text-center p-3 bg-gray-50 rounded">
                <div className="text-lg font-bold text-blue-600">
                  {backtestResults.sharpeRatio.toFixed(2)}
                </div>
                <div className="text-xs text-gray-600">Sharpe Ratio</div>
              </div>
              <div className="text-center p-3 bg-gray-50 rounded">
                <div className="text-lg font-bold text-red-600">
                  {formatPercentage(backtestResults.maxDrawdown)}
                </div>
                <div className="text-xs text-gray-600">Max Drawdown</div>
              </div>
              <div className="text-center p-3 bg-gray-50 rounded">
                <div className="text-lg font-bold text-purple-600">
                  {formatPercentage(backtestResults.winRate)}
                </div>
                <div className="text-xs text-gray-600">Win Rate</div>
              </div>
            </div>

            {/* Additional Metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-sm">
              <div>
                <span className="font-medium">Total Trades:</span> {backtestResults.totalTrades}
              </div>
              <div>
                <span className="font-medium">Avg Return:</span> {formatPercentage(backtestResults.avgReturn)}
              </div>
              <div>
                <span className="font-medium">Period:</span> {backtestResults.startDate} to {backtestResults.endDate}
              </div>
            </div>

            {/* Equity Curve Visualization */}
            <div className="mt-4">
              <h4 className="font-medium mb-2">Equity Curve</h4>
              <div className="h-40 bg-gray-50 rounded flex items-end justify-between p-2 overflow-hidden">
                {backtestResults.equity.slice(0, 20).map((point, index) => (
                  <div
                    key={index}
                    className="bg-blue-500 rounded-t w-2 mx-px"
                    style={{
                      height: `${Math.max(5, (point.value - 9000) / 50)}%`
                    }}
                    title={`${point.date}: ${formatCurrency(point.value)}`}
                  />
                ))}
              </div>
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>{backtestResults.startDate}</span>
                <span>{backtestResults.endDate}</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default StrategyEngine;
