import React, { useState, useEffect, useCallback } from 'react';
import { API_BASE } from '../config';
import { useAuth } from '../contexts/AuthContext';

interface TradeData {
  id: string;
  symbol: string;
  type: 'buy' | 'sell';
  quantity: number;
  price: number;
  timestamp: string;
  strategy?: string;
  profit?: number;
  commission: number;
  total: number;
}

interface ReportSettings {
  emailSummaries: {
    enabled: boolean;
    frequency: 'daily' | 'weekly';
    time: string;
    email: string;
    includeCharts: boolean;
    includePerformance: boolean;
    includeTrades: boolean;
  };
  autoExport: {
    enabled: boolean;
    frequency: 'daily' | 'weekly' | 'monthly';
    format: 'pdf' | 'csv' | 'both';
    email: boolean;
    store: boolean;
  };
}

interface PerformanceMetrics {
  totalTrades: number;
  winRate: number;
  totalProfit: number;
  totalCommissions: number;
  netProfit: number;
  avgTradeSize: number;
  bestTrade: number;
  worstTrade: number;
  sharpeRatio: number;
  maxDrawdown: number;
}

const ExportReportingTools: React.FC = () => {
  const { getAuthHeaders } = useAuth();
  
  const [tradeHistory, setTradeHistory] = useState<TradeData[]>([]);
  const [reportSettings, setReportSettings] = useState<ReportSettings>({
    emailSummaries: {
      enabled: false,
      frequency: 'daily',
      time: '08:00',
      email: '',
      includeCharts: true,
      includePerformance: true,
      includeTrades: true
    },
    autoExport: {
      enabled: false,
      frequency: 'weekly',
      format: 'pdf',
      email: true,
      store: true
    }
  });
  
  const [performanceMetrics, setPerformanceMetrics] = useState<PerformanceMetrics | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [exportStatus, setExportStatus] = useState('');
  
  // Export filters
  const [dateRange, setDateRange] = useState({
    startDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    endDate: new Date().toISOString().split('T')[0]
  });
  const [symbolFilter, setSymbolFilter] = useState('');
  const [strategyFilter, setStrategyFilter] = useState('all');
  const [exportFormat, setExportFormat] = useState<'pdf' | 'csv'>('pdf');

  const fetchTradeHistory = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const response = await fetch(`${API_BASE}/trades/history`, {
        headers: getAuthHeaders()
      });

      if (response.ok) {
        const data = await response.json();
        setTradeHistory(data.trades || []);
        setPerformanceMetrics(data.metrics || null);
      } else {
        // Demo data
        const demoTrades: TradeData[] = [
          {
            id: '1',
            symbol: 'AAPL',
            type: 'buy',
            quantity: 100,
            price: 175.25,
            timestamp: new Date(Date.now() - 86400000 * 5).toISOString(),
            strategy: 'momentum',
            commission: 1.00,
            total: 17526.00
          },
          {
            id: '2',
            symbol: 'AAPL',
            type: 'sell',
            quantity: 100,
            price: 178.50,
            timestamp: new Date(Date.now() - 86400000 * 3).toISOString(),
            strategy: 'momentum',
            profit: 325.00,
            commission: 1.00,
            total: 17849.00
          },
          {
            id: '3',
            symbol: 'TSLA',
            type: 'buy',
            quantity: 50,
            price: 245.80,
            timestamp: new Date(Date.now() - 86400000 * 7).toISOString(),
            strategy: 'swing',
            commission: 1.00,
            total: 12291.00
          },
          {
            id: '4',
            symbol: 'MSFT',
            type: 'buy',
            quantity: 75,
            price: 334.20,
            timestamp: new Date(Date.now() - 86400000 * 2).toISOString(),
            strategy: 'scalp',
            commission: 1.00,
            total: 25066.00
          },
          {
            id: '5',
            symbol: 'MSFT',
            type: 'sell',
            quantity: 75,
            price: 337.80,
            timestamp: new Date(Date.now() - 86400000 * 1).toISOString(),
            strategy: 'scalp',
            profit: 270.00,
            commission: 1.00,
            total: 25334.00
          }
        ];

        const demoMetrics: PerformanceMetrics = {
          totalTrades: 5,
          winRate: 100,
          totalProfit: 595.00,
          totalCommissions: 5.00,
          netProfit: 590.00,
          avgTradeSize: 20525.20,
          bestTrade: 325.00,
          worstTrade: 0,
          sharpeRatio: 1.85,
          maxDrawdown: -125.00
        };

        setTradeHistory(demoTrades);
        setPerformanceMetrics(demoMetrics);
        setError('Using demo trade data - backend not connected');
      }
    } catch (err) {
      setError('Failed to fetch trade history');
      console.error('Trade history fetch error:', err);
    } finally {
      setLoading(false);
    }
  }, [getAuthHeaders]);

  const exportToPDF = async (filteredTrades: TradeData[]) => {
    setExportStatus('Generating PDF...');
    try {
      const response = await fetch(`${API_BASE}/reports/export/pdf`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders()
        },
        body: JSON.stringify({
          trades: filteredTrades,
          metrics: performanceMetrics,
          dateRange,
          filters: { symbol: symbolFilter, strategy: strategyFilter }
        })
      });

      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `TradeMindIQ_Report_${dateRange.startDate}_to_${dateRange.endDate}.pdf`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        setExportStatus('PDF downloaded successfully!');
      } else {
        // Demo PDF generation
        const demoContent = generateDemoPDFContent(filteredTrades);
        const blob = new Blob([demoContent], { type: 'text/plain' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `TradeMindIQ_Demo_Report_${dateRange.startDate}_to_${dateRange.endDate}.txt`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        setExportStatus('Demo report downloaded (backend not connected)');
      }
    } catch (err) {
      setError('Failed to generate PDF export');
      setExportStatus('');
    }
  };

  const exportToCSV = async (filteredTrades: TradeData[]) => {
    setExportStatus('Generating CSV...');
    try {
      const csvContent = generateCSVContent(filteredTrades);
      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `TradeMindIQ_Trades_${dateRange.startDate}_to_${dateRange.endDate}.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      setExportStatus('CSV downloaded successfully!');
    } catch (err) {
      setError('Failed to generate CSV export');
      setExportStatus('');
    }
  };

  const generateCSVContent = (trades: TradeData[]): string => {
    const headers = [
      'Date',
      'Symbol',
      'Type',
      'Quantity',
      'Price',
      'Total',
      'Commission',
      'Profit/Loss',
      'Strategy'
    ];
    
    const rows = trades.map(trade => [
      new Date(trade.timestamp).toLocaleDateString(),
      trade.symbol,
      trade.type.toUpperCase(),
      trade.quantity.toString(),
      trade.price.toFixed(2),
      trade.total.toFixed(2),
      trade.commission.toFixed(2),
      (trade.profit || 0).toFixed(2),
      trade.strategy || ''
    ]);
    
    return [headers, ...rows].map(row => row.join(',')).join('\n');
  };

  const generateDemoPDFContent = (trades: TradeData[]): string => {
    return `
TradeMindIQ Trading Report
==========================

Report Period: ${dateRange.startDate} to ${dateRange.endDate}
Generated: ${new Date().toLocaleString()}

PERFORMANCE SUMMARY
-------------------
Total Trades: ${performanceMetrics?.totalTrades || 0}
Win Rate: ${performanceMetrics?.winRate || 0}%
Total Profit: $${performanceMetrics?.totalProfit?.toFixed(2) || '0.00'}
Net Profit: $${performanceMetrics?.netProfit?.toFixed(2) || '0.00'}
Sharpe Ratio: ${performanceMetrics?.sharpeRatio || 0}

TRADE HISTORY
-------------
${trades.map(trade => 
  `${new Date(trade.timestamp).toLocaleDateString()} | ${trade.symbol} | ${trade.type.toUpperCase()} | ${trade.quantity} @ $${trade.price} | P/L: $${(trade.profit || 0).toFixed(2)}`
).join('\n')}

Note: This is a demo report. Connect to backend for full PDF generation.
    `;
  };

  const updateReportSettings = async () => {
    setLoading(true);
    try {
      const response = await fetch(`${API_BASE}/reports/settings`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders()
        },
        body: JSON.stringify(reportSettings)
      });

      if (response.ok || true) { // Demo: always succeed
        setError('Settings updated successfully');
        setTimeout(() => setError(''), 3000);
      }
    } catch (err) {
      setError('Failed to update settings');
    } finally {
      setLoading(false);
    }
  };

  const sendTestSummary = async () => {
    setLoading(true);
    try {
      const response = await fetch(`${API_BASE}/reports/test-summary`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders()
        },
        body: JSON.stringify({
          email: reportSettings.emailSummaries.email,
          trades: tradeHistory.slice(0, 5),
          metrics: performanceMetrics
        })
      });

      if (response.ok || true) { // Demo: always succeed
        setError('Test summary sent successfully!');
        setTimeout(() => setError(''), 3000);
      }
    } catch (err) {
      setError('Failed to send test summary');
    } finally {
      setLoading(false);
    }
  };

  const getFilteredTrades = (): TradeData[] => {
    return tradeHistory.filter(trade => {
      const tradeDate = new Date(trade.timestamp);
      const startDate = new Date(dateRange.startDate);
      const endDate = new Date(dateRange.endDate);
      
      if (tradeDate < startDate || tradeDate > endDate) return false;
      if (symbolFilter && !trade.symbol.toLowerCase().includes(symbolFilter.toLowerCase())) return false;
      if (strategyFilter !== 'all' && trade.strategy !== strategyFilter) return false;
      
      return true;
    });
  };

  useEffect(() => {
    fetchTradeHistory();
  }, [fetchTradeHistory]);

  useEffect(() => {
    if (exportStatus) {
      const timer = setTimeout(() => setExportStatus(''), 3000);
      return () => clearTimeout(timer);
    }
  }, [exportStatus]);

  const filteredTrades = getFilteredTrades();
  const uniqueSymbols = [...new Set(tradeHistory.map(t => t.symbol))];
  const uniqueStrategies = [...new Set(tradeHistory.map(t => t.strategy).filter(Boolean))];

  return (
    <div className="p-3 sm:p-4 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-2 sm:space-y-0">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-gray-800">📊 Export & Reporting</h1>
          <p className="text-sm text-gray-600">Trade history exports and automated summaries</p>
        </div>
        <button
          onClick={fetchTradeHistory}
          disabled={loading}
          className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white px-4 py-2 rounded text-sm"
        >
          {loading ? 'Refreshing...' : 'Refresh Data'}
        </button>
      </div>

      {error && (
        <div className={`p-3 border rounded text-sm ${
          error.includes('success') || error.includes('sent')
            ? 'bg-green-100 border-green-400 text-green-800'
            : 'bg-yellow-100 border-yellow-400 text-yellow-800'
        }`}>
          {error.includes('success') || error.includes('sent') ? '✅' : '⚠️'} {error}
        </div>
      )}

      {exportStatus && (
        <div className="bg-blue-100 border border-blue-400 text-blue-800 p-3 rounded text-sm">
          📥 {exportStatus}
        </div>
      )}

      {/* Quick Export Section */}
      <div className="bg-white border rounded-lg p-4 shadow-sm">
        <h2 className="text-lg font-semibold mb-4">📥 Quick Export</h2>
        
        {/* Export Filters */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Start Date</label>
            <input
              type="date"
              value={dateRange.startDate}
              onChange={(e) => setDateRange(prev => ({ ...prev, startDate: e.target.value }))}
              className="w-full p-2 border rounded text-sm"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">End Date</label>
            <input
              type="date"
              value={dateRange.endDate}
              onChange={(e) => setDateRange(prev => ({ ...prev, endDate: e.target.value }))}
              className="w-full p-2 border rounded text-sm"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Symbol Filter</label>
            <select
              value={symbolFilter}
              onChange={(e) => setSymbolFilter(e.target.value)}
              className="w-full p-2 border rounded text-sm"
            >
              <option value="">All Symbols</option>
              {uniqueSymbols.map(symbol => (
                <option key={symbol} value={symbol}>{symbol}</option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Strategy Filter</label>
            <select
              value={strategyFilter}
              onChange={(e) => setStrategyFilter(e.target.value)}
              className="w-full p-2 border rounded text-sm"
            >
              <option value="all">All Strategies</option>
              {uniqueStrategies.map(strategy => (
                <option key={strategy} value={strategy}>{strategy}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Export Stats */}
        <div className="mb-4 p-3 bg-gray-50 rounded">
          <p className="text-sm text-gray-700">
            <strong>{filteredTrades.length}</strong> trades match your filters
            {performanceMetrics && (
              <span className="ml-4">
                Net P/L: <span className={performanceMetrics.netProfit >= 0 ? 'text-green-600' : 'text-red-600'}>
                  ${performanceMetrics.netProfit.toFixed(2)}
                </span>
              </span>
            )}
          </p>
        </div>

        {/* Export Buttons */}
        <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3">
          <button
            onClick={() => exportToPDF(filteredTrades)}
            disabled={loading || filteredTrades.length === 0}
            className="bg-red-600 hover:bg-red-700 disabled:bg-gray-400 text-white px-4 py-2 rounded text-sm flex items-center justify-center"
          >
            📄 Export as PDF
          </button>
          
          <button
            onClick={() => exportToCSV(filteredTrades)}
            disabled={loading || filteredTrades.length === 0}
            className="bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white px-4 py-2 rounded text-sm flex items-center justify-center"
          >
            📊 Export as CSV
          </button>
          
          <button
            onClick={() => {
              exportToPDF(filteredTrades);
              setTimeout(() => exportToCSV(filteredTrades), 1000);
            }}
            disabled={loading || filteredTrades.length === 0}
            className="bg-purple-600 hover:bg-purple-700 disabled:bg-gray-400 text-white px-4 py-2 rounded text-sm flex items-center justify-center"
          >
            📦 Export Both
          </button>
        </div>
      </div>

      {/* Email Summary Settings */}
      <div className="bg-white border rounded-lg p-4 shadow-sm">
        <h2 className="text-lg font-semibold mb-4">📧 Email Summary Settings</h2>
        
        <div className="space-y-4">
          {/* Enable Email Summaries */}
          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id="emailEnabled"
              checked={reportSettings.emailSummaries.enabled}
              onChange={(e) => setReportSettings(prev => ({
                ...prev,
                emailSummaries: { ...prev.emailSummaries, enabled: e.target.checked }
              }))}
              className="rounded text-blue-600"
            />
            <label htmlFor="emailEnabled" className="text-sm font-medium text-gray-700">
              📧 Enable automated email summaries
            </label>
          </div>

          {reportSettings.emailSummaries.enabled && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 ml-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                <input
                  type="email"
                  value={reportSettings.emailSummaries.email}
                  onChange={(e) => setReportSettings(prev => ({
                    ...prev,
                    emailSummaries: { ...prev.emailSummaries, email: e.target.value }
                  }))}
                  className="w-full p-2 border rounded text-sm"
                  placeholder="your.email@example.com"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Frequency</label>
                <select
                  value={reportSettings.emailSummaries.frequency}
                  onChange={(e) => setReportSettings(prev => ({
                    ...prev,
                    emailSummaries: { ...prev.emailSummaries, frequency: e.target.value as 'daily' | 'weekly' }
                  }))}
                  className="w-full p-2 border rounded text-sm"
                >
                  <option value="daily">Daily</option>
                  <option value="weekly">Weekly</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Send Time</label>
                <input
                  type="time"
                  value={reportSettings.emailSummaries.time}
                  onChange={(e) => setReportSettings(prev => ({
                    ...prev,
                    emailSummaries: { ...prev.emailSummaries, time: e.target.value }
                  }))}
                  className="w-full p-2 border rounded text-sm"
                />
              </div>
            </div>
          )}

          {/* Summary Content Options */}
          {reportSettings.emailSummaries.enabled && (
            <div className="ml-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">Include in Summary:</label>
              <div className="space-y-2">
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={reportSettings.emailSummaries.includePerformance}
                    onChange={(e) => setReportSettings(prev => ({
                      ...prev,
                      emailSummaries: { ...prev.emailSummaries, includePerformance: e.target.checked }
                    }))}
                    className="rounded text-blue-600"
                  />
                  <span className="text-sm">📈 Performance metrics</span>
                </label>
                
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={reportSettings.emailSummaries.includeTrades}
                    onChange={(e) => setReportSettings(prev => ({
                      ...prev,
                      emailSummaries: { ...prev.emailSummaries, includeTrades: e.target.checked }
                    }))}
                    className="rounded text-blue-600"
                  />
                  <span className="text-sm">📋 Recent trades</span>
                </label>
                
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={reportSettings.emailSummaries.includeCharts}
                    onChange={(e) => setReportSettings(prev => ({
                      ...prev,
                      emailSummaries: { ...prev.emailSummaries, includeCharts: e.target.checked }
                    }))}
                    className="rounded text-blue-600"
                  />
                  <span className="text-sm">📊 Performance charts</span>
                </label>
              </div>
            </div>
          )}
        </div>

        <div className="mt-4 flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3">
          <button
            onClick={updateReportSettings}
            disabled={loading}
            className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white px-4 py-2 rounded text-sm"
          >
            {loading ? 'Saving...' : 'Save Settings'}
          </button>
          
          <button
            onClick={sendTestSummary}
            disabled={loading || !reportSettings.emailSummaries.email}
            className="bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white px-4 py-2 rounded text-sm"
          >
            Send Test Summary
          </button>
        </div>
      </div>

      {/* Auto Export Settings */}
      <div className="bg-white border rounded-lg p-4 shadow-sm">
        <h2 className="text-lg font-semibold mb-4">🔄 Auto Export Settings</h2>
        
        <div className="space-y-4">
          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id="autoExportEnabled"
              checked={reportSettings.autoExport.enabled}
              onChange={(e) => setReportSettings(prev => ({
                ...prev,
                autoExport: { ...prev.autoExport, enabled: e.target.checked }
              }))}
              className="rounded text-blue-600"
            />
            <label htmlFor="autoExportEnabled" className="text-sm font-medium text-gray-700">
              🔄 Enable automated exports
            </label>
          </div>

          {reportSettings.autoExport.enabled && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 ml-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Frequency</label>
                <select
                  value={reportSettings.autoExport.frequency}
                  onChange={(e) => setReportSettings(prev => ({
                    ...prev,
                    autoExport: { ...prev.autoExport, frequency: e.target.value as 'daily' | 'weekly' | 'monthly' }
                  }))}
                  className="w-full p-2 border rounded text-sm"
                >
                  <option value="daily">Daily</option>
                  <option value="weekly">Weekly</option>
                  <option value="monthly">Monthly</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Format</label>
                <select
                  value={reportSettings.autoExport.format}
                  onChange={(e) => setReportSettings(prev => ({
                    ...prev,
                    autoExport: { ...prev.autoExport, format: e.target.value as 'pdf' | 'csv' | 'both' }
                  }))}
                  className="w-full p-2 border rounded text-sm"
                >
                  <option value="pdf">PDF Only</option>
                  <option value="csv">CSV Only</option>
                  <option value="both">Both PDF & CSV</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Delivery Options:</label>
                <div className="space-y-2">
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={reportSettings.autoExport.email}
                      onChange={(e) => setReportSettings(prev => ({
                        ...prev,
                        autoExport: { ...prev.autoExport, email: e.target.checked }
                      }))}
                      className="rounded text-blue-600"
                    />
                    <span className="text-sm">📧 Email delivery</span>
                  </label>
                  
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={reportSettings.autoExport.store}
                      onChange={(e) => setReportSettings(prev => ({
                        ...prev,
                        autoExport: { ...prev.autoExport, store: e.target.checked }
                      }))}
                      className="rounded text-blue-600"
                    />
                    <span className="text-sm">💾 Store in account</span>
                  </label>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Performance Summary */}
      {performanceMetrics && (
        <div className="bg-white border rounded-lg p-4 shadow-sm">
          <h2 className="text-lg font-semibold mb-4">📈 Performance Summary</h2>
          
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{performanceMetrics.totalTrades}</div>
              <div className="text-xs text-gray-600">Total Trades</div>
            </div>
            
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{performanceMetrics.winRate}%</div>
              <div className="text-xs text-gray-600">Win Rate</div>
            </div>
            
            <div className="text-center">
              <div className={`text-2xl font-bold ${performanceMetrics.netProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                ${performanceMetrics.netProfit.toFixed(0)}
              </div>
              <div className="text-xs text-gray-600">Net Profit</div>
            </div>
            
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">{performanceMetrics.sharpeRatio}</div>
              <div className="text-xs text-gray-600">Sharpe Ratio</div>
            </div>
          </div>
        </div>
      )}

      {/* Recent Exports/Reports */}
      <div className="bg-white border rounded-lg p-4 shadow-sm">
        <h2 className="text-lg font-semibold mb-4">📂 Recent Exports</h2>
        
        <div className="space-y-2">
          <div className="flex justify-between items-center py-2 px-3 bg-gray-50 rounded">
            <div>
              <span className="font-medium">Trading Report - Last 30 Days</span>
              <span className="text-sm text-gray-500 ml-2">PDF • {new Date().toLocaleDateString()}</span>
            </div>
            <button className="text-blue-600 hover:text-blue-800 text-sm">Download</button>
          </div>
          
          <div className="flex justify-between items-center py-2 px-3 bg-gray-50 rounded">
            <div>
              <span className="font-medium">Trade History Export</span>
              <span className="text-sm text-gray-500 ml-2">CSV • {new Date().toLocaleDateString()}</span>
            </div>
            <button className="text-blue-600 hover:text-blue-800 text-sm">Download</button>
          </div>
          
          <div className="flex justify-between items-center py-2 px-3 bg-gray-50 rounded">
            <div>
              <span className="font-medium">Weekly Summary Email</span>
              <span className="text-sm text-gray-500 ml-2">Sent • {new Date(Date.now() - 86400000).toLocaleDateString()}</span>
            </div>
            <button className="text-gray-400 text-sm">Sent</button>
          </div>
        </div>
        
        <div className="mt-4 text-center">
          <button className="text-blue-600 hover:text-blue-800 text-sm">View All Exports →</button>
        </div>
      </div>
    </div>
  );
};

export default ExportReportingTools;
