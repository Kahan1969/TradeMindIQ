import React from 'react';
import { useAuth } from '../contexts/AuthContext';

const UserHeader: React.FC = () => {
  const { user, logout } = useAuth();

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-3 sm:px-4 lg:px-6">
        <div className="flex justify-between items-center h-14 sm:h-16">
          {/* Logo and Title */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            <div className="text-xl sm:text-2xl font-bold text-blue-600">
              TradeMindIQ
            </div>
            <div className="hidden sm:block w-px h-6 bg-gray-300"></div>
            <div className="hidden sm:block text-sm text-gray-600">
              Professional Trading Platform
            </div>
          </div>

          {/* User Info and Actions */}
          <div className="flex items-center space-x-2 sm:space-x-4">
            {/* User Info */}
            <div className="hidden sm:flex flex-col items-end">
              <span className="text-sm font-medium text-gray-900">
                {user?.email || 'Trader'}
              </span>
              <span className="text-xs text-gray-500">
                Online
              </span>
            </div>

            {/* Mobile User Avatar */}
            <div className="sm:hidden w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
              <span className="text-sm font-medium text-blue-600">
                {(user?.email || 'T')[0].toUpperCase()}
              </span>
            </div>

            {/* Logout Button */}
            <button
              onClick={logout}
              className="bg-red-600 hover:bg-red-700 text-white px-3 py-1.5 sm:px-4 sm:py-2 rounded text-sm font-medium transition duration-200"
            >
              <span className="hidden sm:inline">Sign Out</span>
              <span className="sm:hidden">🚪</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default UserHeader;
