import React, { useEffect, useRef, useState } from 'react';
import { createChart, IChartApi, ISeriesApi, LineStyle, ColorType } from 'lightweight-charts';
import { API_BASE } from '../config';
import { EMA, RSI, BollingerBands } from 'technicalindicators';

interface CandleData {
  time: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

interface IndicatorSettings {
  ema: boolean;
  rsi: boolean;
  bollingerBands: boolean;
  buySignals: boolean;
  sellSignals: boolean;
}

interface TradingSignal {
  time: string;
  type: 'buy' | 'sell';
  price: number;
  strength: 'weak' | 'medium' | 'strong';
}

const ChartPanel: React.FC = () => {
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const candleSeriesRef = useRef<ISeriesApi<'Candlestick'> | null>(null);
  const emaSeriesRef = useRef<ISeriesApi<'Line'> | null>(null);
  const rsiChartRef = useRef<IChartApi | null>(null);
  const bbUpperRef = useRef<ISeriesApi<'Line'> | null>(null);
  const bbLowerRef = useRef<ISeriesApi<'Line'> | null>(null);
  
  const [symbol, setSymbol] = useState("AAPL");
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [chartData, setChartData] = useState<CandleData[]>([]);
  const [indicators, setIndicators] = useState<IndicatorSettings>({
    ema: false,
    rsi: false,
    bollingerBands: false,
    buySignals: true,
    sellSignals: true
  });
  const [signals, setSignals] = useState<TradingSignal[]>([]);

  useEffect(() => {
    if (!chartContainerRef.current) return;

    // Main price chart
    const chart = createChart(chartContainerRef.current, {
      width: chartContainerRef.current.clientWidth,
      height: window.innerWidth < 640 ? 300 : 450,
      layout: {
        background: { type: ColorType.Solid, color: '#ffffff' },
        textColor: '#333',
      },
      grid: {
        vertLines: { color: '#f0f0f0' },
        horzLines: { color: '#f0f0f0' },
      },
      rightPriceScale: {
        scaleMargins: { top: 0.1, bottom: 0.1 },
        borderColor: '#cccccc',
      },
      timeScale: {
        borderColor: '#cccccc',
        timeVisible: true,
        secondsVisible: false,
      },
      crosshair: {
        mode: 1, // Normal crosshair
        vertLine: {
          width: 1,
          color: '#758696',
          style: LineStyle.Dashed,
        },
        horzLine: {
          width: 1,
          color: '#758696',
          style: LineStyle.Dashed,
        },
      },
    });

    chartRef.current = chart;
    const candleSeries = chart.addCandlestickSeries({
      upColor: '#26a69a',
      downColor: '#ef5350',
      borderVisible: false,
      wickUpColor: '#26a69a',
      wickDownColor: '#ef5350',
    });
    candleSeriesRef.current = candleSeries;

    fetchChartData();

    const interval = setInterval(fetchChartData, 60000);

    const handleResize = () => {
      if (chartRef.current && chartContainerRef.current) {
        chartRef.current.applyOptions({ 
          width: chartContainerRef.current.clientWidth,
          height: window.innerWidth < 640 ? 300 : 450
        });
      }
    };
    window.addEventListener("resize", handleResize);

    return () => {
      chart.remove();
      window.removeEventListener("resize", handleResize);
      clearInterval(interval);
    };
  }, [symbol]);

  // Update indicators when settings change
  useEffect(() => {
    if (chartData.length > 0) {
      updateIndicators();
      generateTradingSignals();
    }
  }, [indicators, chartData]);

  const fetchChartData = async () => {
    setLoading(true);
    setError('');
    try {
      const response = await fetch(`${API_BASE}/chart-data?symbol=${symbol}`);
      
      let data: CandleData[];
      if (response.ok) {
        data = await response.json();
      } else {
        // Enhanced demo data with more realistic price movements
        data = generateDemoData();
        setError('Using demo data - backend not available');
      }
      
      setChartData(data);
      if (candleSeriesRef.current) {
        candleSeriesRef.current.setData(data);
      }
      
      setLastUpdated(new Date());
    } catch (err) {
      console.error("Failed to load chart data:", err);
      setError('Unable to fetch chart data. Using demo data.');
      const data = generateDemoData();
      setChartData(data);
      if (candleSeriesRef.current) {
        candleSeriesRef.current.setData(data);
      }
      setLastUpdated(new Date());
    } finally {
      setLoading(false);
    }
  };

  const generateDemoData = (): CandleData[] => {
    const data: CandleData[] = [];
    let basePrice = 170;
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - 30);

    for (let i = 0; i < 30; i++) {
      const date = new Date(startDate);
      date.setDate(date.getDate() + i);
      
      const volatility = 0.02;
      const trend = Math.sin(i * 0.2) * 0.01;
      const random = (Math.random() - 0.5) * volatility;
      
      const open = basePrice;
      const changePercent = trend + random;
      const high = open * (1 + Math.abs(changePercent) + Math.random() * 0.01);
      const low = open * (1 - Math.abs(changePercent) - Math.random() * 0.01);
      const close = open * (1 + changePercent);
      
      data.push({
        time: date.toISOString().split('T')[0],
        open: Number(open.toFixed(2)),
        high: Number(high.toFixed(2)),
        low: Number(low.toFixed(2)),
        close: Number(close.toFixed(2)),
        volume: Math.floor(Math.random() * 1000000) + 500000
      });
      
      basePrice = close;
    }
    
    return data;
  };

  const updateIndicators = () => {
    if (!chartRef.current || chartData.length < 20) return;

    const closes = chartData.map(d => d.close);
    const highs = chartData.map(d => d.high);
    const lows = chartData.map(d => d.low);

    // EMA Indicator
    if (indicators.ema) {
      try {
        const emaValues = EMA.calculate({ period: 20, values: closes });
        const emaData = emaValues.map((value, index) => ({
          time: chartData[index + (closes.length - emaValues.length)].time,
          value: Number(value.toFixed(2))
        }));

        if (emaSeriesRef.current) {
          chartRef.current.removeSeries(emaSeriesRef.current);
        }
        
        emaSeriesRef.current = chartRef.current.addLineSeries({
          color: '#2196F3',
          lineWidth: 2,
          title: 'EMA(20)',
        });
        emaSeriesRef.current.setData(emaData);
      } catch (error) {
        console.error('EMA calculation error:', error);
      }
    } else if (emaSeriesRef.current) {
      chartRef.current.removeSeries(emaSeriesRef.current);
      emaSeriesRef.current = null;
    }

    // Bollinger Bands
    if (indicators.bollingerBands) {
      try {
        const bbInput = { period: 20, stdDev: 2, values: closes };
        const bbResult = BollingerBands.calculate(bbInput);
        
        const upperBandData = bbResult.map((band, index) => ({
          time: chartData[index + (closes.length - bbResult.length)].time,
          value: Number(band.upper.toFixed(2))
        }));
        
        const lowerBandData = bbResult.map((band, index) => ({
          time: chartData[index + (closes.length - bbResult.length)].time,
          value: Number(band.lower.toFixed(2))
        }));

        if (bbUpperRef.current) {
          chartRef.current.removeSeries(bbUpperRef.current);
        }
        if (bbLowerRef.current) {
          chartRef.current.removeSeries(bbLowerRef.current);
        }

        bbUpperRef.current = chartRef.current.addLineSeries({
          color: '#FF9800',
          lineWidth: 1,
          lineStyle: LineStyle.Dashed,
          title: 'BB Upper',
        });
        bbUpperRef.current.setData(upperBandData);

        bbLowerRef.current = chartRef.current.addLineSeries({
          color: '#FF9800',
          lineWidth: 1,
          lineStyle: LineStyle.Dashed,
          title: 'BB Lower',
        });
        bbLowerRef.current.setData(lowerBandData);
      } catch (error) {
        console.error('Bollinger Bands calculation error:', error);
      }
    } else {
      if (bbUpperRef.current) {
        chartRef.current.removeSeries(bbUpperRef.current);
        bbUpperRef.current = null;
      }
      if (bbLowerRef.current) {
        chartRef.current.removeSeries(bbLowerRef.current);
        bbLowerRef.current = null;
      }
    }
  };

  const generateTradingSignals = () => {
    if (chartData.length < 20) return;

    const closes = chartData.map(d => d.close);
    const signals: TradingSignal[] = [];

    try {
      // Simple EMA crossover strategy
      const emaShort = EMA.calculate({ period: 10, values: closes });
      const emaLong = EMA.calculate({ period: 20, values: closes });
      
      const rsiValues = RSI.calculate({ period: 14, values: closes });

      for (let i = 1; i < Math.min(emaShort.length, emaLong.length, rsiValues.length); i++) {
        const dataIndex = chartData.length - Math.min(emaShort.length, emaLong.length) + i;
        if (dataIndex >= chartData.length) continue;

        const prevShort = emaShort[i - 1];
        const currShort = emaShort[i];
        const prevLong = emaLong[i - 1];
        const currLong = emaLong[i];
        const rsi = rsiValues[Math.min(i, rsiValues.length - 1)];

        // Buy signal: EMA short crosses above EMA long + RSI conditions
        if (prevShort <= prevLong && currShort > currLong && rsi < 70) {
          const strength = rsi < 30 ? 'strong' : rsi < 50 ? 'medium' : 'weak';
          signals.push({
            time: chartData[dataIndex].time,
            type: 'buy',
            price: chartData[dataIndex].close,
            strength
          });
        }

        // Sell signal: EMA short crosses below EMA long + RSI conditions
        if (prevShort >= prevLong && currShort < currLong && rsi > 30) {
          const strength = rsi > 70 ? 'strong' : rsi > 50 ? 'medium' : 'weak';
          signals.push({
            time: chartData[dataIndex].time,
            type: 'sell',
            price: chartData[dataIndex].close,
            strength
          });
        }
      }

      setSignals(signals);

      // Add markers to chart
      if (candleSeriesRef.current) {
        const markers = signals
          .filter(signal => 
            (signal.type === 'buy' && indicators.buySignals) ||
            (signal.type === 'sell' && indicators.sellSignals)
          )
          .map(signal => ({
            time: signal.time,
            position: signal.type === 'buy' ? 'belowBar' as const : 'aboveBar' as const,
            color: signal.type === 'buy' ? '#26a69a' : '#ef5350',
            shape: signal.type === 'buy' ? 'arrowUp' as const : 'arrowDown' as const,
            text: `${signal.type.toUpperCase()} (${signal.strength})`,
            size: signal.strength === 'strong' ? 2 : signal.strength === 'medium' ? 1.5 : 1,
          }));

        candleSeriesRef.current.setMarkers(markers);
      }
    } catch (error) {
      console.error('Signal generation error:', error);
    }
  };

  const toggleIndicator = (indicator: keyof IndicatorSettings) => {
    setIndicators(prev => ({
      ...prev,
      [indicator]: !prev[indicator]
    }));
  };

  const formatLastUpdated = (date: Date | null) => {
    if (!date) return '';
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  const refreshChart = () => {
    fetchChartData();
  };

  return (
    <div className="p-3 sm:p-4 border rounded shadow bg-white">
      <div className="flex flex-col space-y-4">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-2 sm:space-y-0">
          <div className="flex-1">
            <h2 className="text-lg sm:text-xl font-bold">📈 Advanced Chart - {symbol}</h2>
            <div className="flex flex-col sm:flex-row sm:items-center sm:space-x-2">
              {lastUpdated && (
                <p className="text-xs text-gray-500">
                  Last updated: {formatLastUpdated(lastUpdated)}
                </p>
              )}
              {loading && (
                <span className="text-xs text-blue-600 flex items-center">
                  <span className="animate-spin mr-1">⟳</span>
                  Updating...
                </span>
              )}
            </div>
          </div>
          <button
            onClick={refreshChart}
            disabled={loading}
            className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white px-3 py-1 rounded text-sm w-full sm:w-auto"
          >
            {loading ? 'Refreshing...' : 'Refresh'}
          </button>
        </div>

        {error && (
          <div className="p-3 bg-red-100 border border-red-400 text-red-700 rounded text-sm">
            ❌ {error}
          </div>
        )}

        {/* Symbol Input */}
        <div>
          <input
            type="text"
            value={symbol}
            onChange={(e) => setSymbol(e.target.value.toUpperCase())}
            className="w-full sm:w-auto p-2 border rounded text-sm"
            placeholder="Enter symbol (e.g., AAPL)"
          />
        </div>

        {/* Technical Indicators Controls */}
        <div className="bg-gray-50 p-3 rounded-lg">
          <h3 className="text-sm font-semibold mb-3 text-gray-700">Technical Indicators & Signals</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
            <label className="flex items-center space-x-2 text-sm">
              <input
                type="checkbox"
                checked={indicators.ema}
                onChange={() => toggleIndicator('ema')}
                className="rounded text-blue-600"
              />
              <span>EMA(20)</span>
            </label>
            <label className="flex items-center space-x-2 text-sm">
              <input
                type="checkbox"
                checked={indicators.bollingerBands}
                onChange={() => toggleIndicator('bollingerBands')}
                className="rounded text-blue-600"
              />
              <span>Bollinger Bands</span>
            </label>
            <label className="flex items-center space-x-2 text-sm">
              <input
                type="checkbox"
                checked={indicators.buySignals}
                onChange={() => toggleIndicator('buySignals')}
                className="rounded text-green-600"
              />
              <span className="text-green-600">📈 Buy Signals</span>
            </label>
            <label className="flex items-center space-x-2 text-sm">
              <input
                type="checkbox"
                checked={indicators.sellSignals}
                onChange={() => toggleIndicator('sellSignals')}
                className="rounded text-red-600"
              />
              <span className="text-red-600">📉 Sell Signals</span>
            </label>
          </div>
        </div>

        {/* Trading Signals Summary */}
        {signals.length > 0 && (indicators.buySignals || indicators.sellSignals) && (
          <div className="bg-blue-50 p-3 rounded-lg">
            <h3 className="text-sm font-semibold mb-2 text-blue-800">Recent Trading Signals</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              {signals.slice(-4).map((signal, index) => (
                <div key={index} className={`p-2 rounded ${
                  signal.type === 'buy' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                }`}>
                  <div className="font-medium">
                    {signal.type === 'buy' ? '📈' : '📉'} {signal.type.toUpperCase()} Signal
                  </div>
                  <div>Price: ${signal.price.toFixed(2)}</div>
                  <div>Strength: {signal.strength}</div>
                  <div>Date: {signal.time}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Chart Container */}
        <div 
          ref={chartContainerRef} 
          className="w-full border rounded bg-white"
          style={{ minHeight: window.innerWidth < 640 ? '300px' : '450px' }}
        />

        {/* RSI Indicator (if enabled) */}
        {indicators.rsi && (
          <div className="bg-gray-50 p-3 rounded-lg">
            <h3 className="text-sm font-semibold mb-2 text-gray-700">RSI (14) Indicator</h3>
            <RSIChart data={chartData} />
          </div>
        )}
      </div>
    </div>
  );
};

// RSI Chart Component
const RSIChart: React.FC<{ data: CandleData[] }> = ({ data }) => {
  const rsiContainerRef = useRef<HTMLDivElement>(null);
  const rsiChartRef = useRef<IChartApi | null>(null);

  useEffect(() => {
    if (!rsiContainerRef.current || data.length < 14) return;

    const rsiChart = createChart(rsiContainerRef.current, {
      width: rsiContainerRef.current.clientWidth,
      height: 150,
      layout: {
        background: { type: ColorType.Solid, color: '#ffffff' },
        textColor: '#333',
      },
      grid: {
        vertLines: { color: '#f0f0f0' },
        horzLines: { color: '#f0f0f0' },
      },
      rightPriceScale: {
        scaleMargins: { top: 0.1, bottom: 0.1 },
        borderColor: '#cccccc',
      },
      timeScale: {
        borderColor: '#cccccc',
      },
    });

    rsiChartRef.current = rsiChart;

    const rsiSeries = rsiChart.addLineSeries({
      color: '#9C27B0',
      lineWidth: 2,
    });

    try {
      const closes = data.map(d => d.close);
      const rsiValues = RSI.calculate({ period: 14, values: closes });
      
      const rsiData = rsiValues.map((value, index) => ({
        time: data[index + (closes.length - rsiValues.length)].time,
        value: Number(value.toFixed(2))
      }));

      rsiSeries.setData(rsiData);

      // Add horizontal lines for overbought/oversold levels
      const overboughtLine = rsiChart.addLineSeries({
        color: '#f44336',
        lineWidth: 1,
        lineStyle: LineStyle.Dashed,
      });
      
      const oversoldLine = rsiChart.addLineSeries({
        color: '#4caf50',
        lineWidth: 1,
        lineStyle: LineStyle.Dashed,
      });

      const horizontalLineData = rsiData.map(point => ({ time: point.time, value: 70 }));
      const horizontalLineData2 = rsiData.map(point => ({ time: point.time, value: 30 }));
      
      overboughtLine.setData(horizontalLineData);
      oversoldLine.setData(horizontalLineData2);

    } catch (error) {
      console.error('RSI chart error:', error);
    }

    const handleResize = () => {
      if (rsiChartRef.current && rsiContainerRef.current) {
        rsiChartRef.current.applyOptions({ 
          width: rsiContainerRef.current.clientWidth 
        });
      }
    };
    window.addEventListener("resize", handleResize);

    return () => {
      rsiChart.remove();
      window.removeEventListener("resize", handleResize);
    };
  }, [data]);

  return (
    <div 
      ref={rsiContainerRef} 
      className="w-full border rounded bg-white"
      style={{ height: '150px' }}
    />
  );
};

export default ChartPanel;
