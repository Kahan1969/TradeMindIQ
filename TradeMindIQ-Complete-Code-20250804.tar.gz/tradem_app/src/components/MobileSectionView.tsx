import React from 'react';
import AccountSummary from './AccountSummary';
import Portfolio from './Portfolio';
import ChartPanel from './ChartPanel';
import AlertTicker from './AlertTicker';
import TradeHistory from './TradeHistory';
import StrategyEngine from './StrategyEngine';
import AlertsManager from './AlertsManager';
import ExportReportingTools from './ExportReportingTools';
import SettingsPanel from './SettingsPanel';

interface MobileSectionViewProps {
  activeSection: string;
}

const MobileSectionView: React.FC<MobileSectionViewProps> = ({ activeSection }) => {
  const renderSection = () => {
    switch (activeSection) {
      case 'dashboard':
        return <AccountSummary />;
      case 'strategy':
        return <StrategyEngine />;
      case 'alerts':
        return <AlertsManager />;
      case 'reports':
        return <ExportReportingTools />;
      case 'settings':
        return <SettingsPanel />;
      default:
        return <AccountSummary />;
    }
  };

  return (
    <div className="pb-4">
      {renderSection()}
    </div>
  );
};

export default MobileSectionView;
