import React, { useEffect, useState } from 'react';

const AlertTicker: React.FC = () => {
  const [alerts, setAlerts] = useState<string[]>([]);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  useEffect(() => {
    // Try WebSocket connection first
    try {
      const ws = new WebSocket('ws://localhost:8001/ws/alerts');

      ws.onmessage = (event) => {
        const data = JSON.parse(event.data);
        if (data.alerts) {
          setAlerts(data.alerts);
          setLastUpdated(new Date());
        }
      };

      ws.onerror = (err) => {
        console.error("WebSocket error:", err);
        // Fallback to demo data if WebSocket fails
        setAlerts([
          "📈 AAPL broke above $175 resistance",
          "⚡ High volume detected in TSLA",
          "🔔 MSFT approaching support at $330",
          "💡 AI recommendation: Consider profit taking on NVDA"
        ]);
        setLastUpdated(new Date());
      };

      // Set up auto-refresh as fallback every 60 seconds
      const interval = setInterval(() => {
        if (ws.readyState === WebSocket.CLOSED) {
          setLastUpdated(new Date());
        }
      }, 60000);

      return () => {
        ws.close();
        clearInterval(interval);
      };
    } catch (error) {
      // Fallback to demo data
      setAlerts([
        "📈 AAPL broke above $175 resistance",
        "⚡ High volume detected in TSLA",
        "🔔 MSFT approaching support at $330",
        "💡 AI recommendation: Consider profit taking on NVDA"
      ]);
      setLastUpdated(new Date());
    }
  }, []);

  const formatLastUpdated = (date: Date | null) => {
    if (!date) return '';
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  return (
    <div className="bg-yellow-100 p-3 sm:p-4 border rounded shadow">
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-2 space-y-1 sm:space-y-0">
        <div>
          <h3 className="text-base sm:text-lg font-bold">🚨 Live Trade Alerts</h3>
          {lastUpdated && (
            <p className="text-xs text-gray-600">
              Last updated: {formatLastUpdated(lastUpdated)}
            </p>
          )}
        </div>
      </div>
      {alerts.length > 0 ? (
        <ul className="list-disc pl-4 sm:pl-5 space-y-1 text-xs sm:text-sm">
          {alerts.map((alert, i) => <li key={i} className="break-words">{alert}</li>)}
        </ul>
      ) : (
        <p className="text-sm">No alerts yet.</p>
      )}
    </div>
  );
};

export default AlertTicker;
