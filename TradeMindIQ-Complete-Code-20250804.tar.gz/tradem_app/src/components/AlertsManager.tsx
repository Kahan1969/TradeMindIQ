import React, { useState, useEffect, useCallback } from 'react';
import { API_BASE } from '../config';
import { useAuth } from '../contexts/AuthContext';

interface PriceAlert {
  id: string;
  symbol: string;
  condition: 'above' | 'below' | 'crosses_above' | 'crosses_below';
  targetPrice: number;
  currentPrice: number;
  isActive: boolean;
  createdAt: string;
  triggeredAt?: string;
  notificationMethod: ('email' | 'sms' | 'push')[];
  message?: string;
}

interface AISignalAlert {
  id: string;
  strategy: string;
  symbols: string[];
  minConfidence: number;
  signalTypes: ('buy' | 'sell' | 'hold')[];
  notificationMethod: ('email' | 'sms' | 'push')[];
  isActive: boolean;
  createdAt: string;
}

interface NotificationSettings {
  email: string;
  phone: string;
  emailEnabled: boolean;
  smsEnabled: boolean;
  pushEnabled: boolean;
  quietHours: {
    enabled: boolean;
    start: string;
    end: string;
  };
}

interface AlertHistory {
  id: string;
  type: 'price' | 'signal';
  title: string;
  message: string;
  timestamp: string;
  status: 'sent' | 'failed' | 'pending';
  methods: string[];
}

const AlertsManager: React.FC = () => {
  const { getAuthHeaders } = useAuth();
  
  const [priceAlerts, setPriceAlerts] = useState<PriceAlert[]>([]);
  const [signalAlerts, setSignalAlerts] = useState<AISignalAlert[]>([]);
  const [alertHistory, setAlertHistory] = useState<AlertHistory[]>([]);
  const [notificationSettings, setNotificationSettings] = useState<NotificationSettings>({
    email: '',
    phone: '',
    emailEnabled: true,
    smsEnabled: false,
    pushEnabled: true,
    quietHours: {
      enabled: false,
      start: '22:00',
      end: '08:00'
    }
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState<'price' | 'signals' | 'settings' | 'history'>('price');
  
  // New Price Alert Form
  const [newPriceAlert, setNewPriceAlert] = useState({
    symbol: '',
    condition: 'above' as const,
    targetPrice: '',
    notificationMethod: ['email'] as ('email' | 'sms' | 'push')[]
  });

  // New Signal Alert Form
  const [newSignalAlert, setNewSignalAlert] = useState({
    strategy: 'all',
    symbols: [] as string[],
    minConfidence: 70,
    signalTypes: ['buy', 'sell'] as ('buy' | 'sell' | 'hold')[],
    notificationMethod: ['email'] as ('email' | 'sms' | 'push')[]
  });

  const fetchAlerts = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const response = await fetch(`${API_BASE}/alerts`, {
        headers: getAuthHeaders()
      });

      if (response.ok) {
        const data = await response.json();
        setPriceAlerts(data.priceAlerts || []);
        setSignalAlerts(data.signalAlerts || []);
        setAlertHistory(data.history || []);
        setNotificationSettings(data.settings || notificationSettings);
      } else {
        // Demo data
        const demoPriceAlerts: PriceAlert[] = [
          {
            id: '1',
            symbol: 'AAPL',
            condition: 'above',
            targetPrice: 180.00,
            currentPrice: 175.25,
            isActive: true,
            createdAt: new Date(Date.now() - 86400000).toISOString(),
            notificationMethod: ['email', 'sms']
          },
          {
            id: '2',
            symbol: 'TSLA',
            condition: 'below',
            targetPrice: 240.00,
            currentPrice: 245.80,
            isActive: true,
            createdAt: new Date(Date.now() - 172800000).toISOString(),
            notificationMethod: ['email']
          }
        ];

        const demoSignalAlerts: AISignalAlert[] = [
          {
            id: '1',
            strategy: 'momentum',
            symbols: ['AAPL', 'MSFT'],
            minConfidence: 75,
            signalTypes: ['buy', 'sell'],
            notificationMethod: ['email', 'push'],
            isActive: true,
            createdAt: new Date(Date.now() - 259200000).toISOString()
          }
        ];

        const demoHistory: AlertHistory[] = [
          {
            id: '1',
            type: 'signal',
            title: 'BUY Signal: AAPL',
            message: 'Strong momentum signal detected for AAPL at $175.25 with 85% confidence',
            timestamp: new Date(Date.now() - 3600000).toISOString(),
            status: 'sent',
            methods: ['email', 'push']
          },
          {
            id: '2',
            type: 'price',
            title: 'Price Alert: TSLA',
            message: 'TSLA has dropped below $240.00, currently at $235.50',
            timestamp: new Date(Date.now() - 7200000).toISOString(),
            status: 'sent',
            methods: ['email', 'sms']
          }
        ];

        setPriceAlerts(demoPriceAlerts);
        setSignalAlerts(demoSignalAlerts);
        setAlertHistory(demoHistory);
        setError('Using demo alert data - backend not connected');
      }
    } catch (err) {
      setError('Failed to fetch alerts');
      console.error('Alerts fetch error:', err);
    } finally {
      setLoading(false);
    }
  }, [getAuthHeaders, notificationSettings]);

  const createPriceAlert = async () => {
    if (!newPriceAlert.symbol || !newPriceAlert.targetPrice) {
      setError('Please fill in all required fields');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`${API_BASE}/alerts/price`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders()
        },
        body: JSON.stringify({
          ...newPriceAlert,
          targetPrice: parseFloat(newPriceAlert.targetPrice)
        })
      });

      if (response.ok) {
        const newAlert = await response.json();
        setPriceAlerts(prev => [...prev, newAlert]);
      } else {
        // Demo creation
        const demoAlert: PriceAlert = {
          id: Date.now().toString(),
          symbol: newPriceAlert.symbol.toUpperCase(),
          condition: newPriceAlert.condition,
          targetPrice: parseFloat(newPriceAlert.targetPrice),
          currentPrice: Math.random() * 200 + 100, // Random current price
          isActive: true,
          createdAt: new Date().toISOString(),
          notificationMethod: newPriceAlert.notificationMethod
        };
        setPriceAlerts(prev => [...prev, demoAlert]);
        setError('Demo alert created - backend not connected');
      }

      // Reset form
      setNewPriceAlert({
        symbol: '',
        condition: 'above',
        targetPrice: '',
        notificationMethod: ['email']
      });
    } catch (err) {
      setError('Failed to create price alert');
    } finally {
      setLoading(false);
    }
  };

  const createSignalAlert = async () => {
    setLoading(true);
    try {
      const response = await fetch(`${API_BASE}/alerts/signals`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders()
        },
        body: JSON.stringify(newSignalAlert)
      });

      if (response.ok) {
        const newAlert = await response.json();
        setSignalAlerts(prev => [...prev, newAlert]);
      } else {
        // Demo creation
        const demoAlert: AISignalAlert = {
          id: Date.now().toString(),
          strategy: newSignalAlert.strategy,
          symbols: newSignalAlert.symbols,
          minConfidence: newSignalAlert.minConfidence,
          signalTypes: newSignalAlert.signalTypes,
          notificationMethod: newSignalAlert.notificationMethod,
          isActive: true,
          createdAt: new Date().toISOString()
        };
        setSignalAlerts(prev => [...prev, demoAlert]);
        setError('Demo signal alert created - backend not connected');
      }

      // Reset form
      setNewSignalAlert({
        strategy: 'all',
        symbols: [],
        minConfidence: 70,
        signalTypes: ['buy', 'sell'],
        notificationMethod: ['email']
      });
    } catch (err) {
      setError('Failed to create signal alert');
    } finally {
      setLoading(false);
    }
  };

  const toggleAlert = async (type: 'price' | 'signal', id: string) => {
    try {
      const response = await fetch(`${API_BASE}/alerts/${type}/${id}/toggle`, {
        method: 'PATCH',
        headers: getAuthHeaders()
      });

      if (response.ok) {
        if (type === 'price') {
          setPriceAlerts(prev => prev.map(alert => 
            alert.id === id ? { ...alert, isActive: !alert.isActive } : alert
          ));
        } else {
          setSignalAlerts(prev => prev.map(alert => 
            alert.id === id ? { ...alert, isActive: !alert.isActive } : alert
          ));
        }
      } else {
        // Demo toggle
        if (type === 'price') {
          setPriceAlerts(prev => prev.map(alert => 
            alert.id === id ? { ...alert, isActive: !alert.isActive } : alert
          ));
        } else {
          setSignalAlerts(prev => prev.map(alert => 
            alert.id === id ? { ...alert, isActive: !alert.isActive } : alert
          ));
        }
      }
    } catch (err) {
      setError('Failed to toggle alert');
    }
  };

  const deleteAlert = async (type: 'price' | 'signal', id: string) => {
    try {
      const response = await fetch(`${API_BASE}/alerts/${type}/${id}`, {
        method: 'DELETE',
        headers: getAuthHeaders()
      });

      if (response.ok || true) { // Demo: always succeed
        if (type === 'price') {
          setPriceAlerts(prev => prev.filter(alert => alert.id !== id));
        } else {
          setSignalAlerts(prev => prev.filter(alert => alert.id !== id));
        }
      }
    } catch (err) {
      setError('Failed to delete alert');
    }
  };

  const updateNotificationSettings = async () => {
    setLoading(true);
    try {
      const response = await fetch(`${API_BASE}/alerts/settings`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders()
        },
        body: JSON.stringify(notificationSettings)
      });

      if (response.ok || true) { // Demo: always succeed
        setError('Settings updated successfully');
        setTimeout(() => setError(''), 3000);
      }
    } catch (err) {
      setError('Failed to update settings');
    } finally {
      setLoading(false);
    }
  };

  const testNotification = async (method: 'email' | 'sms') => {
    setLoading(true);
    try {
      const response = await fetch(`${API_BASE}/alerts/test`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders()
        },
        body: JSON.stringify({ method })
      });

      if (response.ok || true) { // Demo: always succeed
        setError(`Test ${method} sent successfully!`);
        setTimeout(() => setError(''), 3000);
      }
    } catch (err) {
      setError(`Failed to send test ${method}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAlerts();
    const interval = setInterval(fetchAlerts, 60000); // Refresh every minute
    return () => clearInterval(interval);
  }, [fetchAlerts]);

  const formatDateTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  return (
    <div className="p-3 sm:p-4 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-2 sm:space-y-0">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-gray-800">📢 Smart Alerts</h1>
          <p className="text-sm text-gray-600">Price alerts and AI signal notifications</p>
        </div>
        <button
          onClick={fetchAlerts}
          disabled={loading}
          className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white px-4 py-2 rounded text-sm"
        >
          {loading ? 'Refreshing...' : 'Refresh'}
        </button>
      </div>

      {error && (
        <div className={`p-3 border rounded text-sm ${
          error.includes('success') || error.includes('sent')
            ? 'bg-green-100 border-green-400 text-green-800'
            : 'bg-yellow-100 border-yellow-400 text-yellow-800'
        }`}>
          {error.includes('success') || error.includes('sent') ? '✅' : '⚠️'} {error}
        </div>
      )}

      {/* Tab Navigation */}
      <div className="border-b border-gray-200">
        <nav className="flex space-x-8 overflow-x-auto">
          {[
            { id: 'price', label: 'Price Alerts', icon: '💰' },
            { id: 'signals', label: 'AI Signals', icon: '🤖' },
            { id: 'settings', label: 'Settings', icon: '⚙️' },
            { id: 'history', label: 'History', icon: '📋' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`py-2 px-1 border-b-2 font-medium text-sm whitespace-nowrap ${
                activeTab === tab.id
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              {tab.icon} {tab.label}
            </button>
          ))}
        </nav>
      </div>

      {/* Price Alerts Tab */}
      {activeTab === 'price' && (
        <div className="space-y-6">
          {/* Create New Price Alert */}
          <div className="bg-white border rounded-lg p-4 shadow-sm">
            <h2 className="text-lg font-semibold mb-4">Create Price Alert</h2>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Symbol</label>
                <input
                  type="text"
                  value={newPriceAlert.symbol}
                  onChange={(e) => setNewPriceAlert(prev => ({ ...prev, symbol: e.target.value.toUpperCase() }))}
                  className="w-full p-2 border rounded text-sm"
                  placeholder="e.g., AAPL"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Condition</label>
                <select
                  value={newPriceAlert.condition}
                  onChange={(e) => setNewPriceAlert(prev => ({ ...prev, condition: e.target.value as any }))}
                  className="w-full p-2 border rounded text-sm"
                >
                  <option value="above">Price goes above</option>
                  <option value="below">Price goes below</option>
                  <option value="crosses_above">Crosses above</option>
                  <option value="crosses_below">Crosses below</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Target Price</label>
                <input
                  type="number"
                  step="0.01"
                  value={newPriceAlert.targetPrice}
                  onChange={(e) => setNewPriceAlert(prev => ({ ...prev, targetPrice: e.target.value }))}
                  className="w-full p-2 border rounded text-sm"
                  placeholder="0.00"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Notify via</label>
                <div className="space-y-1">
                  {['email', 'sms', 'push'].map((method) => (
                    <label key={method} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={newPriceAlert.notificationMethod.includes(method as any)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setNewPriceAlert(prev => ({
                              ...prev,
                              notificationMethod: [...prev.notificationMethod, method as any]
                            }));
                          } else {
                            setNewPriceAlert(prev => ({
                              ...prev,
                              notificationMethod: prev.notificationMethod.filter(m => m !== method)
                            }));
                          }
                        }}
                        className="rounded text-blue-600"
                      />
                      <span className="text-sm capitalize">{method}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
            
            <button
              onClick={createPriceAlert}
              disabled={loading || !newPriceAlert.symbol || !newPriceAlert.targetPrice}
              className="bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white px-4 py-2 rounded text-sm"
            >
              Create Alert
            </button>
          </div>

          {/* Active Price Alerts */}
          <div className="bg-white border rounded-lg p-4 shadow-sm">
            <h2 className="text-lg font-semibold mb-4">Active Price Alerts ({priceAlerts.filter(a => a.isActive).length})</h2>
            
            {priceAlerts.length === 0 ? (
              <p className="text-gray-500 text-center py-4">No price alerts created yet</p>
            ) : (
              <div className="space-y-3">
                {priceAlerts.map((alert) => (
                  <div
                    key={alert.id}
                    className={`p-3 border rounded-lg ${
                      alert.isActive ? 'bg-blue-50 border-blue-200' : 'bg-gray-50 border-gray-200'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start space-y-2 sm:space-y-0">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <span className="font-bold text-lg">{alert.symbol}</span>
                          <span className={`px-2 py-1 rounded text-xs font-medium ${
                            alert.isActive ? 'bg-green-600 text-white' : 'bg-gray-600 text-white'
                          }`}>
                            {alert.isActive ? 'Active' : 'Paused'}
                          </span>
                        </div>
                        
                        <div className="mt-2 space-y-1">
                          <p className="text-sm text-gray-700">
                            Alert when price goes <strong>{alert.condition.replace('_', ' ')}</strong> {formatCurrency(alert.targetPrice)}
                          </p>
                          <p className="text-sm text-gray-600">
                            Current: {formatCurrency(alert.currentPrice)} • 
                            Created: {formatDateTime(alert.createdAt)}
                          </p>
                          <div className="flex items-center space-x-2 text-xs text-gray-500">
                            <span>Notify:</span>
                            {alert.notificationMethod.map((method, index) => (
                              <span key={method} className="bg-gray-200 px-1 rounded">
                                {method}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex space-x-2">
                        <button
                          onClick={() => toggleAlert('price', alert.id)}
                          className={`px-3 py-1 rounded text-xs ${
                            alert.isActive
                              ? 'bg-yellow-600 hover:bg-yellow-700 text-white'
                              : 'bg-green-600 hover:bg-green-700 text-white'
                          }`}
                        >
                          {alert.isActive ? 'Pause' : 'Resume'}
                        </button>
                        <button
                          onClick={() => deleteAlert('price', alert.id)}
                          className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded text-xs"
                        >
                          Delete
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* AI Signal Alerts Tab */}
      {activeTab === 'signals' && (
        <div className="space-y-6">
          {/* Create New Signal Alert */}
          <div className="bg-white border rounded-lg p-4 shadow-sm">
            <h2 className="text-lg font-semibold mb-4">Create AI Signal Alert</h2>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Strategy</label>
                <select
                  value={newSignalAlert.strategy}
                  onChange={(e) => setNewSignalAlert(prev => ({ ...prev, strategy: e.target.value }))}
                  className="w-full p-2 border rounded text-sm"
                >
                  <option value="all">All Strategies</option>
                  <option value="momentum">Momentum</option>
                  <option value="swing">Swing Trading</option>
                  <option value="scalp">Scalping</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Symbols (comma-separated)</label>
                <input
                  type="text"
                  value={newSignalAlert.symbols.join(', ')}
                  onChange={(e) => setNewSignalAlert(prev => ({ 
                    ...prev, 
                    symbols: e.target.value.split(',').map(s => s.trim().toUpperCase()).filter(s => s) 
                  }))}
                  className="w-full p-2 border rounded text-sm"
                  placeholder="e.g., AAPL, MSFT, TSLA"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Min Confidence: {newSignalAlert.minConfidence}%
                </label>
                <input
                  type="range"
                  min="50"
                  max="95"
                  value={newSignalAlert.minConfidence}
                  onChange={(e) => setNewSignalAlert(prev => ({ ...prev, minConfidence: parseInt(e.target.value) }))}
                  className="w-full"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Signal Types</label>
                <div className="space-y-1">
                  {['buy', 'sell', 'hold'].map((type) => (
                    <label key={type} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={newSignalAlert.signalTypes.includes(type as any)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setNewSignalAlert(prev => ({
                              ...prev,
                              signalTypes: [...prev.signalTypes, type as any]
                            }));
                          } else {
                            setNewSignalAlert(prev => ({
                              ...prev,
                              signalTypes: prev.signalTypes.filter(t => t !== type)
                            }));
                          }
                        }}
                        className="rounded text-blue-600"
                      />
                      <span className="text-sm capitalize">{type}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">Notification Methods</label>
              <div className="flex space-x-4">
                {['email', 'sms', 'push'].map((method) => (
                  <label key={method} className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={newSignalAlert.notificationMethod.includes(method as any)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setNewSignalAlert(prev => ({
                            ...prev,
                            notificationMethod: [...prev.notificationMethod, method as any]
                          }));
                        } else {
                          setNewSignalAlert(prev => ({
                            ...prev,
                            notificationMethod: prev.notificationMethod.filter(m => m !== method)
                          }));
                        }
                      }}
                      className="rounded text-blue-600"
                    />
                    <span className="text-sm capitalize">{method}</span>
                  </label>
                ))}
              </div>
            </div>
            
            <button
              onClick={createSignalAlert}
              disabled={loading || newSignalAlert.signalTypes.length === 0}
              className="bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white px-4 py-2 rounded text-sm"
            >
              Create Signal Alert
            </button>
          </div>

          {/* Active Signal Alerts */}
          <div className="bg-white border rounded-lg p-4 shadow-sm">
            <h2 className="text-lg font-semibold mb-4">Active AI Signal Alerts ({signalAlerts.filter(a => a.isActive).length})</h2>
            
            {signalAlerts.length === 0 ? (
              <p className="text-gray-500 text-center py-4">No signal alerts created yet</p>
            ) : (
              <div className="space-y-3">
                {signalAlerts.map((alert) => (
                  <div
                    key={alert.id}
                    className={`p-3 border rounded-lg ${
                      alert.isActive ? 'bg-purple-50 border-purple-200' : 'bg-gray-50 border-gray-200'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start space-y-2 sm:space-y-0">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <span className="font-bold text-lg">{alert.strategy === 'all' ? 'All Strategies' : alert.strategy}</span>
                          <span className={`px-2 py-1 rounded text-xs font-medium ${
                            alert.isActive ? 'bg-green-600 text-white' : 'bg-gray-600 text-white'
                          }`}>
                            {alert.isActive ? 'Active' : 'Paused'}
                          </span>
                        </div>
                        
                        <div className="mt-2 space-y-1">
                          <p className="text-sm text-gray-700">
                            Symbols: {alert.symbols.length > 0 ? alert.symbols.join(', ') : 'All symbols'}
                          </p>
                          <p className="text-sm text-gray-700">
                            Min confidence: {alert.minConfidence}% • 
                            Signal types: {alert.signalTypes.join(', ')}
                          </p>
                          <p className="text-sm text-gray-600">
                            Created: {formatDateTime(alert.createdAt)}
                          </p>
                          <div className="flex items-center space-x-2 text-xs text-gray-500">
                            <span>Notify:</span>
                            {alert.notificationMethod.map((method) => (
                              <span key={method} className="bg-gray-200 px-1 rounded">
                                {method}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex space-x-2">
                        <button
                          onClick={() => toggleAlert('signal', alert.id)}
                          className={`px-3 py-1 rounded text-xs ${
                            alert.isActive
                              ? 'bg-yellow-600 hover:bg-yellow-700 text-white'
                              : 'bg-green-600 hover:bg-green-700 text-white'
                          }`}
                        >
                          {alert.isActive ? 'Pause' : 'Resume'}
                        </button>
                        <button
                          onClick={() => deleteAlert('signal', alert.id)}
                          className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded text-xs"
                        >
                          Delete
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Settings Tab */}
      {activeTab === 'settings' && (
        <div className="space-y-6">
          <div className="bg-white border rounded-lg p-4 shadow-sm">
            <h2 className="text-lg font-semibold mb-4">Notification Settings</h2>
            
            <div className="space-y-4">
              {/* Contact Information */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                  <input
                    type="email"
                    value={notificationSettings.email}
                    onChange={(e) => setNotificationSettings(prev => ({ ...prev, email: e.target.value }))}
                    className="w-full p-2 border rounded text-sm"
                    placeholder="your.email@example.com"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
                  <input
                    type="tel"
                    value={notificationSettings.phone}
                    onChange={(e) => setNotificationSettings(prev => ({ ...prev, phone: e.target.value }))}
                    className="w-full p-2 border rounded text-sm"
                    placeholder="+1234567890"
                  />
                </div>
              </div>

              {/* Notification Methods */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Enabled Notification Methods</label>
                <div className="space-y-2">
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={notificationSettings.emailEnabled}
                      onChange={(e) => setNotificationSettings(prev => ({ ...prev, emailEnabled: e.target.checked }))}
                      className="rounded text-blue-600"
                    />
                    <span className="text-sm">📧 Email Notifications</span>
                  </label>
                  
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={notificationSettings.smsEnabled}
                      onChange={(e) => setNotificationSettings(prev => ({ ...prev, smsEnabled: e.target.checked }))}
                      className="rounded text-blue-600"
                    />
                    <span className="text-sm">📱 SMS Notifications</span>
                  </label>
                  
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={notificationSettings.pushEnabled}
                      onChange={(e) => setNotificationSettings(prev => ({ ...prev, pushEnabled: e.target.checked }))}
                      className="rounded text-blue-600"
                    />
                    <span className="text-sm">🔔 Push Notifications</span>
                  </label>
                </div>
              </div>

              {/* Quiet Hours */}
              <div>
                <label className="flex items-center space-x-2 mb-2">
                  <input
                    type="checkbox"
                    checked={notificationSettings.quietHours.enabled}
                    onChange={(e) => setNotificationSettings(prev => ({ 
                      ...prev, 
                      quietHours: { ...prev.quietHours, enabled: e.target.checked }
                    }))}
                    className="rounded text-blue-600"
                  />
                  <span className="text-sm font-medium text-gray-700">🌙 Enable Quiet Hours</span>
                </label>
                
                {notificationSettings.quietHours.enabled && (
                  <div className="grid grid-cols-2 gap-4 ml-6">
                    <div>
                      <label className="block text-xs text-gray-600 mb-1">Start Time</label>
                      <input
                        type="time"
                        value={notificationSettings.quietHours.start}
                        onChange={(e) => setNotificationSettings(prev => ({ 
                          ...prev, 
                          quietHours: { ...prev.quietHours, start: e.target.value }
                        }))}
                        className="w-full p-2 border rounded text-sm"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-xs text-gray-600 mb-1">End Time</label>
                      <input
                        type="time"
                        value={notificationSettings.quietHours.end}
                        onChange={(e) => setNotificationSettings(prev => ({ 
                          ...prev, 
                          quietHours: { ...prev.quietHours, end: e.target.value }
                        }))}
                        className="w-full p-2 border rounded text-sm"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4">
                <button
                  onClick={updateNotificationSettings}
                  disabled={loading}
                  className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white px-4 py-2 rounded text-sm"
                >
                  {loading ? 'Saving...' : 'Save Settings'}
                </button>
                
                <button
                  onClick={() => testNotification('email')}
                  disabled={loading || !notificationSettings.email}
                  className="bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white px-4 py-2 rounded text-sm"
                >
                  Test Email
                </button>
                
                <button
                  onClick={() => testNotification('sms')}
                  disabled={loading || !notificationSettings.phone}
                  className="bg-purple-600 hover:bg-purple-700 disabled:bg-gray-400 text-white px-4 py-2 rounded text-sm"
                >
                  Test SMS
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* History Tab */}
      {activeTab === 'history' && (
        <div className="bg-white border rounded-lg p-4 shadow-sm">
          <h2 className="text-lg font-semibold mb-4">Alert History</h2>
          
          {alertHistory.length === 0 ? (
            <p className="text-gray-500 text-center py-4">No alert history yet</p>
          ) : (
            <div className="space-y-3">
              {alertHistory.map((item) => (
                <div
                  key={item.id}
                  className={`p-3 border rounded-lg ${
                    item.status === 'sent' ? 'bg-green-50 border-green-200' :
                    item.status === 'failed' ? 'bg-red-50 border-red-200' :
                    'bg-yellow-50 border-yellow-200'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start space-y-2 sm:space-y-0">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2">
                        <span className={`px-2 py-1 rounded text-xs font-medium ${
                          item.type === 'price' ? 'bg-blue-600 text-white' : 'bg-purple-600 text-white'
                        }`}>
                          {item.type === 'price' ? '💰 Price' : '🤖 Signal'}
                        </span>
                        <span className={`px-2 py-1 rounded text-xs font-medium ${
                          item.status === 'sent' ? 'bg-green-600 text-white' :
                          item.status === 'failed' ? 'bg-red-600 text-white' :
                          'bg-yellow-600 text-white'
                        }`}>
                          {item.status === 'sent' ? '✅ Sent' :
                           item.status === 'failed' ? '❌ Failed' :
                           '⏳ Pending'}
                        </span>
                      </div>
                      
                      <h3 className="font-medium mt-2">{item.title}</h3>
                      <p className="text-sm text-gray-700 mt-1">{item.message}</p>
                      
                      <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                        <span>{formatDateTime(item.timestamp)}</span>
                        <span>Via: {item.methods.join(', ')}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default AlertsManager;
