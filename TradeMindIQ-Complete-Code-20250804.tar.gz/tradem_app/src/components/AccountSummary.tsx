import React, { useEffect, useState, useCallback } from 'react';
import { API_BASE } from '../config';
import { useAuth } from '../contexts/AuthContext';

interface AccountData {
  balance: number;
  buyingPower: number;
  netPnL: number;
  openOrders: number;
  totalValue: number;
  dayChange: number;
  dayChangePercent: number;
}

const AccountSummary: React.FC = () => {
  const { getAuthHeaders } = useAuth();
  const [accountData, setAccountData] = useState<AccountData>({
    balance: 0,
    buyingPower: 0,
    netPnL: 0,
    openOrders: 0,
    totalValue: 0,
    dayChange: 0,
    dayChangePercent: 0
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  const fetchAccountData = useCallback(async () => {
    try {
      const response = await fetch(`${API_BASE}/account`, {
        headers: {
          ...getAuthHeaders()
        }
      });
      const data = await response.json();
      
      if (response.ok) {
        setAccountData(data);
        setLastUpdated(new Date());
        setError('');
      } else {
        setError(data.message || 'Failed to fetch account data');
      }
    } catch (err) {
      setError('Unable to fetch account data. Check your connection.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchAccountData();
    
    // Set up interval to refresh every 30 seconds
    const interval = setInterval(fetchAccountData, 30000);
    
    return () => clearInterval(interval);
  }, [fetchAccountData]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const formatPercentage = (percentage: number) => {
    return `${percentage >= 0 ? '+' : ''}${percentage.toFixed(2)}%`;
  };

  const formatLastUpdated = (date: Date | null) => {
    if (!date) return '';
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  if (loading) {
    return (
      <div className="p-3 sm:p-4 border rounded shadow bg-white">
        <h2 className="text-lg sm:text-xl font-bold mb-3">💰 Account Summary</h2>
        <div className="text-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-2"></div>
          <p className="text-sm text-gray-600">Loading account data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-3 sm:p-4 border rounded shadow bg-white">
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-4 space-y-2 sm:space-y-0">
        <div>
          <h2 className="text-lg sm:text-xl font-bold">💰 Account Summary</h2>
          {lastUpdated && (
            <p className="text-xs text-gray-500">
              Last updated: {formatLastUpdated(lastUpdated)}
            </p>
          )}
        </div>
        <button
          onClick={fetchAccountData}
          className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded text-sm w-full sm:w-auto"
        >
          Refresh
        </button>
      </div>

      {error && (
        <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded text-sm">
          ❌ {error}
        </div>
      )}

      {/* Account Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-gray-50 p-3 rounded">
          <h3 className="text-xs sm:text-sm font-medium text-gray-600">Total Value</h3>
          <p className="text-base sm:text-lg font-bold text-gray-900">
            {formatCurrency(accountData.totalValue)}
          </p>
        </div>
        
        <div className="bg-gray-50 p-3 rounded">
          <h3 className="text-xs sm:text-sm font-medium text-gray-600">Balance</h3>
          <p className="text-base sm:text-lg font-bold text-gray-900">
            {formatCurrency(accountData.balance)}
          </p>
        </div>
        
        <div className="bg-gray-50 p-3 rounded">
          <h3 className="text-xs sm:text-sm font-medium text-gray-600">Buying Power</h3>
          <p className="text-base sm:text-lg font-bold text-green-600">
            {formatCurrency(accountData.buyingPower)}
          </p>
        </div>
        
        <div className="bg-gray-50 p-3 rounded">
          <h3 className="text-xs sm:text-sm font-medium text-gray-600">Net P&L</h3>
          <p className={`text-base sm:text-lg font-bold ${accountData.netPnL >= 0 ? 'text-green-600' : 'text-red-600'}`}>
            {formatCurrency(accountData.netPnL)}
          </p>
        </div>
        
        <div className="bg-gray-50 p-3 rounded">
          <h3 className="text-xs sm:text-sm font-medium text-gray-600">Day Change</h3>
          <p className={`text-base sm:text-lg font-bold ${accountData.dayChange >= 0 ? 'text-green-600' : 'text-red-600'}`}>
            {formatCurrency(accountData.dayChange)}
          </p>
          <p className={`text-xs ${accountData.dayChangePercent >= 0 ? 'text-green-600' : 'text-red-600'}`}>
            {formatPercentage(accountData.dayChangePercent)}
          </p>
        </div>
        
        <div className="bg-gray-50 p-3 rounded">
          <h3 className="text-xs sm:text-sm font-medium text-gray-600">Open Orders</h3>
          <p className="text-base sm:text-lg font-bold text-blue-600">
            {accountData.openOrders}
          </p>
        </div>
      </div>
    </div>
  );
};

export default AccountSummary;
