import React, { useEffect, useState, useCallback } from 'react';
import { API_BASE } from '../config';
import { useAuth } from '../contexts/AuthContext';

interface Position {
  symbol: string;
  shares: number;
  avgCost: number;
  currentPrice: number;
  marketValue: number;
  pnl: number;
  pnlPercent: number;
}

const Portfolio: React.FC = () => {
  const { getAuthHeaders } = useAuth();
  const [positions, setPositions] = useState<Position[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [totalValue, setTotalValue] = useState(0);
  const [totalPnL, setTotalPnL] = useState(0);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  const fetchPortfolio = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const response = await fetch(`${API_BASE}/portfolio`, {
        headers: {
          ...getAuthHeaders()
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setPositions(data.positions || []);
        setTotalValue(data.totalValue || 0);
        setTotalPnL(data.totalPnL || 0);
        setLastUpdated(new Date());
      } else {
        // Demo data fallback
        const demoPositions = [
          {
            symbol: 'AAPL',
            shares: 10,
            avgCost: 170.50,
            currentPrice: 175.25,
            marketValue: 1752.50,
            pnl: 47.50,
            pnlPercent: 2.78
          },
          {
            symbol: 'TSLA',
            shares: 5,
            avgCost: 245.00,
            currentPrice: 238.75,
            marketValue: 1193.75,
            pnl: -31.25,
            pnlPercent: -2.55
          }
        ];
        setPositions(demoPositions);
        setTotalValue(2946.25);
        setTotalPnL(16.25);
        setLastUpdated(new Date());
      }
    } catch (err) {
      setError('Unable to fetch portfolio. Using demo data.');
      // Demo data fallback
      const demoPositions = [
        {
          symbol: 'AAPL',
          shares: 10,
          avgCost: 170.50,
          currentPrice: 175.25,
          marketValue: 1752.50,
          pnl: 47.50,
          pnlPercent: 2.78
        }
      ];
      setPositions(demoPositions);
      setTotalValue(1752.50);
      setTotalPnL(47.50);
      setLastUpdated(new Date());
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchPortfolio();
    
    // Set up interval to refresh portfolio every 60 seconds
    const interval = setInterval(() => {
      fetchPortfolio();
    }, 60000);
    
    return () => clearInterval(interval);
  }, [fetchPortfolio]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const formatPercentage = (percentage: number) => {
    return `${percentage >= 0 ? '+' : ''}${percentage.toFixed(2)}%`;
  };

  const formatLastUpdated = (date: Date | null) => {
    if (!date) return '';
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  if (loading) {
    return (
      <div className="p-3 sm:p-4 border rounded shadow bg-white">
        <h2 className="text-lg sm:text-xl font-bold mb-3">📊 Portfolio</h2>
        <div className="text-center py-8">
          <p>Loading portfolio...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-3 sm:p-4 border rounded shadow bg-white">
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-4 space-y-2 sm:space-y-0">
        <div>
          <h2 className="text-lg sm:text-xl font-bold">📊 Portfolio</h2>
          {lastUpdated && (
            <p className="text-xs text-gray-500">
              Last updated: {formatLastUpdated(lastUpdated)}
            </p>
          )}
        </div>
        <button
          onClick={fetchPortfolio}
          className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded text-sm w-full sm:w-auto"
        >
          Refresh
        </button>
      </div>

      {error && (
        <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded text-sm">
          ❌ {error}
        </div>
      )}

      {/* Portfolio Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4 mb-4 sm:mb-6">
        <div className="bg-gray-50 p-3 rounded">
          <h3 className="text-sm font-medium text-gray-600">Total Value</h3>
          <p className="text-base sm:text-lg font-bold">{formatCurrency(totalValue)}</p>
        </div>
        <div className="bg-gray-50 p-3 rounded">
          <h3 className="text-sm font-medium text-gray-600">Total P&L</h3>
          <p className={`text-base sm:text-lg font-bold ${totalPnL >= 0 ? 'text-green-600' : 'text-red-600'}`}>
            {formatCurrency(totalPnL)}
          </p>
        </div>
        <div className="bg-gray-50 p-3 rounded">
          <h3 className="text-sm font-medium text-gray-600">Positions</h3>
          <p className="text-base sm:text-lg font-bold">{positions.length}</p>
        </div>
      </div>

      {/* Positions Table/Cards */}
      {positions.length > 0 ? (
        <>
          {/* Desktop Table */}
          <div className="hidden sm:block overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-gray-50">
                  <th className="text-left p-2">Symbol</th>
                  <th className="text-right p-2">Shares</th>
                  <th className="text-right p-2">Avg Cost</th>
                  <th className="text-right p-2">Current Price</th>
                  <th className="text-right p-2">Market Value</th>
                  <th className="text-right p-2">P&L</th>
                  <th className="text-right p-2">P&L %</th>
                </tr>
              </thead>
              <tbody>
                {positions.map((position, index) => (
                  <tr key={index} className="border-b hover:bg-gray-50">
                    <td className="p-2 font-medium">{position.symbol}</td>
                    <td className="p-2 text-right">{position.shares}</td>
                    <td className="p-2 text-right">{formatCurrency(position.avgCost)}</td>
                    <td className="p-2 text-right">{formatCurrency(position.currentPrice)}</td>
                    <td className="p-2 text-right">{formatCurrency(position.marketValue)}</td>
                    <td className={`p-2 text-right ${position.pnl >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {formatCurrency(position.pnl)}
                    </td>
                    <td className={`p-2 text-right ${position.pnlPercent >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {formatPercentage(position.pnlPercent)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile Cards */}
          <div className="sm:hidden space-y-3">
            {positions.map((position, index) => (
              <div key={index} className="bg-gray-50 rounded-lg p-3 border">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="font-bold text-lg">{position.symbol}</h3>
                    <p className="text-sm text-gray-600">{position.shares} shares</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">{formatCurrency(position.marketValue)}</p>
                    <p className={`text-sm ${position.pnl >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {formatCurrency(position.pnl)} ({formatPercentage(position.pnlPercent)})
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <span className="text-gray-600">Avg Cost:</span>
                    <span className="ml-1 font-medium">{formatCurrency(position.avgCost)}</span>
                  </div>
                  <div>
                    <span className="text-gray-600">Current:</span>
                    <span className="ml-1 font-medium">{formatCurrency(position.currentPrice)}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </>
      ) : (
        <div className="text-center py-8 text-gray-500">
          <p>No positions found</p>
          <p className="text-sm">Start trading to see your portfolio here</p>
        </div>
      )}
    </div>
  );
};

export default Portfolio;
