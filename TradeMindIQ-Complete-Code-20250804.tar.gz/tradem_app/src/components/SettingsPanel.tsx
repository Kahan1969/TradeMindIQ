import React, { useState, useEffect, useCallback } from 'react';
import { API_BASE } from '../config';
import { useAuth } from '../contexts/AuthContext';

interface UserPreferences {
  general: {
    theme: 'light' | 'dark' | 'auto';
    timezone: string;
    autoRefreshInterval: number; // in seconds
    defaultSymbols: string[];
    currency: 'USD' | 'EUR' | 'GBP';
    dateFormat: 'MM/DD/YYYY' | 'DD/MM/YYYY' | 'YYYY-MM-DD';
  };
  trading: {
    defaultStrategy: string;
    riskLevel: 'conservative' | 'moderate' | 'aggressive';
    autoSaveEnabled: boolean;
    confirmTrades: boolean;
  };
  notifications: {
    emailEnabled: boolean;
    smsEnabled: boolean;
    pushEnabled: boolean;
    soundEnabled: boolean;
    quietHours: {
      enabled: boolean;
      startTime: string;
      endTime: string;
    };
  };
  display: {
    compactMode: boolean;
    showPercentages: boolean;
    hideSmallBalances: boolean;
    animationsEnabled: boolean;
  };
}

const defaultPreferences: UserPreferences = {
  general: {
    theme: 'light',
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    autoRefreshInterval: 30,
    defaultSymbols: ['AAPL', 'TSLA', 'MSFT'],
    currency: 'USD',
    dateFormat: 'MM/DD/YYYY'
  },
  trading: {
    defaultStrategy: 'momentum',
    riskLevel: 'moderate',
    autoSaveEnabled: true,
    confirmTrades: true
  },
  notifications: {
    emailEnabled: true,
    smsEnabled: false,
    pushEnabled: true,
    soundEnabled: true,
    quietHours: {
      enabled: false,
      startTime: '22:00',
      endTime: '08:00'
    }
  },
  display: {
    compactMode: false,
    showPercentages: true,
    hideSmallBalances: false,
    animationsEnabled: true
  }
};

const AVAILABLE_SYMBOLS = [
  'AAPL', 'MSFT', 'GOOGL', 'AMZN', 'TSLA', 'NVDA', 'META', 'NFLX',
  'AMD', 'INTC', 'CRM', 'ORCL', 'ADBE', 'NOW', 'PYPL', 'SHOP',
  'SQ', 'ZOOM', 'DOCU', 'TWLO', 'OKTA', 'SNOW', 'PLTR', 'COIN'
];

const TIMEZONE_OPTIONS = [
  'America/New_York',
  'America/Chicago', 
  'America/Denver',
  'America/Los_Angeles',
  'Europe/London',
  'Europe/Paris',
  'Europe/Berlin',
  'Asia/Tokyo',
  'Asia/Shanghai',
  'Asia/Singapore',
  'Australia/Sydney'
];

const SettingsPanel: React.FC = () => {
  const { getAuthHeaders } = useAuth();
  const [preferences, setPreferences] = useState<UserPreferences>(defaultPreferences);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [activeTab, setActiveTab] = useState<'general' | 'trading' | 'notifications' | 'display'>('general');
  const [isDarkMode, setIsDarkMode] = useState(false);

  // Apply theme changes immediately
  useEffect(() => {
    const applyTheme = () => {
      if (preferences.general.theme === 'dark' || 
          (preferences.general.theme === 'auto' && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
        document.documentElement.classList.add('dark');
        setIsDarkMode(true);
      } else {
        document.documentElement.classList.remove('dark');
        setIsDarkMode(false);
      }
    };

    applyTheme();

    // Listen for system theme changes when auto mode is enabled
    if (preferences.general.theme === 'auto') {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      mediaQuery.addEventListener('change', applyTheme);
      return () => mediaQuery.removeEventListener('change', applyTheme);
    }
  }, [preferences.general.theme]);

  const fetchPreferences = useCallback(async () => {
    setLoading(true);
    try {
      const response = await fetch(`${API_BASE}/user/preferences`, {
        headers: getAuthHeaders()
      });

      if (response.ok) {
        const data = await response.json();
        setPreferences({ ...defaultPreferences, ...data });
      } else {
        // Use default preferences if API fails
        setPreferences(defaultPreferences);
        setError('Using default preferences - backend not connected');
      }
    } catch (err) {
      setError('Failed to load preferences');
      setPreferences(defaultPreferences);
      console.error('Preferences fetch error:', err);
    } finally {
      setLoading(false);
    }
  }, [getAuthHeaders]);

  const savePreferences = async () => {
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      const response = await fetch(`${API_BASE}/user/preferences`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders()
        },
        body: JSON.stringify(preferences)
      });

      if (response.ok) {
        setSuccess('Preferences saved successfully!');
        // Apply auto-refresh interval
        if (preferences.general.autoRefreshInterval > 0) {
          localStorage.setItem('autoRefreshInterval', preferences.general.autoRefreshInterval.toString());
        }
      } else {
        // Demo mode - save to localStorage
        localStorage.setItem('userPreferences', JSON.stringify(preferences));
        setSuccess('Preferences saved locally (demo mode)');
      }
    } catch (err) {
      setError('Failed to save preferences');
      console.error('Save preferences error:', err);
    } finally {
      setLoading(false);
      setTimeout(() => {
        setSuccess('');
        setError('');
      }, 3000);
    }
  };

  const resetToDefaults = () => {
    setPreferences(defaultPreferences);
    setSuccess('Reset to default preferences');
    setTimeout(() => setSuccess(''), 3000);
  };

  const updatePreference = (section: keyof UserPreferences, key: string, value: any) => {
    setPreferences(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [key]: value
      }
    }));
  };

  const updateNestedPreference = (section: keyof UserPreferences, parentKey: string, key: string, value: any) => {
    setPreferences(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [parentKey]: {
          ...(prev[section] as any)[parentKey],
          [key]: value
        }
      }
    }));
  };

  const toggleSymbol = (symbol: string) => {
    const currentSymbols = preferences.general.defaultSymbols;
    if (currentSymbols.includes(symbol)) {
      updatePreference('general', 'defaultSymbols', currentSymbols.filter(s => s !== symbol));
    } else {
      updatePreference('general', 'defaultSymbols', [...currentSymbols, symbol]);
    }
  };

  useEffect(() => {
    fetchPreferences();
  }, [fetchPreferences]);

  const TabButton: React.FC<{ tab: string; label: string; icon: string }> = ({ tab, label, icon }) => (
    <button
      onClick={() => setActiveTab(tab as any)}
      className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
        activeTab === tab
          ? 'bg-blue-600 text-white'
          : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
      }`}
    >
      <span>{icon}</span>
      <span>{label}</span>
    </button>
  );

  return (
    <div className={`p-3 sm:p-4 space-y-6 ${isDarkMode ? 'dark bg-gray-900 text-white' : 'bg-gray-50'}`}>
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-2 sm:space-y-0">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-gray-800 dark:text-white">⚙️ Settings & Preferences</h1>
          <p className="text-sm text-gray-600 dark:text-gray-400">Customize your TradeMindIQ experience</p>
        </div>
        <div className="flex space-x-2">
          <button
            onClick={resetToDefaults}
            className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded text-sm"
          >
            Reset Defaults
          </button>
          <button
            onClick={savePreferences}
            disabled={loading}
            className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white px-4 py-2 rounded text-sm"
          >
            {loading ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </div>

      {/* Status Messages */}
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-800 p-3 rounded text-sm">
          ⚠️ {error}
        </div>
      )}

      {success && (
        <div className="bg-green-100 border border-green-400 text-green-800 p-3 rounded text-sm">
          ✅ {success}
        </div>
      )}

      {/* Tabs */}
      <div className="flex flex-wrap gap-2">
        <TabButton tab="general" label="General" icon="🔧" />
        <TabButton tab="trading" label="Trading" icon="📈" />
        <TabButton tab="notifications" label="Notifications" icon="🔔" />
        <TabButton tab="display" label="Display" icon="🎨" />
      </div>

      {/* General Settings */}
      {activeTab === 'general' && (
        <div className="bg-white dark:bg-gray-800 border rounded-lg p-4 shadow-sm space-y-6">
          <h2 className="text-lg font-semibold mb-4">🔧 General Settings</h2>

          {/* Theme */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">🎨 Theme</label>
            <select
              value={preferences.general.theme}
              onChange={(e) => updatePreference('general', 'theme', e.target.value)}
              className="w-full p-2 border rounded text-sm dark:bg-gray-700 dark:border-gray-600"
            >
              <option value="light">☀️ Light</option>
              <option value="dark">🌙 Dark</option>
              <option value="auto">⚡ Auto (System)</option>
            </select>
          </div>

          {/* Timezone */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">🌍 Timezone</label>
            <select
              value={preferences.general.timezone}
              onChange={(e) => updatePreference('general', 'timezone', e.target.value)}
              className="w-full p-2 border rounded text-sm dark:bg-gray-700 dark:border-gray-600"
            >
              {TIMEZONE_OPTIONS.map(tz => (
                <option key={tz} value={tz}>{tz.replace('_', ' ')}</option>
              ))}
            </select>
            <p className="text-xs text-gray-500 mt-1">
              Current time: {new Date().toLocaleString('en-US', { timeZone: preferences.general.timezone })}
            </p>
          </div>

          {/* Auto-Refresh Interval */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              🔄 Auto-Refresh Interval ({preferences.general.autoRefreshInterval}s)
            </label>
            <input
              type="range"
              min="5"
              max="300"
              step="5"
              value={preferences.general.autoRefreshInterval}
              onChange={(e) => updatePreference('general', 'autoRefreshInterval', parseInt(e.target.value))}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-gray-500 mt-1">
              <span>5s</span>
              <span>Real-time</span>
              <span>5min</span>
            </div>
          </div>

          {/* Default Symbols */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              📊 Default Symbols ({preferences.general.defaultSymbols.length}/10)
            </label>
            <div className="grid grid-cols-4 sm:grid-cols-6 lg:grid-cols-8 gap-2 max-h-40 overflow-y-auto">
              {AVAILABLE_SYMBOLS.map(symbol => (
                <button
                  key={symbol}
                  onClick={() => toggleSymbol(symbol)}
                  disabled={!preferences.general.defaultSymbols.includes(symbol) && preferences.general.defaultSymbols.length >= 10}
                  className={`p-2 text-xs rounded border transition-colors ${
                    preferences.general.defaultSymbols.includes(symbol)
                      ? 'bg-blue-600 text-white border-blue-600'
                      : 'bg-gray-100 hover:bg-gray-200 text-gray-700 border-gray-300 disabled:opacity-50'
                  }`}
                >
                  {symbol}
                </button>
              ))}
            </div>
            <p className="text-xs text-gray-500 mt-1">
              Selected: {preferences.general.defaultSymbols.join(', ') || 'None'}
            </p>
          </div>

          {/* Currency & Date Format */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">💰 Currency</label>
              <select
                value={preferences.general.currency}
                onChange={(e) => updatePreference('general', 'currency', e.target.value)}
                className="w-full p-2 border rounded text-sm dark:bg-gray-700 dark:border-gray-600"
              >
                <option value="USD">🇺🇸 USD</option>
                <option value="EUR">🇪🇺 EUR</option>
                <option value="GBP">🇬🇧 GBP</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">📅 Date Format</label>
              <select
                value={preferences.general.dateFormat}
                onChange={(e) => updatePreference('general', 'dateFormat', e.target.value)}
                className="w-full p-2 border rounded text-sm dark:bg-gray-700 dark:border-gray-600"
              >
                <option value="MM/DD/YYYY">MM/DD/YYYY (US)</option>
                <option value="DD/MM/YYYY">DD/MM/YYYY (EU)</option>
                <option value="YYYY-MM-DD">YYYY-MM-DD (ISO)</option>
              </select>
            </div>
          </div>
        </div>
      )}

      {/* Trading Settings */}
      {activeTab === 'trading' && (
        <div className="bg-white dark:bg-gray-800 border rounded-lg p-4 shadow-sm space-y-6">
          <h2 className="text-lg font-semibold mb-4">📈 Trading Settings</h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">🎯 Default Strategy</label>
              <select
                value={preferences.trading.defaultStrategy}
                onChange={(e) => updatePreference('trading', 'defaultStrategy', e.target.value)}
                className="w-full p-2 border rounded text-sm dark:bg-gray-700 dark:border-gray-600"
              >
                <option value="momentum">🚀 Momentum</option>
                <option value="swing">🌊 Swing</option>
                <option value="scalp">⚡ Scalp</option>
                <option value="position">📊 Position</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">⚖️ Risk Level</label>
              <select
                value={preferences.trading.riskLevel}
                onChange={(e) => updatePreference('trading', 'riskLevel', e.target.value)}
                className="w-full p-2 border rounded text-sm dark:bg-gray-700 dark:border-gray-600"
              >
                <option value="conservative">🛡️ Conservative</option>
                <option value="moderate">⚖️ Moderate</option>
                <option value="aggressive">🔥 Aggressive</option>
              </select>
            </div>
          </div>

          <div className="space-y-3">
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={preferences.trading.autoSaveEnabled}
                onChange={(e) => updatePreference('trading', 'autoSaveEnabled', e.target.checked)}
                className="rounded text-blue-600"
              />
              <span className="text-sm">💾 Auto-save trading settings</span>
            </label>

            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={preferences.trading.confirmTrades}
                onChange={(e) => updatePreference('trading', 'confirmTrades', e.target.checked)}
                className="rounded text-blue-600"
              />
              <span className="text-sm">✅ Confirm trades before execution</span>
            </label>
          </div>
        </div>
      )}

      {/* Notification Settings */}
      {activeTab === 'notifications' && (
        <div className="bg-white dark:bg-gray-800 border rounded-lg p-4 shadow-sm space-y-6">
          <h2 className="text-lg font-semibold mb-4">🔔 Notification Settings</h2>

          <div className="space-y-3">
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={preferences.notifications.emailEnabled}
                onChange={(e) => updatePreference('notifications', 'emailEnabled', e.target.checked)}
                className="rounded text-blue-600"
              />
              <span className="text-sm">📧 Email notifications</span>
            </label>

            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={preferences.notifications.smsEnabled}
                onChange={(e) => updatePreference('notifications', 'smsEnabled', e.target.checked)}
                className="rounded text-blue-600"
              />
              <span className="text-sm">📱 SMS notifications</span>
            </label>

            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={preferences.notifications.pushEnabled}
                onChange={(e) => updatePreference('notifications', 'pushEnabled', e.target.checked)}
                className="rounded text-blue-600"
              />
              <span className="text-sm">🔔 Push notifications</span>
            </label>

            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={preferences.notifications.soundEnabled}
                onChange={(e) => updatePreference('notifications', 'soundEnabled', e.target.checked)}
                className="rounded text-blue-600"
              />
              <span className="text-sm">🔊 Sound alerts</span>
            </label>
          </div>

          {/* Quiet Hours */}
          <div className="border-t pt-4">
            <label className="flex items-center space-x-2 mb-3">
              <input
                type="checkbox"
                checked={preferences.notifications.quietHours.enabled}
                onChange={(e) => updateNestedPreference('notifications', 'quietHours', 'enabled', e.target.checked)}
                className="rounded text-blue-600"
              />
              <span className="text-sm font-medium">🌙 Quiet Hours</span>
            </label>

            {preferences.notifications.quietHours.enabled && (
              <div className="grid grid-cols-2 gap-4 ml-6">
                <div>
                  <label className="block text-xs text-gray-600 dark:text-gray-400 mb-1">Start Time</label>
                  <input
                    type="time"
                    value={preferences.notifications.quietHours.startTime}
                    onChange={(e) => updateNestedPreference('notifications', 'quietHours', 'startTime', e.target.value)}
                    className="w-full p-2 border rounded text-sm dark:bg-gray-700 dark:border-gray-600"
                  />
                </div>
                <div>
                  <label className="block text-xs text-gray-600 dark:text-gray-400 mb-1">End Time</label>
                  <input
                    type="time"
                    value={preferences.notifications.quietHours.endTime}
                    onChange={(e) => updateNestedPreference('notifications', 'quietHours', 'endTime', e.target.value)}
                    className="w-full p-2 border rounded text-sm dark:bg-gray-700 dark:border-gray-600"
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Display Settings */}
      {activeTab === 'display' && (
        <div className="bg-white dark:bg-gray-800 border rounded-lg p-4 shadow-sm space-y-6">
          <h2 className="text-lg font-semibold mb-4">🎨 Display Settings</h2>

          <div className="space-y-3">
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={preferences.display.compactMode}
                onChange={(e) => updatePreference('display', 'compactMode', e.target.checked)}
                className="rounded text-blue-600"
              />
              <span className="text-sm">📱 Compact mode (mobile-friendly)</span>
            </label>

            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={preferences.display.showPercentages}
                onChange={(e) => updatePreference('display', 'showPercentages', e.target.checked)}
                className="rounded text-blue-600"
              />
              <span className="text-sm">📊 Show percentage changes</span>
            </label>

            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={preferences.display.hideSmallBalances}
                onChange={(e) => updatePreference('display', 'hideSmallBalances', e.target.checked)}
                className="rounded text-blue-600"
              />
              <span className="text-sm">👁️ Hide small balances (&lt;$10)</span>
            </label>

            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={preferences.display.animationsEnabled}
                onChange={(e) => updatePreference('display', 'animationsEnabled', e.target.checked)}
                className="rounded text-blue-600"
              />
              <span className="text-sm">✨ Enable animations</span>
            </label>
          </div>
        </div>
      )}

      {/* Current Settings Summary */}
      <div className="bg-blue-50 dark:bg-blue-900 border border-blue-200 dark:border-blue-700 rounded-lg p-4">
        <h3 className="text-sm font-semibold text-blue-800 dark:text-blue-200 mb-2">📋 Current Settings Summary</h3>
        <div className="text-xs text-blue-700 dark:text-blue-300 space-y-1">
          <p>🎨 Theme: {preferences.general.theme} | 🌍 Timezone: {preferences.general.timezone.split('/')[1]}</p>
          <p>🔄 Refresh: {preferences.general.autoRefreshInterval}s | 📊 Symbols: {preferences.general.defaultSymbols.length}</p>
          <p>📈 Strategy: {preferences.trading.defaultStrategy} | ⚖️ Risk: {preferences.trading.riskLevel}</p>
          <p>🔔 Notifications: {[preferences.notifications.emailEnabled && 'Email', preferences.notifications.smsEnabled && 'SMS', preferences.notifications.pushEnabled && 'Push'].filter(Boolean).join(', ') || 'None'}</p>
        </div>
      </div>
    </div>
  );
};

export default SettingsPanel;
