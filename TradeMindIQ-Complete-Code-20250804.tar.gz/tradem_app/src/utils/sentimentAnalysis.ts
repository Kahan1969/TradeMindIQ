/**
 * Advanced Sentiment Analysis Utilities for Trading Strategies
 */

export interface SentimentAnalysis {
  score: number; // -1 to 1, where -1 is very negative, 1 is very positive
  magnitude: number; // 0 to 1, how strongly the sentiment is expressed
  confidence: number; // 0 to 1, confidence in the analysis
  keywords: string[];
  category: 'earnings' | 'regulatory' | 'market' | 'company' | 'economic';
}

export interface MarketSentiment {
  overall: number;
  bullish: number;
  bearish: number;
  neutral: number;
  volatility: number;
  trend: 'bullish' | 'bearish' | 'sideways';
}

/**
 * Analyzes sentiment from news text
 */
export const analyzeSentiment = (text: string): SentimentAnalysis => {
  const positiveWords = [
    'growth', 'profit', 'gain', 'increase', 'up', 'bull', 'positive', 'strong',
    'beat', 'exceed', 'outperform', 'rally', 'surge', 'climb', 'rise', 'boost',
    'breakthrough', 'success', 'record', 'milestone', 'expansion', 'upgrade'
  ];

  const negativeWords = [
    'loss', 'decline', 'fall', 'drop', 'down', 'bear', 'negative', 'weak',
    'miss', 'underperform', 'crash', 'plunge', 'tumble', 'collapse', 'concern',
    'risk', 'threat', 'crisis', 'recession', 'bankruptcy', 'downgrade', 'cut'
  ];

  const earningsWords = ['earnings', 'revenue', 'profit', 'eps', 'guidance', 'outlook'];
  const regulatoryWords = ['regulation', 'fda', 'sec', 'antitrust', 'compliance'];
  const marketWords = ['market', 'index', 'sector', 'industry', 'benchmark'];

  const words = text.toLowerCase().split(/\s+/);
  let positiveCount = 0;
  let negativeCount = 0;
  let totalWords = words.length;
  const foundKeywords: string[] = [];

  // Count sentiment words
  words.forEach(word => {
    if (positiveWords.includes(word)) {
      positiveCount++;
      foundKeywords.push(word);
    }
    if (negativeWords.includes(word)) {
      negativeCount++;
      foundKeywords.push(word);
    }
  });

  // Calculate sentiment score
  const sentimentDiff = positiveCount - negativeCount;
  const sentimentTotal = positiveCount + negativeCount;
  const score = sentimentTotal > 0 ? sentimentDiff / sentimentTotal : 0;
  
  // Calculate magnitude (how much sentiment is present)
  const magnitude = Math.min(sentimentTotal / Math.max(totalWords * 0.1, 1), 1);
  
  // Calculate confidence based on sentiment word density
  const confidence = Math.min(sentimentTotal / Math.max(totalWords * 0.05, 1), 1);

  // Determine category
  let category: SentimentAnalysis['category'] = 'market';
  if (earningsWords.some(word => text.toLowerCase().includes(word))) {
    category = 'earnings';
  } else if (regulatoryWords.some(word => text.toLowerCase().includes(word))) {
    category = 'regulatory';
  } else if (marketWords.some(word => text.toLowerCase().includes(word))) {
    category = 'market';
  } else {
    category = 'company';
  }

  return {
    score: Math.max(-1, Math.min(1, score)),
    magnitude,
    confidence,
    keywords: foundKeywords,
    category
  };
};

/**
 * Aggregates multiple sentiment analyses into overall market sentiment
 */
export const aggregateMarketSentiment = (sentiments: SentimentAnalysis[]): MarketSentiment => {
  if (sentiments.length === 0) {
    return {
      overall: 0,
      bullish: 0,
      bearish: 0,
      neutral: 0,
      volatility: 0,
      trend: 'sideways'
    };
  }

  const weightedScores = sentiments.map(s => s.score * s.confidence * s.magnitude);
  const totalWeight = sentiments.reduce((sum, s) => sum + (s.confidence * s.magnitude), 0);
  
  const overall = totalWeight > 0 ? weightedScores.reduce((sum, score) => sum + score, 0) / totalWeight : 0;
  
  const bullish = sentiments.filter(s => s.score > 0.2).length / sentiments.length;
  const bearish = sentiments.filter(s => s.score < -0.2).length / sentiments.length;
  const neutral = sentiments.filter(s => Math.abs(s.score) <= 0.2).length / sentiments.length;
  
  // Calculate volatility based on sentiment variance
  const variance = sentiments.reduce((sum, s) => sum + Math.pow(s.score - overall, 2), 0) / sentiments.length;
  const volatility = Math.sqrt(variance);
  
  let trend: MarketSentiment['trend'] = 'sideways';
  if (overall > 0.3) trend = 'bullish';
  else if (overall < -0.3) trend = 'bearish';

  return {
    overall: Math.max(-1, Math.min(1, overall)),
    bullish,
    bearish,
    neutral,
    volatility: Math.min(1, volatility),
    trend
  };
};

/**
 * Generates trading signals based on sentiment and technical analysis
 */
export interface SignalInput {
  technicalScore: number;
  sentimentScore: number;
  sentimentWeight: number;
  price: number;
  volume: number;
  volatility: number;
}

export const generateTradingSignal = (input: SignalInput) => {
  const { technicalScore, sentimentScore, sentimentWeight, price, volume, volatility } = input;
  
  // Combine technical and sentiment scores
  const combinedScore = (technicalScore * (1 - sentimentWeight)) + (sentimentScore * sentimentWeight);
  
  // Adjust for volume and volatility
  const volumeMultiplier = Math.min(2, Math.max(0.5, volume / 1000000)); // Normalize volume
  const volatilityMultiplier = Math.max(0.5, Math.min(1.5, 1 - (volatility * 0.5))); // Reduce signal in high volatility
  
  const adjustedScore = combinedScore * volumeMultiplier * volatilityMultiplier;
  
  // Determine action and confidence
  let action: 'buy' | 'sell' | 'hold' = 'hold';
  let confidence = Math.abs(adjustedScore);
  
  if (adjustedScore > 0.6) {
    action = 'buy';
  } else if (adjustedScore < -0.6) {
    action = 'sell';
  }
  
  // Determine signal strength
  let strength: 'weak' | 'medium' | 'strong' = 'weak';
  if (confidence > 0.8) strength = 'strong';
  else if (confidence > 0.6) strength = 'medium';
  
  return {
    action,
    confidence: Math.min(1, confidence),
    strength,
    combinedScore: adjustedScore,
    reasoning: generateReasoning(technicalScore, sentimentScore, sentimentWeight, action, strength)
  };
};

const generateReasoning = (
  technical: number, 
  sentiment: number, 
  sentimentWeight: number, 
  action: string, 
  strength: string
): string => {
  const techDesc = technical > 0.6 ? 'strong bullish' : technical > 0.3 ? 'bullish' : technical < -0.6 ? 'strong bearish' : technical < -0.3 ? 'bearish' : 'neutral';
  const sentDesc = sentiment > 0.6 ? 'very positive' : sentiment > 0.3 ? 'positive' : sentiment < -0.6 ? 'very negative' : sentiment < -0.3 ? 'negative' : 'neutral';
  
  let reasoning = `${techDesc} technical indicators`;
  
  if (sentimentWeight > 0.1) {
    reasoning += ` combined with ${sentDesc} market sentiment`;
  }
  
  reasoning += ` suggest ${action.toUpperCase()} with ${strength} conviction`;
  
  return reasoning;
};

/**
 * Risk management utilities
 */
export const calculatePositionSize = (
  accountValue: number,
  riskPerTrade: number,
  stopLossPercent: number,
  confidence: number
): number => {
  const baseRisk = accountValue * (riskPerTrade / 100);
  const adjustedRisk = baseRisk * confidence; // Scale by confidence
  const positionSize = adjustedRisk / (stopLossPercent / 100);
  
  return Math.max(0, Math.min(accountValue * 0.2, positionSize)); // Cap at 20% of account
};

export const calculateStopLoss = (
  price: number,
  action: 'buy' | 'sell',
  volatility: number,
  baseStopPercent: number
): number => {
  // Adjust stop loss based on volatility
  const adjustedStopPercent = baseStopPercent * (1 + volatility);
  
  if (action === 'buy') {
    return price * (1 - adjustedStopPercent / 100);
  } else {
    return price * (1 + adjustedStopPercent / 100);
  }
};

export const calculateTakeProfit = (
  price: number,
  action: 'buy' | 'sell',
  confidence: number,
  baseTakeProfitPercent: number
): number => {
  // Adjust take profit based on confidence
  const adjustedTakeProfitPercent = baseTakeProfitPercent * (1 + confidence * 0.5);
  
  if (action === 'buy') {
    return price * (1 + adjustedTakeProfitPercent / 100);
  } else {
    return price * (1 - adjustedTakeProfitPercent / 100);
  }
};
