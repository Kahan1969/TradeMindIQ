/**
 * Advanced Backtesting Engine for Trading Strategies
 */

export interface BacktestConfig {
  startDate: string;
  endDate: string;
  initialCapital: number;
  commissionRate: number; // percentage per trade
  slippageRate: number; // percentage for market impact
  maxPositions: number;
  riskPerTrade: number; // percentage of capital per trade
}

export interface Trade {
  symbol: string;
  entryDate: string;
  exitDate?: string;
  entryPrice: number;
  exitPrice?: number;
  quantity: number;
  side: 'long' | 'short';
  pnl?: number;
  commission: number;
  stopLoss?: number;
  takeProfit?: number;
  exitReason?: 'stop_loss' | 'take_profit' | 'signal' | 'time_limit';
}

export interface BacktestMetrics {
  totalReturn: number;
  annualizedReturn: number;
  sharpeRatio: number;
  sortinoRatio: number;
  maxDrawdown: number;
  maxDrawdownDuration: number;
  winRate: number;
  lossRate: number;
  avgWin: number;
  avgLoss: number;
  profitFactor: number;
  totalTrades: number;
  winningTrades: number;
  losingTrades: number;
  averageHoldingPeriod: number;
  volatility: number;
  calmarRatio: number;
  recoveryFactor: number;
}

export interface EquityPoint {
  date: string;
  equity: number;
  drawdown: number;
  returns: number;
}

export interface BacktestResult {
  metrics: BacktestMetrics;
  trades: Trade[];
  equity: EquityPoint[];
  monthlyReturns: Array<{ month: string; return: number }>;
  yearlyReturns: Array<{ year: number; return: number }>;
}

export class BacktestEngine {
  private config: BacktestConfig;
  private trades: Trade[] = [];
  private openPositions: Map<string, Trade> = new Map();
  private equity: EquityPoint[] = [];
  private currentCapital: number;

  constructor(config: BacktestConfig) {
    this.config = config;
    this.currentCapital = config.initialCapital;
  }

  /**
   * Run backtest with historical data and signals
   */
  async runBacktest(
    historicalData: Array<{
      date: string;
      symbol: string;
      open: number;
      high: number;
      low: number;
      close: number;
      volume: number;
    }>,
    signals: Array<{
      date: string;
      symbol: string;
      action: 'buy' | 'sell' | 'hold';
      confidence: number;
      price: number;
    }>
  ): Promise<BacktestResult> {
    
    // Reset state
    this.trades = [];
    this.openPositions.clear();
    this.equity = [];
    this.currentCapital = this.config.initialCapital;

    // Group data by date
    const dataByDate = this.groupDataByDate(historicalData);
    const signalsByDate = this.groupSignalsByDate(signals);
    
    // Get all dates in chronological order
    const allDates = Array.from(new Set([...Object.keys(dataByDate), ...Object.keys(signalsByDate)]))
      .filter(date => date >= this.config.startDate && date <= this.config.endDate)
      .sort();

    // Process each trading day
    for (const date of allDates) {
      const dayData = dataByDate[date] || [];
      const daySignals = signalsByDate[date] || [];
      
      // Update open positions (check stops, exits)
      this.updateOpenPositions(dayData, date);
      
      // Process new signals
      this.processSignals(daySignals, dayData, date);
      
      // Calculate daily equity
      this.calculateEquity(dayData, date);
    }

    // Close any remaining open positions
    this.closeRemainingPositions(historicalData, this.config.endDate);

    return this.generateResults();
  }

  private groupDataByDate(data: any[]): Record<string, any[]> {
    return data.reduce((acc, item) => {
      if (!acc[item.date]) acc[item.date] = [];
      acc[item.date].push(item);
      return acc;
    }, {});
  }

  private groupSignalsByDate(signals: any[]): Record<string, any[]> {
    return signals.reduce((acc, signal) => {
      if (!acc[signal.date]) acc[signal.date] = [];
      acc[signal.date].push(signal);
      return acc;
    }, {});
  }

  private updateOpenPositions(dayData: any[], date: string): void {
    const positionsToClose: string[] = [];

    this.openPositions.forEach((position, symbol) => {
      const symbolData = dayData.find(d => d.symbol === symbol);
      if (!symbolData) return;

      // Check stop loss
      if (position.stopLoss) {
        const hitStopLoss = position.side === 'long' 
          ? symbolData.low <= position.stopLoss
          : symbolData.high >= position.stopLoss;
        
        if (hitStopLoss) {
          this.closePosition(position, position.stopLoss, date, 'stop_loss');
          positionsToClose.push(symbol);
          return;
        }
      }

      // Check take profit
      if (position.takeProfit) {
        const hitTakeProfit = position.side === 'long'
          ? symbolData.high >= position.takeProfit
          : symbolData.low <= position.takeProfit;
        
        if (hitTakeProfit) {
          this.closePosition(position, position.takeProfit, date, 'take_profit');
          positionsToClose.push(symbol);
          return;
        }
      }

      // Check time-based exit (optional - hold for max 30 days)
      const entryDate = new Date(position.entryDate);
      const currentDate = new Date(date);
      const daysDiff = (currentDate.getTime() - entryDate.getTime()) / (1000 * 60 * 60 * 24);
      
      if (daysDiff > 30) {
        this.closePosition(position, symbolData.close, date, 'time_limit');
        positionsToClose.push(symbol);
      }
    });

    // Remove closed positions
    positionsToClose.forEach(symbol => this.openPositions.delete(symbol));
  }

  private processSignals(signals: any[], dayData: any[], date: string): void {
    for (const signal of signals) {
      const symbolData = dayData.find(d => d.symbol === signal.symbol);
      if (!symbolData) continue;

      if (signal.action === 'buy' && !this.openPositions.has(signal.symbol)) {
        this.openLongPosition(signal, symbolData, date);
      } else if (signal.action === 'sell') {
        // Close long position if open, or open short position
        if (this.openPositions.has(signal.symbol)) {
          const position = this.openPositions.get(signal.symbol)!;
          if (position.side === 'long') {
            this.closePosition(position, signal.price, date, 'signal');
            this.openPositions.delete(signal.symbol);
          }
        } else {
          this.openShortPosition(signal, symbolData, date);
        }
      }
    }
  }

  private openLongPosition(signal: any, symbolData: any, date: string): void {
    if (this.openPositions.size >= this.config.maxPositions) return;

    const positionValue = this.currentCapital * (this.config.riskPerTrade / 100) * signal.confidence;
    const entryPrice = signal.price * (1 + this.config.slippageRate / 100); // Add slippage
    const quantity = Math.floor(positionValue / entryPrice);
    
    if (quantity === 0) return;

    const commission = positionValue * (this.config.commissionRate / 100);
    const stopLoss = entryPrice * 0.95; // 5% stop loss
    const takeProfit = entryPrice * 1.15; // 15% take profit

    const trade: Trade = {
      symbol: signal.symbol,
      entryDate: date,
      entryPrice,
      quantity,
      side: 'long',
      commission,
      stopLoss,
      takeProfit
    };

    this.openPositions.set(signal.symbol, trade);
    this.currentCapital -= (positionValue + commission);
  }

  private openShortPosition(signal: any, symbolData: any, date: string): void {
    if (this.openPositions.size >= this.config.maxPositions) return;

    const positionValue = this.currentCapital * (this.config.riskPerTrade / 100) * signal.confidence;
    const entryPrice = signal.price * (1 - this.config.slippageRate / 100); // Add slippage
    const quantity = Math.floor(positionValue / entryPrice);
    
    if (quantity === 0) return;

    const commission = positionValue * (this.config.commissionRate / 100);
    const stopLoss = entryPrice * 1.05; // 5% stop loss for short
    const takeProfit = entryPrice * 0.85; // 15% take profit for short

    const trade: Trade = {
      symbol: signal.symbol,
      entryDate: date,
      entryPrice,
      quantity,
      side: 'short',
      commission,
      stopLoss,
      takeProfit
    };

    this.openPositions.set(signal.symbol, trade);
    this.currentCapital -= commission; // For short, we don't reduce capital for position value
  }

  private closePosition(position: Trade, exitPrice: number, date: string, reason: Trade['exitReason']): void {
    const adjustedExitPrice = position.side === 'long' 
      ? exitPrice * (1 - this.config.slippageRate / 100)
      : exitPrice * (1 + this.config.slippageRate / 100);

    const exitCommission = position.quantity * adjustedExitPrice * (this.config.commissionRate / 100);
    
    let pnl: number;
    if (position.side === 'long') {
      pnl = (adjustedExitPrice - position.entryPrice) * position.quantity - position.commission - exitCommission;
      this.currentCapital += (position.quantity * adjustedExitPrice);
    } else {
      pnl = (position.entryPrice - adjustedExitPrice) * position.quantity - position.commission - exitCommission;
      this.currentCapital += (position.entryPrice - adjustedExitPrice) * position.quantity;
    }

    this.currentCapital += pnl;

    const completedTrade: Trade = {
      ...position,
      exitDate: date,
      exitPrice: adjustedExitPrice,
      pnl,
      commission: position.commission + exitCommission,
      exitReason: reason
    };

    this.trades.push(completedTrade);
  }

  private calculateEquity(dayData: any[], date: string): void {
    let totalEquity = this.currentCapital;
    
    // Add value of open positions
    this.openPositions.forEach((position, symbol) => {
      const symbolData = dayData.find(d => d.symbol === symbol);
      if (symbolData) {
        if (position.side === 'long') {
          totalEquity += position.quantity * symbolData.close;
        } else {
          totalEquity += (position.entryPrice - symbolData.close) * position.quantity;
        }
      }
    });

    const prevEquity = this.equity.length > 0 ? this.equity[this.equity.length - 1].equity : this.config.initialCapital;
    const returns = (totalEquity - prevEquity) / prevEquity;
    
    // Calculate drawdown
    const peak = Math.max(...this.equity.map(e => e.equity), totalEquity);
    const drawdown = (peak - totalEquity) / peak;

    this.equity.push({
      date,
      equity: totalEquity,
      returns,
      drawdown
    });
  }

  private closeRemainingPositions(historicalData: any[], endDate: string): void {
    this.openPositions.forEach((position, symbol) => {
      const lastData = historicalData
        .filter(d => d.symbol === symbol && d.date <= endDate)
        .sort((a, b) => a.date.localeCompare(b.date))
        .pop();
      
      if (lastData) {
        this.closePosition(position, lastData.close, endDate, 'time_limit');
      }
    });
    this.openPositions.clear();
  }

  private generateResults(): BacktestResult {
    const metrics = this.calculateMetrics();
    const monthlyReturns = this.calculateMonthlyReturns();
    const yearlyReturns = this.calculateYearlyReturns();

    return {
      metrics,
      trades: this.trades,
      equity: this.equity,
      monthlyReturns,
      yearlyReturns
    };
  }

  private calculateMetrics(): BacktestMetrics {
    const totalReturn = (this.equity[this.equity.length - 1]?.equity - this.config.initialCapital) / this.config.initialCapital * 100;
    
    const days = (new Date(this.config.endDate).getTime() - new Date(this.config.startDate).getTime()) / (1000 * 60 * 60 * 24);
    const years = days / 365.25;
    const annualizedReturn = Math.pow(1 + totalReturn / 100, 1 / years) - 1;

    const returns = this.equity.map(e => e.returns).filter(r => !isNaN(r));
    const avgReturn = returns.reduce((sum, r) => sum + r, 0) / returns.length;
    const volatility = Math.sqrt(returns.reduce((sum, r) => sum + Math.pow(r - avgReturn, 2), 0) / returns.length) * Math.sqrt(252);
    
    const sharpeRatio = volatility > 0 ? (annualizedReturn - 0.02) / volatility : 0; // Assuming 2% risk-free rate

    const negativeReturns = returns.filter(r => r < 0);
    const downside = Math.sqrt(negativeReturns.reduce((sum, r) => sum + Math.pow(r, 2), 0) / negativeReturns.length) * Math.sqrt(252);
    const sortinoRatio = downside > 0 ? (annualizedReturn - 0.02) / downside : 0;

    const maxDrawdown = Math.max(...this.equity.map(e => e.drawdown)) * 100;
    const calmarRatio = maxDrawdown > 0 ? annualizedReturn / (maxDrawdown / 100) : 0;

    const winningTrades = this.trades.filter(t => t.pnl! > 0).length;
    const losingTrades = this.trades.filter(t => t.pnl! < 0).length;
    const winRate = this.trades.length > 0 ? winningTrades / this.trades.length * 100 : 0;
    const lossRate = 100 - winRate;

    const avgWin = winningTrades > 0 ? this.trades.filter(t => t.pnl! > 0).reduce((sum, t) => sum + t.pnl!, 0) / winningTrades : 0;
    const avgLoss = losingTrades > 0 ? Math.abs(this.trades.filter(t => t.pnl! < 0).reduce((sum, t) => sum + t.pnl!, 0) / losingTrades) : 0;
    
    const grossProfit = this.trades.filter(t => t.pnl! > 0).reduce((sum, t) => sum + t.pnl!, 0);
    const grossLoss = Math.abs(this.trades.filter(t => t.pnl! < 0).reduce((sum, t) => sum + t.pnl!, 0));
    const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : 0;

    const averageHoldingPeriod = this.trades.length > 0 
      ? this.trades.reduce((sum, t) => {
          const entry = new Date(t.entryDate).getTime();
          const exit = new Date(t.exitDate!).getTime();
          return sum + (exit - entry) / (1000 * 60 * 60 * 24);
        }, 0) / this.trades.length
      : 0;

    const recoveryFactor = maxDrawdown > 0 ? totalReturn / maxDrawdown : 0;

    // Calculate max drawdown duration (simplified)
    let maxDrawdownDuration = 0;
    let currentDrawdownDuration = 0;
    let peak = this.config.initialCapital;
    
    for (const point of this.equity) {
      if (point.equity > peak) {
        peak = point.equity;
        currentDrawdownDuration = 0;
      } else {
        currentDrawdownDuration++;
        maxDrawdownDuration = Math.max(maxDrawdownDuration, currentDrawdownDuration);
      }
    }

    return {
      totalReturn,
      annualizedReturn: annualizedReturn * 100,
      sharpeRatio,
      sortinoRatio,
      maxDrawdown,
      maxDrawdownDuration,
      winRate,
      lossRate,
      avgWin,
      avgLoss,
      profitFactor,
      totalTrades: this.trades.length,
      winningTrades,
      losingTrades,
      averageHoldingPeriod,
      volatility: volatility * 100,
      calmarRatio,
      recoveryFactor
    };
  }

  private calculateMonthlyReturns(): Array<{ month: string; return: number }> {
    const monthlyData: Record<string, { start: number; end: number }> = {};
    
    for (const point of this.equity) {
      const month = point.date.substring(0, 7); // YYYY-MM
      if (!monthlyData[month]) {
        monthlyData[month] = { start: point.equity, end: point.equity };
      } else {
        monthlyData[month].end = point.equity;
      }
    }

    return Object.entries(monthlyData).map(([month, data]) => ({
      month,
      return: (data.end - data.start) / data.start * 100
    }));
  }

  private calculateYearlyReturns(): Array<{ year: number; return: number }> {
    const yearlyData: Record<number, { start: number; end: number }> = {};
    
    for (const point of this.equity) {
      const year = new Date(point.date).getFullYear();
      if (!yearlyData[year]) {
        yearlyData[year] = { start: point.equity, end: point.equity };
      } else {
        yearlyData[year].end = point.equity;
      }
    }

    return Object.entries(yearlyData).map(([year, data]) => ({
      year: parseInt(year),
      return: (data.end - data.start) / data.start * 100
    }));
  }
}
