// Frontend Authentication Utilities for TradeMindIQ
// Handles JWT token management and API authentication

const API_BASE_URL = 'http://localhost:3002/api';

// Token management
export const tokenManager = {
  // Get token from localStorage
  getToken() {
    return localStorage.getItem('jwt_token');
  },

  // Set token in localStorage
  setToken(token) {
    localStorage.setItem('jwt_token', token);
  },

  // Remove token from localStorage
  removeToken() {
    localStorage.removeItem('jwt_token');
  },

  // Check if user is authenticated
  isAuthenticated() {
    const token = this.getToken();
    if (!token) return false;
    
    try {
      // Decode JWT without verification (just to check expiry)
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.exp > Date.now() / 1000;
    } catch {
      return false;
    }
  },

  // Get user info from token
  getUserInfo() {
    const token = this.getToken();
    if (!token) return null;
    
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return {
        userId: payload.userId,
        username: payload.username,
        email: payload.email,
        role: payload.role
      };
    } catch {
      return null;
    }
  }
};

// API client with authentication
export const apiClient = {
  // Make authenticated API request
  async request(endpoint, options = {}) {
    const token = tokenManager.getToken();
    const url = `${API_BASE_URL}${endpoint}`;
    
    const config = {
      headers: {
        'Content-Type': 'application/json',
        ...(token && { Authorization: `Bearer ${token}` }),
        ...options.headers
      },
      ...options
    };

    try {
      const response = await fetch(url, config);
      
      // Handle authentication errors
      if (response.status === 401) {
        tokenManager.removeToken();
        window.location.href = '/login';
        throw new Error('Authentication required');
      }
      
      if (!response.ok) {
        const error = await response.json().catch(() => ({ message: 'Request failed' }));
        throw new Error(error.message || `HTTP ${response.status}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('API Request failed:', error);
      throw error;
    }
  },

  // Convenience methods
  get(endpoint) {
    return this.request(endpoint, { method: 'GET' });
  },

  post(endpoint, data) {
    return this.request(endpoint, {
      method: 'POST',
      body: JSON.stringify(data)
    });
  },

  put(endpoint, data) {
    return this.request(endpoint, {
      method: 'PUT',
      body: JSON.stringify(data)
    });
  },

  delete(endpoint) {
    return this.request(endpoint, { method: 'DELETE' });
  }
};

// Authentication service
export const authService = {
  // User login
  async login(username, password) {
    try {
      const response = await fetch(`${API_BASE_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Login failed');
      }

      const data = await response.json();
      tokenManager.setToken(data.token);
      return data;
    } catch (error) {
      console.error('Login failed:', error);
      throw error;
    }
  },

  // User registration
  async register(userData) {
    try {
      const response = await fetch(`${API_BASE_URL}/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(userData)
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Registration failed');
      }

      const data = await response.json();
      tokenManager.setToken(data.token);
      return data;
    } catch (error) {
      console.error('Registration failed:', error);
      throw error;
    }
  },

  // User logout
  logout() {
    tokenManager.removeToken();
    window.location.href = '/login';
  },

  // Get user profile
  async getProfile() {
    return await apiClient.get('/auth/profile');
  },

  // Update user profile
  async updateProfile(profileData) {
    return await apiClient.put('/auth/profile', profileData);
  },

  // Change password
  async changePassword(currentPassword, newPassword) {
    return await apiClient.put('/auth/change-password', {
      currentPassword,
      newPassword
    });
  }
};

// React hook for authentication state
export const useAuth = () => {
  const [isAuthenticated, setIsAuthenticated] = React.useState(
    tokenManager.isAuthenticated()
  );
  const [user, setUser] = React.useState(tokenManager.getUserInfo());

  React.useEffect(() => {
    const checkAuth = () => {
      const authenticated = tokenManager.isAuthenticated();
      const userInfo = tokenManager.getUserInfo();
      
      setIsAuthenticated(authenticated);
      setUser(userInfo);
    };

    // Check auth state on mount and storage changes
    checkAuth();
    window.addEventListener('storage', checkAuth);
    
    return () => window.removeEventListener('storage', checkAuth);
  }, []);

  const login = async (username, password) => {
    try {
      const result = await authService.login(username, password);
      setIsAuthenticated(true);
      setUser(tokenManager.getUserInfo());
      return result;
    } catch (error) {
      setIsAuthenticated(false);
      setUser(null);
      throw error;
    }
  };

  const logout = () => {
    authService.logout();
    setIsAuthenticated(false);
    setUser(null);
  };

  return {
    isAuthenticated,
    user,
    login,
    logout,
    register: authService.register,
    getProfile: authService.getProfile,
    updateProfile: authService.updateProfile,
    changePassword: authService.changePassword
  };
};

// Protected Route component
export const ProtectedRoute = ({ children }) => {
  const isAuthenticated = tokenManager.isAuthenticated();
  
  if (!isAuthenticated) {
    return React.createElement('div', {
      style: {
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '100vh',
        flexDirection: 'column',
        gap: '20px'
      }
    }, [
      React.createElement('h2', { key: 'title' }, 'Authentication Required'),
      React.createElement('p', { key: 'message' }, 'Please log in to access this page.'),
      React.createElement('button', {
        key: 'login-btn',
        onClick: () => window.location.href = '/login',
        style: {
          padding: '10px 20px',
          backgroundColor: '#007bff',
          color: 'white',
          border: 'none',
          borderRadius: '4px',
          cursor: 'pointer'
        }
      }, 'Go to Login')
    ]);
  }
  
  return children;
};

export default {
  tokenManager,
  apiClient,
  authService,
  useAuth,
  ProtectedRoute
};
