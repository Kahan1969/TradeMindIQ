// Email and SMS notification utilities for TradeMindIQ
// This would typically be used in your backend service

export interface NotificationConfig {
  email: {
    service: 'gmail' | 'sendgrid' | 'ses';
    apiKey?: string;
    user?: string;
    pass?: string;
    from: string;
  };
  sms: {
    accountSid: string;
    authToken: string;
    fromNumber: string;
  };
}

export interface AlertData {
  type: 'price' | 'signal';
  title: string;
  message: string;
  symbol?: string;
  price?: number;
  confidence?: number;
  strategy?: string;
  timestamp: string;
}

export interface UserNotificationPreferences {
  email: string;
  phone: string;
  methods: ('email' | 'sms' | 'push')[];
  quietHours?: {
    enabled: boolean;
    start: string;
    end: string;
    timezone: string;
  };
}

export class NotificationService {
  private config: NotificationConfig;

  constructor(config: NotificationConfig) {
    this.config = config;
  }

  /**
   * Send email notification
   */
  async sendEmail(to: string, subject: string, htmlContent: string, textContent?: string): Promise<boolean> {
    try {
      // Example implementation with nodemailer (for Gmail)
      if (this.config.email.service === 'gmail') {
        const nodemailer = require('nodemailer');
        
        const transporter = nodemailer.createTransporter({
          service: 'gmail',
          auth: {
            user: this.config.email.user,
            pass: this.config.email.pass
          }
        });

        const mailOptions = {
          from: this.config.email.from,
          to: to,
          subject: subject,
          html: htmlContent,
          text: textContent || this.stripHtml(htmlContent)
        };

        await transporter.sendMail(mailOptions);
        return true;
      }

      // Example implementation with SendGrid
      if (this.config.email.service === 'sendgrid') {
        const sgMail = require('@sendgrid/mail');
        sgMail.setApiKey(this.config.email.apiKey);

        const msg = {
          to: to,
          from: this.config.email.from,
          subject: subject,
          html: htmlContent,
          text: textContent || this.stripHtml(htmlContent)
        };

        await sgMail.send(msg);
        return true;
      }

      return false;
    } catch (error) {
      console.error('Email sending failed:', error);
      return false;
    }
  }

  /**
   * Send SMS notification via Twilio
   */
  async sendSMS(to: string, message: string): Promise<boolean> {
    try {
      const twilio = require('twilio');
      const client = twilio(this.config.sms.accountSid, this.config.sms.authToken);

      await client.messages.create({
        body: message,
        from: this.config.sms.fromNumber,
        to: to
      });

      return true;
    } catch (error) {
      console.error('SMS sending failed:', error);
      return false;
    }
  }

  /**
   * Check if current time is within user's quiet hours
   */
  private isQuietHours(preferences: UserNotificationPreferences): boolean {
    if (!preferences.quietHours?.enabled) {
      return false;
    }

    const now = new Date();
    const currentTime = now.toLocaleTimeString('en-US', {
      hour12: false,
      timeZone: preferences.quietHours.timezone || 'UTC'
    });

    const start = preferences.quietHours.start;
    const end = preferences.quietHours.end;

    // Handle cases where quiet hours span midnight
    if (start > end) {
      return currentTime >= start || currentTime <= end;
    } else {
      return currentTime >= start && currentTime <= end;
    }
  }

  /**
   * Send alert notification to user via preferred methods
   */
  async sendAlert(
    alertData: AlertData,
    userPreferences: UserNotificationPreferences
  ): Promise<{ success: boolean; methods: string[]; errors: string[] }> {
    const results: { success: boolean; methods: string[]; errors: string[] } = { 
      success: false, 
      methods: [], 
      errors: [] 
    };

    // Check quiet hours
    if (this.isQuietHours(userPreferences)) {
      results.errors.push('Alert blocked due to quiet hours');
      return results;
    }

    // Generate content based on alert type
    const content = this.generateAlertContent(alertData);

    // Send via each preferred method
    for (const method of userPreferences.methods) {
      try {
        let sent = false;

        switch (method) {
          case 'email':
            if (userPreferences.email) {
              sent = await this.sendEmail(
                userPreferences.email,
                content.subject,
                content.html,
                content.text
              );
            }
            break;

          case 'sms':
            if (userPreferences.phone) {
              sent = await this.sendSMS(userPreferences.phone, content.sms);
            }
            break;

          case 'push':
            // Push notifications would be implemented separately
            // using services like Firebase Cloud Messaging
            sent = await this.sendPushNotification(content);
            break;
        }

        if (sent) {
          results.methods.push(method);
          results.success = true;
        } else {
          results.errors.push(`Failed to send ${method}`);
        }
      } catch (error: any) {
        results.errors.push(`${method} error: ${error?.message || 'Unknown error'}`);
      }
    }

    return results;
  }

  /**
   * Generate notification content based on alert type
   */
  private generateAlertContent(alertData: AlertData) {
    const timestamp = new Date(alertData.timestamp).toLocaleString();

    if (alertData.type === 'price') {
      return {
        subject: `🚨 Price Alert: ${alertData.symbol}`,
        html: this.generatePriceAlertHTML(alertData, timestamp),
        text: `PRICE ALERT: ${alertData.title}\n\n${alertData.message}\n\nTime: ${timestamp}\n\nTradeMindIQ Alert System`,
        sms: `🚨 ${alertData.title}: ${alertData.message} at ${timestamp}`
      };
    } else {
      return {
        subject: `🤖 AI Trading Signal: ${alertData.symbol || 'Market'}`,
        html: this.generateSignalAlertHTML(alertData, timestamp),
        text: `AI SIGNAL: ${alertData.title}\n\n${alertData.message}\n\nConfidence: ${alertData.confidence}%\nStrategy: ${alertData.strategy}\nTime: ${timestamp}\n\nTradeMindIQ AI Engine`,
        sms: `🤖 ${alertData.title}: ${alertData.message} (${alertData.confidence}% confidence)`
      };
    }
  }

  /**
   * Generate HTML email template for price alerts
   */
  private generatePriceAlertHTML(alertData: AlertData, timestamp: string): string {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>TradeMindIQ Price Alert</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 20px; }
          .container { max-width: 600px; margin: 0 auto; background: #fff; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
          .header { background: #dc2626; color: white; padding: 20px; border-radius: 8px 8px 0 0; text-align: center; }
          .content { padding: 30px; }
          .alert-box { background: #fee2e2; border: 1px solid #fca5a5; border-radius: 6px; padding: 20px; margin: 20px 0; }
          .price { font-size: 24px; font-weight: bold; color: #dc2626; }
          .symbol { font-size: 28px; font-weight: bold; color: #1f2937; }
          .footer { background: #f3f4f6; padding: 15px; border-radius: 0 0 8px 8px; text-align: center; font-size: 12px; color: #6b7280; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🚨 Price Alert Triggered</h1>
          </div>
          <div class="content">
            <div class="alert-box">
              <div class="symbol">${alertData.symbol}</div>
              <div class="price">$${alertData.price?.toFixed(2)}</div>
              <p><strong>${alertData.title}</strong></p>
              <p>${alertData.message}</p>
            </div>
            <p><strong>Alert Time:</strong> ${timestamp}</p>
            <p>This alert was triggered based on your price monitoring settings in TradeMindIQ.</p>
          </div>
          <div class="footer">
            <p>TradeMindIQ Alert System | Manage your alerts in the app</p>
          </div>
        </div>
      </body>
      </html>
    `;
  }

  /**
   * Generate HTML email template for AI signal alerts
   */
  private generateSignalAlertHTML(alertData: AlertData, timestamp: string): string {
    const confidenceColor = (alertData.confidence || 0) >= 80 ? '#059669' : 
                           (alertData.confidence || 0) >= 60 ? '#d97706' : '#dc2626';

    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>TradeMindIQ AI Signal</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 20px; }
          .container { max-width: 600px; margin: 0 auto; background: #fff; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
          .header { background: linear-gradient(135deg, #7c3aed, #3b82f6); color: white; padding: 20px; border-radius: 8px 8px 0 0; text-align: center; }
          .content { padding: 30px; }
          .signal-box { background: #f0f9ff; border: 1px solid #7dd3fc; border-radius: 6px; padding: 20px; margin: 20px 0; }
          .confidence { font-size: 20px; font-weight: bold; }
          .strategy { background: #e0e7ff; color: #3730a3; padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: bold; }
          .footer { background: #f3f4f6; padding: 15px; border-radius: 0 0 8px 8px; text-align: center; font-size: 12px; color: #6b7280; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🤖 AI Trading Signal</h1>
          </div>
          <div class="content">
            <div class="signal-box">
              <p><strong>${alertData.title}</strong></p>
              <p>${alertData.message}</p>
              <div style="margin-top: 15px;">
                <span class="strategy">${alertData.strategy?.toUpperCase()}</span>
                <div class="confidence" style="color: ${confidenceColor}; margin-top: 10px;">
                  Confidence: ${alertData.confidence}%
                </div>
              </div>
            </div>
            <p><strong>Signal Time:</strong> ${timestamp}</p>
            <p>This signal was generated by our AI trading engine based on market analysis and your configured strategy preferences.</p>
            <p><em>Remember: This is not financial advice. Always do your own research before making trading decisions.</em></p>
          </div>
          <div class="footer">
            <p>TradeMindIQ AI Engine | Manage your alerts in the app</p>
          </div>
        </div>
      </body>
      </html>
    `;
  }

  /**
   * Send push notification (placeholder for FCM implementation)
   */
  private async sendPushNotification(content: any): Promise<boolean> {
    // This would integrate with Firebase Cloud Messaging or similar service
    console.log('Push notification would be sent:', content.subject);
    return true; // Simulated success
  }

  /**
   * Strip HTML tags for plain text content
   */
  private stripHtml(html: string): string {
    return html.replace(/<[^>]*>/g, '').replace(/\s+/g, ' ').trim();
  }
}

// Example usage and configuration
export const createNotificationService = (config: NotificationConfig): NotificationService => {
  return new NotificationService(config);
};

// Example environment configuration
export const getNotificationConfig = (): NotificationConfig => {
  return {
    email: {
      service: (process.env.EMAIL_SERVICE as 'gmail' | 'sendgrid') || 'gmail',
      apiKey: process.env.SENDGRID_API_KEY,
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS,
      from: process.env.EMAIL_FROM || 'alerts@trademindiq.com'
    },
    sms: {
      accountSid: process.env.TWILIO_ACCOUNT_SID || '',
      authToken: process.env.TWILIO_AUTH_TOKEN || '',
      fromNumber: process.env.TWILIO_FROM_NUMBER || ''
    }
  };
};

// Alert queue management for batch processing
export class AlertQueue {
  private queue: Array<{
    alertData: AlertData;
    userPreferences: UserNotificationPreferences;
    retryCount: number;
  }> = [];
  
  private notificationService: NotificationService;
  private processing = false;

  constructor(notificationService: NotificationService) {
    this.notificationService = notificationService;
  }

  /**
   * Add alert to queue
   */
  enqueue(alertData: AlertData, userPreferences: UserNotificationPreferences) {
    this.queue.push({
      alertData,
      userPreferences,
      retryCount: 0
    });

    if (!this.processing) {
      this.processQueue();
    }
  }

  /**
   * Process queued alerts
   */
  private async processQueue() {
    this.processing = true;

    while (this.queue.length > 0) {
      const item = this.queue.shift()!;
      
      try {
        const result = await this.notificationService.sendAlert(
          item.alertData,
          item.userPreferences
        );

        if (!result.success && item.retryCount < 3) {
          // Retry failed alerts up to 3 times
          item.retryCount++;
          this.queue.push(item);
          await this.delay(5000); // Wait 5 seconds before retry
        }
      } catch (error) {
        console.error('Alert processing error:', error);
      }

      // Small delay between alerts to avoid rate limiting
      await this.delay(1000);
    }

    this.processing = false;
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// Example Express.js route handlers
export const createAlertRoutes = (notificationService: NotificationService) => {
  return {
    // Test notification endpoint
    testNotification: async (req: any, res: any) => {
      try {
        const { method, email, phone } = req.body;
        
        const testAlert: AlertData = {
          type: 'signal',
          title: 'Test Notification',
          message: 'This is a test notification from TradeMindIQ',
          timestamp: new Date().toISOString()
        };

        const userPrefs: UserNotificationPreferences = {
          email: email || 'test@example.com',
          phone: phone || '+1234567890',
          methods: [method]
        };

        const result = await notificationService.sendAlert(testAlert, userPrefs);
        
        res.json({
          success: result.success,
          message: result.success ? `Test ${method} sent successfully` : 'Failed to send notification',
          details: result
        });
      } catch (error) {
        res.status(500).json({ error: 'Failed to send test notification' });
      }
    },

    // Trigger price alert
    triggerPriceAlert: async (req: any, res: any) => {
      try {
        const { symbol, price, condition, targetPrice, userId } = req.body;
        
        // In a real implementation, you'd fetch user preferences from database
        const userPrefs = await getUserNotificationPreferences(userId);
        
        const alertData: AlertData = {
          type: 'price',
          title: `Price Alert: ${symbol}`,
          message: `${symbol} has ${condition} ${targetPrice}, currently at $${price}`,
          symbol,
          price,
          timestamp: new Date().toISOString()
        };

        const result = await notificationService.sendAlert(alertData, userPrefs);
        
        res.json({ success: result.success, details: result });
      } catch (error) {
        res.status(500).json({ error: 'Failed to send price alert' });
      }
    },

    // Trigger AI signal alert
    triggerSignalAlert: async (req: any, res: any) => {
      try {
        const { symbol, signal, confidence, strategy, userId } = req.body;
        
        const userPrefs = await getUserNotificationPreferences(userId);
        
        const alertData: AlertData = {
          type: 'signal',
          title: `${signal.toUpperCase()} Signal: ${symbol}`,
          message: `AI detected a ${signal} signal for ${symbol} using ${strategy} strategy`,
          symbol,
          confidence,
          strategy,
          timestamp: new Date().toISOString()
        };

        const result = await notificationService.sendAlert(alertData, userPrefs);
        
        res.json({ success: result.success, details: result });
      } catch (error) {
        res.status(500).json({ error: 'Failed to send signal alert' });
      }
    }
  };
};

// Placeholder for user preferences retrieval
async function getUserNotificationPreferences(userId: string): Promise<UserNotificationPreferences> {
  // This would fetch from your database
  return {
    email: 'user@example.com',
    phone: '+1234567890',
    methods: ['email', 'sms']
  };
}
