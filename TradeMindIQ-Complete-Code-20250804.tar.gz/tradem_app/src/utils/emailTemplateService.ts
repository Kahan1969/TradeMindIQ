// Email template service for TradeMindIQ automated reporting
// This service generates professional HTML email templates for trading summaries

export interface TradeData {
  id: string;
  symbol: string;
  type: 'buy' | 'sell';
  quantity: number;
  price: number;
  timestamp: string;
  strategy?: string;
  profit?: number;
  commission: number;
  total: number;
}

export interface PerformanceMetrics {
  totalTrades: number;
  winRate: number;
  totalProfit: number;
  totalCommissions: number;
  netProfit: number;
  avgTradeSize: number;
  bestTrade: number;
  worstTrade: number;
  sharpeRatio: number;
  maxDrawdown: number;
}

export interface SummaryData {
  period: 'daily' | 'weekly';
  startDate: string;
  endDate: string;
  trades: TradeData[];
  metrics: PerformanceMetrics;
  includeCharts: boolean;
  includePerformance: boolean;
  includeTrades: boolean;
}

export class EmailTemplateService {
  
  /**
   * Generate daily trading summary email
   */
  generateDailySummary(data: SummaryData): { subject: string; html: string; text: string } {
    const subject = `📊 TradeMindIQ Daily Summary - ${new Date(data.endDate).toLocaleDateString()}`;
    
    return {
      subject,
      html: this.generateDailySummaryHTML(data),
      text: this.generateDailySummaryText(data)
    };
  }

  /**
   * Generate weekly trading summary email
   */
  generateWeeklySummary(data: SummaryData): { subject: string; html: string; text: string } {
    const startDate = new Date(data.startDate).toLocaleDateString();
    const endDate = new Date(data.endDate).toLocaleDateString();
    const subject = `📈 TradeMindIQ Weekly Summary - ${startDate} to ${endDate}`;
    
    return {
      subject,
      html: this.generateWeeklySummaryHTML(data),
      text: this.generateWeeklySummaryText(data)
    };
  }

  /**
   * Generate daily summary HTML template
   */
  private generateDailySummaryHTML(data: SummaryData): string {
    const date = new Date(data.endDate).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });

    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>TradeMindIQ Daily Summary</title>
        <style>
          body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 20px; background-color: #f5f5f5; }
          .container { max-width: 600px; margin: 0 auto; background: #fff; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); overflow: hidden; }
          .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px 20px; text-align: center; }
          .header h1 { margin: 0; font-size: 28px; font-weight: 300; }
          .header .date { font-size: 16px; opacity: 0.9; margin-top: 5px; }
          .content { padding: 30px; }
          .metrics-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin: 25px 0; }
          .metric { background: #f8fafc; border-radius: 8px; padding: 20px; text-align: center; border-left: 4px solid #667eea; }
          .metric-value { font-size: 24px; font-weight: bold; margin-bottom: 5px; }
          .metric-label { font-size: 12px; color: #666; text-transform: uppercase; letter-spacing: 0.5px; }
          .positive { color: #10b981; }
          .negative { color: #ef4444; }
          .neutral { color: #6b7280; }
          .section { margin: 30px 0; }
          .section h2 { color: #374151; font-size: 20px; margin-bottom: 15px; padding-bottom: 10px; border-bottom: 2px solid #e5e7eb; }
          .trade-item { background: #f9fafb; border-radius: 6px; padding: 15px; margin-bottom: 10px; display: flex; justify-content: space-between; align-items: center; }
          .trade-symbol { font-weight: bold; color: #1f2937; }
          .trade-details { font-size: 14px; color: #6b7280; }
          .trade-pnl { font-weight: bold; }
          .footer { background: #f3f4f6; padding: 20px; text-align: center; font-size: 12px; color: #6b7280; }
          .cta-button { background: #667eea; color: white; padding: 12px 30px; border-radius: 6px; text-decoration: none; display: inline-block; margin: 20px 0; font-weight: bold; }
          @media (max-width: 600px) {
            .metrics-grid { grid-template-columns: 1fr; }
            .trade-item { flex-direction: column; align-items: flex-start; }
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>📊 Daily Trading Summary</h1>
            <div class="date">${date}</div>
          </div>
          
          <div class="content">
            ${data.includePerformance ? this.generatePerformanceSection(data.metrics, 'daily') : ''}
            
            ${data.includeTrades ? this.generateTradesSection(data.trades, 'daily') : ''}
            
            <div class="section">
              <p>Your TradeMindIQ AI system is actively monitoring the markets and executing your trading strategies. Stay disciplined and trust the process!</p>
              <a href="#" class="cta-button">View Full Dashboard</a>
            </div>
          </div>
          
          <div class="footer">
            <p>TradeMindIQ Daily Summary | Powered by AI Trading Intelligence</p>
            <p>This email was automatically generated. To modify your email preferences, visit your account settings.</p>
          </div>
        </div>
      </body>
      </html>
    `;
  }

  /**
   * Generate weekly summary HTML template
   */
  private generateWeeklySummaryHTML(data: SummaryData): string {
    const startDate = new Date(data.startDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    const endDate = new Date(data.endDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });

    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>TradeMindIQ Weekly Summary</title>
        <style>
          body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 20px; background-color: #f5f5f5; }
          .container { max-width: 650px; margin: 0 auto; background: #fff; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); overflow: hidden; }
          .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 40px 20px; text-align: center; }
          .header h1 { margin: 0; font-size: 32px; font-weight: 300; }
          .header .period { font-size: 18px; opacity: 0.9; margin-top: 10px; }
          .content { padding: 40px; }
          .highlight-metrics { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin: 30px 0; }
          .highlight-metric { background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%); border-radius: 12px; padding: 25px; text-align: center; border: 1px solid #e2e8f0; }
          .highlight-value { font-size: 28px; font-weight: bold; margin-bottom: 8px; }
          .highlight-label { font-size: 13px; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; }
          .metrics-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; margin: 25px 0; }
          .metric { background: #f8fafc; border-radius: 8px; padding: 18px; text-align: center; border-left: 4px solid #667eea; }
          .metric-value { font-size: 20px; font-weight: bold; margin-bottom: 5px; }
          .metric-label { font-size: 11px; color: #666; text-transform: uppercase; letter-spacing: 0.5px; }
          .positive { color: #10b981; }
          .negative { color: #ef4444; }
          .neutral { color: #6b7280; }
          .section { margin: 35px 0; }
          .section h2 { color: #374151; font-size: 22px; margin-bottom: 20px; padding-bottom: 10px; border-bottom: 2px solid #e5e7eb; }
          .weekly-insights { background: #fef3c7; border-left: 4px solid #f59e0b; padding: 20px; border-radius: 6px; margin: 25px 0; }
          .weekly-insights h3 { color: #92400e; margin-top: 0; }
          .trade-summary { background: #f0f9ff; border-radius: 8px; padding: 20px; margin: 20px 0; }
          .footer { background: #f3f4f6; padding: 25px; text-align: center; font-size: 12px; color: #6b7280; }
          .cta-button { background: #667eea; color: white; padding: 15px 35px; border-radius: 8px; text-decoration: none; display: inline-block; margin: 25px 0; font-weight: bold; font-size: 16px; }
          @media (max-width: 600px) {
            .highlight-metrics { grid-template-columns: 1fr; }
            .metrics-grid { grid-template-columns: 1fr; }
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>📈 Weekly Trading Summary</h1>
            <div class="period">${startDate} - ${endDate}</div>
          </div>
          
          <div class="content">
            ${data.includePerformance ? this.generateWeeklyPerformanceSection(data.metrics) : ''}
            
            ${this.generateWeeklyInsights(data)}
            
            ${data.includeTrades ? this.generateTradesSection(data.trades, 'weekly') : ''}
            
            <div class="section">
              <h2>🎯 Looking Ahead</h2>
              <p>Your AI trading strategies continue to evolve and adapt to market conditions. Keep monitoring your portfolio and stay informed about market trends.</p>
              <a href="#" class="cta-button">Access Full Analytics</a>
            </div>
          </div>
          
          <div class="footer">
            <p>TradeMindIQ Weekly Summary | Advanced AI Trading Platform</p>
            <p>This automated report helps you track your trading performance. Manage your email preferences in your account settings.</p>
          </div>
        </div>
      </body>
      </html>
    `;
  }

  /**
   * Generate performance section HTML
   */
  private generatePerformanceSection(metrics: PerformanceMetrics, period: 'daily' | 'weekly'): string {
    const titleText = period === 'daily' ? "Today's Performance" : "Performance Overview";
    
    return `
      <div class="section">
        <h2>📊 ${titleText}</h2>
        <div class="metrics-grid">
          <div class="metric">
            <div class="metric-value neutral">${metrics.totalTrades}</div>
            <div class="metric-label">Total Trades</div>
          </div>
          <div class="metric">
            <div class="metric-value ${metrics.winRate >= 60 ? 'positive' : metrics.winRate >= 40 ? 'neutral' : 'negative'}">${metrics.winRate}%</div>
            <div class="metric-label">Win Rate</div>
          </div>
          <div class="metric">
            <div class="metric-value ${metrics.netProfit >= 0 ? 'positive' : 'negative'}">$${metrics.netProfit.toFixed(2)}</div>
            <div class="metric-label">Net P&L</div>
          </div>
          <div class="metric">
            <div class="metric-value neutral">${metrics.sharpeRatio}</div>
            <div class="metric-label">Sharpe Ratio</div>
          </div>
        </div>
      </div>
    `;
  }

  /**
   * Generate weekly performance section with highlights
   */
  private generateWeeklyPerformanceSection(metrics: PerformanceMetrics): string {
    return `
      <div class="section">
        <div class="highlight-metrics">
          <div class="highlight-metric">
            <div class="highlight-value ${metrics.netProfit >= 0 ? 'positive' : 'negative'}">$${metrics.netProfit.toFixed(0)}</div>
            <div class="highlight-label">Weekly P&L</div>
          </div>
          <div class="highlight-metric">
            <div class="highlight-value neutral">${metrics.totalTrades}</div>
            <div class="highlight-label">Trades Executed</div>
          </div>
          <div class="highlight-metric">
            <div class="highlight-value ${metrics.winRate >= 60 ? 'positive' : 'neutral'}">${metrics.winRate}%</div>
            <div class="highlight-label">Success Rate</div>
          </div>
        </div>
        
        <div class="metrics-grid">
          <div class="metric">
            <div class="metric-value positive">$${metrics.bestTrade.toFixed(2)}</div>
            <div class="metric-label">Best Trade</div>
          </div>
          <div class="metric">
            <div class="metric-value negative">$${metrics.worstTrade.toFixed(2)}</div>
            <div class="metric-label">Worst Trade</div>
          </div>
          <div class="metric">
            <div class="metric-value neutral">$${metrics.avgTradeSize.toFixed(0)}</div>
            <div class="metric-label">Avg Trade Size</div>
          </div>
          <div class="metric">
            <div class="metric-value negative">$${Math.abs(metrics.maxDrawdown).toFixed(2)}</div>
            <div class="metric-label">Max Drawdown</div>
          </div>
        </div>
      </div>
    `;
  }

  /**
   * Generate weekly insights section
   */
  private generateWeeklyInsights(data: SummaryData): string {
    const winningTrades = data.trades.filter(t => (t.profit || 0) > 0).length;
    const losingTrades = data.trades.filter(t => (t.profit || 0) < 0).length;
    const topSymbol = this.getTopTradedSymbol(data.trades);
    
    return `
      <div class="weekly-insights">
        <h3>💡 Weekly Insights</h3>
        <ul>
          <li><strong>${winningTrades}</strong> profitable trades vs <strong>${losingTrades}</strong> losing trades</li>
          <li>Most active symbol: <strong>${topSymbol}</strong></li>
          <li>Your AI strategies maintained a <strong>${data.metrics.winRate}%</strong> success rate</li>
          <li>Total commission costs: <strong>$${data.metrics.totalCommissions.toFixed(2)}</strong></li>
        </ul>
      </div>
    `;
  }

  /**
   * Generate trades section HTML
   */
  private generateTradesSection(trades: TradeData[], period: 'daily' | 'weekly'): string {
    const titleText = period === 'daily' ? "Today's Trades" : "Recent Trades";
    const displayTrades = trades.slice(0, period === 'daily' ? 10 : 15);
    
    if (displayTrades.length === 0) {
      return `
        <div class="section">
          <h2>📋 ${titleText}</h2>
          <div class="trade-summary">
            <p>No trades executed during this period. Your AI system is monitoring the markets for optimal opportunities.</p>
          </div>
        </div>
      `;
    }

    const tradesHTML = displayTrades.map(trade => {
      const profitClass = (trade.profit || 0) >= 0 ? 'positive' : 'negative';
      const profitText = trade.profit ? `$${trade.profit.toFixed(2)}` : 'Pending';
      
      return `
        <div class="trade-item">
          <div>
            <div class="trade-symbol">${trade.symbol}</div>
            <div class="trade-details">${trade.type.toUpperCase()} ${trade.quantity} @ $${trade.price.toFixed(2)} • ${trade.strategy || 'Manual'}</div>
          </div>
          <div class="trade-pnl ${profitClass}">${profitText}</div>
        </div>
      `;
    }).join('');

    return `
      <div class="section">
        <h2>📋 ${titleText}</h2>
        ${tradesHTML}
        ${trades.length > displayTrades.length ? `<p style="text-align: center; color: #6b7280; margin-top: 15px;">+${trades.length - displayTrades.length} more trades</p>` : ''}
      </div>
    `;
  }

  /**
   * Generate daily summary plain text
   */
  private generateDailySummaryText(data: SummaryData): string {
    const date = new Date(data.endDate).toLocaleDateString();
    
    return `
TradeMindIQ Daily Summary - ${date}
====================================

Performance Summary:
- Total Trades: ${data.metrics.totalTrades}
- Win Rate: ${data.metrics.winRate}%
- Net P&L: $${data.metrics.netProfit.toFixed(2)}
- Sharpe Ratio: ${data.metrics.sharpeRatio}

${data.trades.length > 0 ? `
Recent Trades:
${data.trades.slice(0, 5).map(trade => 
  `${trade.symbol} ${trade.type.toUpperCase()} ${trade.quantity} @ $${trade.price.toFixed(2)} | P/L: $${(trade.profit || 0).toFixed(2)}`
).join('\n')}
` : 'No trades executed today.'}

Your TradeMindIQ AI system continues to monitor the markets for optimal trading opportunities.

Visit your dashboard for detailed analytics: [Dashboard Link]
    `;
  }

  /**
   * Generate weekly summary plain text
   */
  private generateWeeklySummaryText(data: SummaryData): string {
    const startDate = new Date(data.startDate).toLocaleDateString();
    const endDate = new Date(data.endDate).toLocaleDateString();
    
    return `
TradeMindIQ Weekly Summary - ${startDate} to ${endDate}
======================================================

Performance Highlights:
- Total Trades: ${data.metrics.totalTrades}
- Win Rate: ${data.metrics.winRate}%
- Net P&L: $${data.metrics.netProfit.toFixed(2)}
- Best Trade: $${data.metrics.bestTrade.toFixed(2)}
- Worst Trade: $${data.metrics.worstTrade.toFixed(2)}

${data.trades.length > 0 ? `
Recent Activity:
${data.trades.slice(0, 10).map(trade => 
  `${new Date(trade.timestamp).toLocaleDateString()} | ${trade.symbol} ${trade.type.toUpperCase()} ${trade.quantity} @ $${trade.price.toFixed(2)}`
).join('\n')}
` : 'No trades executed this week.'}

Weekly Insights:
- Most traded symbol: ${this.getTopTradedSymbol(data.trades)}
- Total commission costs: $${data.metrics.totalCommissions.toFixed(2)}
- Your AI strategies maintained consistent performance

Access your full analytics dashboard: [Dashboard Link]
    `;
  }

  /**
   * Get the most traded symbol from trades array
   */
  private getTopTradedSymbol(trades: TradeData[]): string {
    if (trades.length === 0) return 'N/A';
    
    const symbolCounts = trades.reduce((acc, trade) => {
      acc[trade.symbol] = (acc[trade.symbol] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
    
    return Object.entries(symbolCounts)
      .sort(([,a], [,b]) => b - a)[0][0];
  }

  /**
   * Generate export completion notification email
   */
  generateExportNotification(
    exportType: 'pdf' | 'csv' | 'both',
    period: string,
    downloadLinks: string[]
  ): { subject: string; html: string; text: string } {
    const subject = `📊 Your TradeMindIQ ${exportType.toUpperCase()} Export is Ready`;
    
    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Export Ready</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 20px; }
          .container { max-width: 500px; margin: 0 auto; background: #fff; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
          .header { background: #667eea; color: white; padding: 20px; border-radius: 8px 8px 0 0; text-align: center; }
          .content { padding: 30px; }
          .download-button { background: #10b981; color: white; padding: 12px 25px; border-radius: 6px; text-decoration: none; display: inline-block; margin: 10px 5px; }
          .footer { background: #f3f4f6; padding: 15px; border-radius: 0 0 8px 8px; text-align: center; font-size: 12px; color: #6b7280; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>📊 Export Complete</h1>
          </div>
          <div class="content">
            <p>Your TradeMindIQ trading report export for <strong>${period}</strong> is ready for download.</p>
            <p>Export format: <strong>${exportType.toUpperCase()}</strong></p>
            
            <div style="text-align: center; margin: 25px 0;">
              ${downloadLinks.map(link => `<a href="${link}" class="download-button">Download Report</a>`).join('')}
            </div>
            
            <p><small>Download links expire in 7 days for security purposes.</small></p>
          </div>
          <div class="footer">
            <p>TradeMindIQ Export Service | Keep tracking your trading success</p>
          </div>
        </div>
      </body>
      </html>
    `;

    const text = `
TradeMindIQ Export Complete

Your trading report export for ${period} is ready for download.
Export format: ${exportType.toUpperCase()}

Download links:
${downloadLinks.join('\n')}

Download links expire in 7 days for security purposes.

TradeMindIQ Export Service
    `;

    return { subject, html, text };
  }
}

// Export utility functions
export const createEmailTemplateService = (): EmailTemplateService => {
  return new EmailTemplateService();
};

// Example usage
export const generateSampleEmailContent = () => {
  const templateService = new EmailTemplateService();
  
  const sampleData: SummaryData = {
    period: 'daily',
    startDate: new Date().toISOString(),
    endDate: new Date().toISOString(),
    trades: [
      {
        id: '1',
        symbol: 'AAPL',
        type: 'buy',
        quantity: 100,
        price: 175.25,
        timestamp: new Date().toISOString(),
        strategy: 'momentum',
        profit: 325.00,
        commission: 1.00,
        total: 17526.00
      }
    ],
    metrics: {
      totalTrades: 1,
      winRate: 100,
      totalProfit: 325.00,
      totalCommissions: 1.00,
      netProfit: 324.00,
      avgTradeSize: 17526.00,
      bestTrade: 325.00,
      worstTrade: 0,
      sharpeRatio: 1.85,
      maxDrawdown: 0
    },
    includeCharts: true,
    includePerformance: true,
    includeTrades: true
  };
  
  return templateService.generateDailySummary(sampleData);
};
