import React, { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import AuthForm from './components/AuthForm';
import UserHeader from './components/UserHeader';
import ChartPanel from './components/ChartPanel';
import AlertTicker from './components/AlertTicker';
import Portfolio from './components/Portfolio';
import TradeHistory from './components/TradeHistory';
import AccountSummary from './components/AccountSummary';
import StrategyEngine from './components/StrategyEngine';
import AlertsManager from './components/AlertsManager';
import ExportReportingTools from './components/ExportReportingTools';
import SettingsPanel from './components/SettingsPanel';
import PWAInstallPrompt from './components/PWAInstallPrompt';
import MobileBottomNav from './components/MobileBottomNav';
import MobileSectionView from './components/MobileSectionView';
import './App.css';

function AppContent() {
  const { isAuthenticated, loading } = useAuth();
  const [activeSection, setActiveSection] = useState('dashboard');

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading TradeMindIQ...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <AuthForm />;
  }

  return (
    <div className="App bg-gray-50 min-h-screen">
      <UserHeader />
      
      {/* Desktop Layout */}
      <main className="hidden sm:block max-w-4xl mx-auto px-3 sm:px-4 lg:px-6 space-y-4 sm:space-y-6 pb-8">
        <AccountSummary />
        <StrategyEngine />
        <AlertsManager />
        <ExportReportingTools />
        <SettingsPanel />
        <ChartPanel />
        <AlertTicker />
        <Portfolio />
        <TradeHistory />
      </main>
      
      {/* Mobile Layout */}
      <main className="sm:hidden px-3 space-y-4 pb-20">
        <MobileSectionView activeSection={activeSection} />
      </main>
      
      {/* Mobile Bottom Navigation */}
      <MobileBottomNav 
        activeSection={activeSection} 
        onSectionChange={setActiveSection} 
      />
      
      <PWAInstallPrompt />
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
