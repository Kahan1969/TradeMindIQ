#!/bin/bash

# TradeMindIQ Testing Script
echo "🚀 Starting TradeMindIQ Mobile Testing..."
echo ""

# Check if app is running
echo "📡 Checking if app is running..."
if curl -s http://localhost:3000 > /dev/null; then
    echo "✅ App is running at http://localhost:3000"
else
    echo "❌ App is not running. Start with: npm start"
    exit 1
fi

echo ""
echo "🧪 TESTING CHECKLIST:"
echo ""
echo "RESPONSIVE DESIGN:"
echo "□ Open Chrome DevTools (F12)"
echo "□ Toggle device toolbar"
echo "□ Test iPhone SE (375px width)"
echo "□ Test iPad (768px width)"
echo "□ Test Desktop (1200px+ width)"
echo ""

echo "MOBILE FEATURES:"
echo "□ Bottom navigation appears on mobile"
echo "□ Touch targets are finger-friendly"
echo "□ Text is readable without zooming"
echo "□ All buttons work with touch"
echo ""

echo "PWA FEATURES:"
echo "□ Install prompt appears"
echo "□ App can be installed"
echo "□ Works in standalone mode"
echo "□ Offline functionality"
echo ""

echo "AUTHENTICATION:"
echo "□ Registration form works"
echo "□ Login form works"
echo "□ Error messages display"
echo "□ User header shows after login"
echo ""

echo "TRADING COMPONENTS:"
echo "□ Dashboard loads with demo data"
echo "□ Portfolio shows positions"
echo "□ Charts display properly"
echo "□ Trade history is visible"
echo "□ Alerts ticker works"
echo ""

echo "🌐 Open http://localhost:3000 to start testing!"
echo "📱 Use browser dev tools to simulate mobile devices"
