#!/bin/bash
cd "/Users/kahangabar/Desktop/TradeMindIQ/tradem_app"
npm start
