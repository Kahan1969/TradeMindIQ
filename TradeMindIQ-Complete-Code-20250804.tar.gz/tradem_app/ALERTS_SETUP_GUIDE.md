# TradeMindIQ Email/SMS Alerts Setup Guide

## Overview
This guide explains how to set up email and SMS alerts using Twilio and email services for the TradeMindIQ trading platform.

## Features Implemented

### 📢 AlertsManager Component
- **Price Alerts**: Set alerts for price movements (above/below/crosses)
- **AI Signal Alerts**: Get notified when AI strategies generate trading signals
- **Multiple Notification Methods**: Email, SMS, and Push notifications
- **Quiet Hours**: Configure times when notifications are disabled
- **Alert History**: Track all sent notifications
- **Test Functions**: Test email and SMS functionality

### 🔧 Notification Service
- **Email Integration**: Support for Gmail, SendGrid, and AWS SES
- **SMS Integration**: Twilio SMS service
- **Queue Management**: Batch processing with retry logic
- **Template System**: HTML email templates for professional alerts
- **Error Handling**: Comprehensive error tracking and reporting

## Installation

### Frontend Dependencies
```bash
# Already included in the existing React project
# No additional dependencies needed for the frontend components
```

### Backend Dependencies (Node.js)
```bash
npm install twilio nodemailer @sendgrid/mail
```

## Environment Configuration

Create a `.env` file in your backend directory:

```env
# Email Configuration (Choose one)
EMAIL_SERVICE=gmail
EMAIL_USER=your.email@gmail.com
EMAIL_PASS=your_app_password
EMAIL_FROM=alerts@trademindiq.com

# OR SendGrid
EMAIL_SERVICE=sendgrid
SENDGRID_API_KEY=your_sendgrid_api_key
EMAIL_FROM=alerts@trademindiq.com

# Twilio SMS Configuration
TWILIO_ACCOUNT_SID=your_twilio_account_sid
TWILIO_AUTH_TOKEN=your_twilio_auth_token
TWILIO_FROM_NUMBER=+1234567890
```

## Backend Implementation

### 1. Express.js Route Setup
```javascript
import express from 'express';
import { createNotificationService, getNotificationConfig, createAlertRoutes } from './utils/notificationService';

const app = express();
const notificationService = createNotificationService(getNotificationConfig());
const alertRoutes = createAlertRoutes(notificationService);

// Alert endpoints
app.post('/api/alerts/test', alertRoutes.testNotification);
app.post('/api/alerts/price/trigger', alertRoutes.triggerPriceAlert);
app.post('/api/alerts/signals/trigger', alertRoutes.triggerSignalAlert);

// CRUD operations for alerts
app.get('/api/alerts', async (req, res) => {
  // Return user's alerts from database
});

app.post('/api/alerts/price', async (req, res) => {
  // Create new price alert
});

app.post('/api/alerts/signals', async (req, res) => {
  // Create new signal alert
});
```

### 2. Database Schema (Example for MongoDB)
```javascript
// Price Alert Schema
const priceAlertSchema = {
  userId: String,
  symbol: String,
  condition: String, // 'above', 'below', 'crosses_above', 'crosses_below'
  targetPrice: Number,
  currentPrice: Number,
  isActive: Boolean,
  notificationMethod: [String], // ['email', 'sms', 'push']
  createdAt: Date,
  triggeredAt: Date
};

// Signal Alert Schema
const signalAlertSchema = {
  userId: String,
  strategy: String, // 'momentum', 'swing', 'scalp', 'all'
  symbols: [String],
  minConfidence: Number,
  signalTypes: [String], // ['buy', 'sell', 'hold']
  notificationMethod: [String],
  isActive: Boolean,
  createdAt: Date
};

// User Notification Preferences
const notificationSettingsSchema = {
  userId: String,
  email: String,
  phone: String,
  emailEnabled: Boolean,
  smsEnabled: Boolean,
  pushEnabled: Boolean,
  quietHours: {
    enabled: Boolean,
    start: String, // '22:00'
    end: String, // '08:00'
    timezone: String
  }
};
```

### 3. Price Monitoring Service
```javascript
// Example price monitoring service
class PriceMonitor {
  constructor(notificationService) {
    this.notificationService = notificationService;
    this.activeAlerts = new Map();
  }

  async checkPriceAlerts() {
    const alerts = await this.getActivePriceAlerts();
    
    for (const alert of alerts) {
      const currentPrice = await this.getCurrentPrice(alert.symbol);
      const shouldTrigger = this.shouldTriggerAlert(alert, currentPrice);
      
      if (shouldTrigger) {
        await this.triggerAlert(alert, currentPrice);
      }
    }
  }

  shouldTriggerAlert(alert, currentPrice) {
    switch (alert.condition) {
      case 'above':
        return currentPrice > alert.targetPrice;
      case 'below':
        return currentPrice < alert.targetPrice;
      case 'crosses_above':
        return alert.currentPrice <= alert.targetPrice && currentPrice > alert.targetPrice;
      case 'crosses_below':
        return alert.currentPrice >= alert.targetPrice && currentPrice < alert.targetPrice;
      default:
        return false;
    }
  }

  async triggerAlert(alert, currentPrice) {
    const alertData = {
      type: 'price',
      title: `Price Alert: ${alert.symbol}`,
      message: `${alert.symbol} has ${alert.condition.replace('_', ' ')} $${alert.targetPrice}, currently at $${currentPrice}`,
      symbol: alert.symbol,
      price: currentPrice,
      timestamp: new Date().toISOString()
    };

    const userPrefs = await this.getUserNotificationPreferences(alert.userId);
    await this.notificationService.sendAlert(alertData, userPrefs);
    
    // Mark alert as triggered
    await this.markAlertTriggered(alert.id);
  }
}
```

### 4. AI Signal Integration
```javascript
// Integration with your AI strategy engine
class AISignalMonitor {
  constructor(notificationService) {
    this.notificationService = notificationService;
  }

  async onSignalGenerated(signal) {
    const alerts = await this.getMatchingSignalAlerts(signal);
    
    for (const alert of alerts) {
      if (this.shouldNotifySignal(alert, signal)) {
        await this.sendSignalNotification(alert, signal);
      }
    }
  }

  shouldNotifySignal(alert, signal) {
    // Check strategy match
    if (alert.strategy !== 'all' && alert.strategy !== signal.strategy) {
      return false;
    }

    // Check symbol match
    if (alert.symbols.length > 0 && !alert.symbols.includes(signal.symbol)) {
      return false;
    }

    // Check signal type
    if (!alert.signalTypes.includes(signal.type)) {
      return false;
    }

    // Check confidence threshold
    if (signal.confidence < alert.minConfidence) {
      return false;
    }

    return true;
  }

  async sendSignalNotification(alert, signal) {
    const alertData = {
      type: 'signal',
      title: `${signal.type.toUpperCase()} Signal: ${signal.symbol}`,
      message: `AI detected a ${signal.type} signal for ${signal.symbol} using ${signal.strategy} strategy`,
      symbol: signal.symbol,
      confidence: signal.confidence,
      strategy: signal.strategy,
      timestamp: new Date().toISOString()
    };

    const userPrefs = await this.getUserNotificationPreferences(alert.userId);
    await this.notificationService.sendAlert(alertData, userPrefs);
  }
}
```

## Service Provider Setup

### Gmail Setup
1. Enable 2-Factor Authentication
2. Generate App Password: Google Account → Security → App passwords
3. Use app password in EMAIL_PASS environment variable

### SendGrid Setup
1. Create SendGrid account
2. Create API key with Mail Send permissions
3. Add your domain and verify sender identity

### Twilio Setup
1. Create Twilio account
2. Get Account SID and Auth Token from console
3. Purchase phone number for sending SMS
4. Verify your phone number for testing

## Testing

### Test Notifications
Use the built-in test functions in the AlertsManager component:

1. Navigate to Settings tab
2. Enter email and phone number
3. Click "Test Email" or "Test SMS"
4. Check delivery and troubleshoot if needed

### Price Alert Testing
1. Create a price alert with current market price
2. Set condition to trigger immediately
3. Verify notification is received
4. Check alert history

### AI Signal Testing
1. Create signal alert with low confidence threshold
2. Generate test signals from AI engine
3. Verify notifications match criteria
4. Check signal alert history

## Mobile Integration

The AlertsManager is fully integrated into the mobile navigation:

- **Mobile Tab**: 📢 Alerts tab in bottom navigation
- **Responsive Design**: Optimized for touch interfaces
- **Offline Support**: Cached alert data with PWA
- **Push Notifications**: Ready for FCM integration

## Production Considerations

### Security
- Store API keys securely (environment variables, secret managers)
- Validate phone numbers and email addresses
- Implement rate limiting for notifications
- Use HTTPS for all API endpoints

### Scalability
- Use message queues (Redis, RabbitMQ) for high volume
- Implement database indexing for alert queries
- Use CDN for static email assets
- Monitor notification delivery rates

### Monitoring
- Track notification success/failure rates
- Monitor API quotas (Twilio, SendGrid)
- Log alert trigger events
- Set up alerting for service failures

## Troubleshooting

### Common Issues
1. **Email not sending**: Check SMTP settings and authentication
2. **SMS not sending**: Verify Twilio credentials and phone number format
3. **Alerts not triggering**: Check price monitoring service and database queries
4. **Quiet hours not working**: Verify timezone configuration

### Debug Mode
Enable debug logging in the notification service:
```javascript
const notificationService = createNotificationService({
  ...config,
  debug: true
});
```

## Cost Estimation

### SendGrid
- Free tier: 100 emails/day
- Essentials: $14.95/month for 50,000 emails

### Twilio SMS
- $0.0075 per SMS in US
- $1/month per phone number

### Gmail SMTP
- Free for personal use
- G Suite: $6/user/month

## Next Steps

1. **Backend Integration**: Implement the notification service in your backend
2. **Database Setup**: Create alert storage schemas
3. **Service Configuration**: Set up email and SMS providers
4. **Testing**: Thoroughly test all notification methods
5. **Monitoring**: Implement logging and monitoring
6. **Push Notifications**: Add Firebase Cloud Messaging for mobile push notifications

The AlertsManager component is ready to use and will work with demo data until the backend is implemented. All notification methods are designed to be production-ready with proper error handling and user experience considerations.
