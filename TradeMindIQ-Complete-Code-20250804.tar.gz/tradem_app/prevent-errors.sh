#!/bin/bash

# TradeMindIQ Error Prevention & System Verification Script
# Run this before any development work to prevent known issues

echo "🛡️ TradeMindIQ Error Prevention Check"
echo "====================================="
echo ""

# Track errors found
ERROR_COUNT=0
WARNING_COUNT=0

# Function to log errors
log_error() {
    echo "❌ ERROR: $1"
    ERROR_COUNT=$((ERROR_COUNT + 1))
}

log_warning() {
    echo "⚠️  WARNING: $1" 
    WARNING_COUNT=$((WARNING_COUNT + 1))
}

log_success() {
    echo "✅ $1"
}

# 1. File Integrity Checks
echo "🔍 File Integrity Verification"
echo "------------------------------"

# Check critical files exist and have content
critical_files=(
    "src/components/SettingsPanel.tsx"
    "src/components/MobileBottomNav.tsx" 
    "src/components/MobileSectionView.tsx"
    "backend-example/simpleServer.js"
    "src/App.tsx"
    "src/index.css"
)

for file in "${critical_files[@]}"; do
    if [ ! -f "$file" ]; then
        log_error "Missing critical file: $file"
    elif [ ! -s "$file" ]; then
        log_error "Empty file detected: $file (0 bytes)"
    else
        size=$(wc -c < "$file")
        if [ "$size" -lt 100 ]; then
            log_warning "File unusually small: $file ($size bytes)"
        else
            log_success "File OK: $file ($size bytes)"
        fi
    fi
done

echo ""

# 2. Syntax Verification
echo "🔧 Syntax Verification"
echo "----------------------"

# Check JavaScript/TypeScript syntax
if [ -f "backend-example/simpleServer.js" ]; then
    if node -c backend-example/simpleServer.js 2>/dev/null; then
        log_success "Backend syntax OK"
    else
        log_error "Backend syntax error in simpleServer.js"
    fi
fi

# Check TypeScript compilation (if available)
if command -v npx &> /dev/null; then
    if npx tsc --noEmit --skipLibCheck 2>/dev/null; then
        log_success "TypeScript compilation OK"
    else
        log_warning "TypeScript compilation issues detected"
    fi
fi

echo ""

# 3. Server Process Check
echo "🔄 Server Process Verification"
echo "------------------------------"

# Check if backend is running
if curl -s http://localhost:3002/api/reports/health > /dev/null 2>&1; then
    log_success "Backend server responding on port 3002"
    
    # Test critical endpoints
    endpoints=(
        "/api/reports/health"
        "/api/trades/history"
        "/api/user/preferences"
        "/api/reports/settings"
    )
    
    for endpoint in "${endpoints[@]}"; do
        if curl -s -H "user-id: demo-user" "http://localhost:3002$endpoint" > /dev/null 2>&1; then
            log_success "Endpoint OK: $endpoint"
        else
            log_error "Endpoint not responding: $endpoint"
        fi
    done
else
    log_warning "Backend server not running on port 3002"
    echo "  💡 Start with: cd backend-example && node simpleServer.js"
fi

# Check if frontend is accessible
if curl -s http://localhost:3000 > /dev/null 2>&1; then
    log_success "Frontend accessible on port 3000"
else
    log_warning "Frontend not accessible on port 3000"
    echo "  💡 Start with: npm start"
fi

echo ""

# 4. Dependencies Check
echo "📦 Dependencies Verification" 
echo "----------------------------"

# Check Node.js version
if command -v node &> /dev/null; then
    NODE_VERSION=$(node --version)
    log_success "Node.js version: $NODE_VERSION"
else
    log_error "Node.js not found"
fi

# Check npm packages
if [ -f "package.json" ]; then
    if [ -d "node_modules" ]; then
        log_success "Frontend dependencies installed"
    else
        log_warning "Frontend node_modules missing"
        echo "  💡 Run: npm install"
    fi
fi

if [ -f "backend-example/package.json" ]; then
    if [ -d "backend-example/node_modules" ]; then
        log_success "Backend dependencies installed"
    else
        log_warning "Backend node_modules missing"
        echo "  💡 Run: cd backend-example && npm install"
    fi
fi

# Check critical tools
tools=("curl" "jq")
for tool in "${tools[@]}"; do
    if command -v "$tool" &> /dev/null; then
        log_success "Tool available: $tool"
    else
        log_warning "Missing tool: $tool"
    fi
done

echo ""

# 5. Git Status Check
echo "📋 Git Status Check"
echo "-------------------"

if git status > /dev/null 2>&1; then
    CHANGES=$(git status --porcelain | wc -l)
    if [ "$CHANGES" -gt 0 ]; then
        log_warning "$CHANGES uncommitted changes detected"
        echo "  💡 Consider committing changes before development"
    else
        log_success "Git working directory clean"
    fi
else
    log_warning "Not in a git repository or git not available"
fi

echo ""

# 6. Recent Error Patterns Check
echo "🔍 Known Error Pattern Detection"
echo "--------------------------------"

# Check for common corruption patterns
if grep -r "import R.*const sections" src/ 2>/dev/null; then
    log_error "File corruption pattern detected in source files"
fi

# Check for empty React components
if find src/components -name "*.tsx" -empty 2>/dev/null | grep -q .; then
    log_error "Empty React component files detected"
fi

# Check for server file issues
if [ -f "backend-example/simpleServer.js" ]; then
    if ! grep -q "app.listen" backend-example/simpleServer.js; then
        log_error "Backend server missing app.listen - file may be incomplete"
    fi
    
    if ! grep -q "/api/user/preferences" backend-example/simpleServer.js; then
        log_warning "Backend missing user preferences endpoints"
    fi
fi

echo ""

# 7. Performance & Resource Check
echo "⚡ Performance Check"
echo "-------------------"

# Check disk space
DISK_USAGE=$(df . | tail -1 | awk '{print $5}' | sed 's/%//')
if [ "$DISK_USAGE" -gt 90 ]; then
    log_warning "Disk usage high: ${DISK_USAGE}%"
else
    log_success "Disk usage OK: ${DISK_USAGE}%"
fi

# Check memory usage
if command -v free &> /dev/null; then
    MEMORY_USAGE=$(free | grep '^Mem:' | awk '{printf("%.0f", $3/$2 * 100)}')
    if [ "$MEMORY_USAGE" -gt 90 ]; then
        log_warning "Memory usage high: ${MEMORY_USAGE}%"
    else
        log_success "Memory usage OK: ${MEMORY_USAGE}%"
    fi
elif command -v vm_stat &> /dev/null; then
    # macOS memory check
    log_success "Memory check available (macOS)"
fi

echo ""

# Summary Report
echo "📊 Prevention Check Summary"
echo "==========================="

if [ "$ERROR_COUNT" -eq 0 ] && [ "$WARNING_COUNT" -eq 0 ]; then
    echo "🎉 ALL CHECKS PASSED - System ready for development!"
    echo "✅ No errors or warnings detected"
elif [ "$ERROR_COUNT" -eq 0 ]; then
    echo "⚠️  WARNINGS DETECTED - Proceed with caution"
    echo "✅ No critical errors found"
    echo "⚠️  $WARNING_COUNT warnings need attention"
else
    echo "🚨 ERRORS DETECTED - Fix before proceeding!"
    echo "❌ $ERROR_COUNT critical errors found"
    echo "⚠️  $WARNING_COUNT warnings detected"
    echo ""
    echo "💡 Recommended actions:"
    echo "   1. Fix all critical errors first"
    echo "   2. Address warnings if possible"
    echo "   3. Re-run this script to verify fixes"
    echo "   4. Check ERROR_PREVENTION_GUIDE.md for solutions"
fi

echo ""
echo "📖 Documentation:"
echo "   🚨 Error Guide: ERROR_PREVENTION_GUIDE.md"
echo "   📋 Settings Errors: SETTINGS_PANEL_ERROR_LOG.md"
echo "   🧪 Test Script: test-system.sh"
echo ""

# Return appropriate exit code
if [ "$ERROR_COUNT" -gt 0 ]; then
    exit 1
elif [ "$WARNING_COUNT" -gt 0 ]; then
    exit 2
else
    exit 0
fi
