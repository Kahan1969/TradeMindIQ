#!/bin/bash

# TradeMindIQ System Recovery Script
# Fixes common issues and restarts services

echo "🔧 TradeMindIQ System Recovery"
echo "=============================="
echo ""

# Function to check if a port is in use
check_port() {
    local port=$1
    if lsof -i :$port > /dev/null 2>&1; then
        return 0  # Port is in use
    else
        return 1  # Port is free
    fi
}

# Function to kill processes on a specific port
kill_port() {
    local port=$1
    echo "🔄 Stopping processes on port $port..."
    lsof -ti :$port | xargs kill -9 2>/dev/null || true
    sleep 2
}

# Step 1: Stop existing processes
echo "🛑 Stopping existing services..."
pkill -f "node.*simpleServer" 2>/dev/null || true
pkill -f "node.*react-scripts" 2>/dev/null || true

# Kill specific ports if they're in use
if check_port 3000; then
    kill_port 3000
fi

if check_port 3002; then
    kill_port 3002
fi

echo "✅ Services stopped"
echo ""

# Step 2: Verify directory structure
echo "📁 Checking directory structure..."
WORK_DIR="/Users/kahangabar/Desktop/TradeMindIQ/tradem_app"

if [ ! -d "$WORK_DIR" ]; then
    echo "❌ Work directory not found: $WORK_DIR"
    exit 1
fi

cd "$WORK_DIR"

if [ ! -f "backend-example/simpleServer.js" ]; then
    echo "❌ Backend server file not found"
    exit 1
fi

if [ ! -f "package.json" ]; then
    echo "❌ Frontend package.json not found"
    exit 1
fi

echo "✅ Directory structure OK"
echo ""

# Step 3: Check dependencies
echo "📦 Checking dependencies..."

# Check backend dependencies
cd "$WORK_DIR/backend-example"
if [ ! -d "node_modules" ]; then
    echo "🔄 Installing backend dependencies..."
    npm install
fi

# Check frontend dependencies
cd "$WORK_DIR"
if [ ! -d "node_modules" ]; then
    echo "🔄 Installing frontend dependencies..."
    npm install
fi

echo "✅ Dependencies OK"
echo ""

# Step 4: Restart backend
echo "🚀 Starting backend server..."
cd "$WORK_DIR/backend-example"
node simpleServer.js &
BACKEND_PID=$!

# Wait for backend to start
sleep 3

# Check if backend is running
if curl -s http://localhost:3002/api/reports/health > /dev/null; then
    echo "✅ Backend started successfully on port 3002"
else
    echo "❌ Backend failed to start"
    kill $BACKEND_PID 2>/dev/null || true
    exit 1
fi

echo ""

# Step 5: Check frontend status
echo "🌐 Checking frontend status..."
if check_port 3000; then
    echo "✅ Frontend already running on port 3000"
else
    echo "ℹ️  Frontend not running. To start:"
    echo "   cd $WORK_DIR && npm start"
fi

echo ""

# Step 6: Verify system
echo "🧪 Running system verification..."
cd "$WORK_DIR"

if [ -x "./test-system.sh" ]; then
    echo "Running quick test..."
    timeout 10 ./test-system.sh || echo "⚠️  Test script took too long or failed"
else
    echo "⚠️  test-system.sh not found or not executable"
fi

echo ""
echo "🎉 Recovery Complete!"
echo "===================="
echo ""
echo "📊 System Status:"
echo "  🔧 Backend: http://localhost:3002 (Running)"
if check_port 3000; then
    echo "  🌐 Frontend: http://localhost:3000 (Running)"
else
    echo "  🌐 Frontend: Not running (start with 'npm start')"
fi
echo ""
echo "📖 Next Steps:"
echo "  1. Open http://localhost:3000 in your browser"
echo "  2. Navigate to the 📋 Reports tab"
echo "  3. Test the Export/Reporting features"
echo ""
echo "📚 Documentation:"
echo "  📋 README.md - Setup guide"
echo "  🚨 ERROR_PREVENTION_GUIDE.md - Troubleshooting"
echo "  🧪 test-system.sh - Full system test"
echo ""
echo "✅ System ready for use!"
