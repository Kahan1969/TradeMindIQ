// Example Express.js backend integration for TradeMindIQ Alerts
// This file demonstrates how to integrate the notification service with your backend

import express from 'express';
import cors from 'cors';
import { createNotificationService, getNotificationConfig, createAlertRoutes, AlertQueue } from '../src/utils/notificationService';
import { authenticateToken } from './auth.mjs';

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());

// Initialize notification service
const notificationConfig = getNotificationConfig();
const notificationService = createNotificationService(notificationConfig);
const alertQueue = new AlertQueue(notificationService);
const alertRoutes = createAlertRoutes(notificationService);

// In-memory storage for demo (use database in production)
let priceAlerts = [];
let signalAlerts = [];
let alertHistory = [];
let userSettings = new Map();

// Get all alerts for user
app.get('/api/alerts', authenticateToken, (req, res) => {
  const userPriceAlerts = priceAlerts.filter(alert => alert.userId === req.userId);
  const userSignalAlerts = signalAlerts.filter(alert => alert.userId === req.userId);
  const userHistory = alertHistory.filter(item => item.userId === req.userId);
  const settings = userSettings.get(req.userId) || {
    email: '',
    phone: '',
    emailEnabled: true,
    smsEnabled: false,
    pushEnabled: true,
    quietHours: {
      enabled: false,
      start: '22:00',
      end: '08:00'
    }
  };

  res.json({
    priceAlerts: userPriceAlerts,
    signalAlerts: userSignalAlerts,
    history: userHistory,
    settings: settings
  });
});

// Create price alert
app.post('/api/alerts/price', authenticateToken, (req, res) => {
  const { symbol, condition, targetPrice, notificationMethod } = req.body;
  
  const newAlert = {
    id: Date.now().toString(),
    userId: req.userId,
    symbol: symbol.toUpperCase(),
    condition,
    targetPrice: parseFloat(targetPrice),
    currentPrice: Math.random() * 200 + 100, // Mock current price
    isActive: true,
    createdAt: new Date().toISOString(),
    notificationMethod
  };

  priceAlerts.push(newAlert);
  
  // Add to alert history
  alertHistory.push({
    id: Date.now().toString(),
    userId: req.userId,
    type: 'price',
    title: 'Price Alert Created',
    message: `Created alert for ${symbol} to trigger when price goes ${condition} $${targetPrice}`,
    timestamp: new Date().toISOString(),
    status: 'sent',
    methods: ['app']
  });

  res.json(newAlert);
});

// Create signal alert
app.post('/api/alerts/signals', authenticateToken, (req, res) => {
  const { strategy, symbols, minConfidence, signalTypes, notificationMethod } = req.body;
  
  const newAlert = {
    id: Date.now().toString(),
    userId: req.userId,
    strategy,
    symbols,
    minConfidence,
    signalTypes,
    notificationMethod,
    isActive: true,
    createdAt: new Date().toISOString()
  };

  signalAlerts.push(newAlert);
  
  // Add to alert history
  alertHistory.push({
    id: Date.now().toString(),
    userId: req.userId,
    type: 'signal',
    title: 'Signal Alert Created',
    message: `Created alert for ${strategy} strategy with ${minConfidence}% minimum confidence`,
    timestamp: new Date().toISOString(),
    status: 'sent',
    methods: ['app']
  });

  res.json(newAlert);
});

// Toggle alert active status
// Toggle alert enabled/disabled status
app.patch('/api/alerts/:type/:id/toggle', authenticateToken, (req, res) => {
  const { type, id } = req.params;
  
  let alerts = type === 'price' ? priceAlerts : signalAlerts;
  const alertIndex = alerts.findIndex(alert => alert.id === id && alert.userId === req.userId);
  
  if (alertIndex === -1) {
    return res.status(404).json({ error: 'Alert not found' });
  }

  alerts[alertIndex].isActive = !alerts[alertIndex].isActive;
  
  res.json({ success: true, isActive: alerts[alertIndex].isActive });
});

// Delete alert
app.delete('/api/alerts/:type/:id', authenticateToken, (req, res) => {
  const { type, id } = req.params;
  
  if (type === 'price') {
    priceAlerts = priceAlerts.filter(alert => !(alert.id === id && alert.userId === req.userId));
  } else {
    signalAlerts = signalAlerts.filter(alert => !(alert.id === id && alert.userId === req.userId));
  }
  
  res.json({ success: true });
});

// Update alert settings
app.put('/api/alerts/settings', authenticateToken, (req, res) => {
  const settings = req.body;
  userSettings.set(req.userId, settings);
  
  res.json({ success: true, settings });
});

// Test notification
// Test notification endpoint
app.post('/api/alerts/test', authenticateToken, async (req, res) => {
  const { method } = req.body;
  const settings = userSettings.get(req.userId);
  
  if (!settings) {
    return res.status(400).json({ error: 'Please configure notification settings first' });
  }

  const testAlert = {
    type: 'signal',
    title: 'Test Notification',
    message: 'This is a test notification from TradeMindIQ alerts system. If you received this, your notifications are working correctly!',
    timestamp: new Date().toISOString()
  };

  const userPrefs = {
    email: settings.email,
    phone: settings.phone,
    methods: [method]
  };

  try {
    const result = await notificationService.sendAlert(testAlert, userPrefs);
    
    // Add to history
    alertHistory.push({
      id: Date.now().toString(),
      userId: req.userId,
      type: 'signal',
      title: 'Test Notification',
      message: testAlert.message,
      timestamp: new Date().toISOString(),
      status: result.success ? 'sent' : 'failed',
      methods: result.methods
    });

    res.json({
      success: result.success,
      message: result.success ? `Test ${method} sent successfully` : 'Failed to send notification',
      details: result
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to send test notification' });
  }
});

// Trigger price alert (for testing)
// Manual trigger for price alerts (for testing)
app.post('/api/alerts/price/trigger', authenticateToken, async (req, res) => {
  const { symbol, price, alertId } = req.body;
  
  const alert = priceAlerts.find(a => a.id === alertId && a.userId === req.userId);
  if (!alert) {
    return res.status(404).json({ error: 'Alert not found' });
  }

  const alertData = {
    type: 'price',
    title: `Price Alert: ${symbol}`,
    message: `${symbol} has ${alert.condition.replace('_', ' ')} $${alert.targetPrice}, currently at $${price}`,
    symbol,
    price,
    timestamp: new Date().toISOString()
  };

  const settings = userSettings.get(req.userId);
  const userPrefs = {
    email: settings?.email || '',
    phone: settings?.phone || '',
    methods: alert.notificationMethod
  };

  try {
    const result = await notificationService.sendAlert(alertData, userPrefs);
    
    // Add to history
    alertHistory.push({
      id: Date.now().toString(),
      userId: req.userId,
      type: 'price',
      title: alertData.title,
      message: alertData.message,
      timestamp: new Date().toISOString(),
      status: result.success ? 'sent' : 'failed',
      methods: result.methods
    });

    // Mark alert as triggered
    alert.triggeredAt = new Date().toISOString();
    alert.isActive = false; // Disable after triggering

    res.json({ success: result.success, details: result });
  } catch (error) {
    res.status(500).json({ error: 'Failed to trigger price alert' });
  }
});

// Trigger signal alert (for testing)
// Manual trigger for signal alerts (for testing)
app.post('/api/alerts/signals/trigger', authenticateToken, async (req, res) => {
  const { symbol, signal, confidence, strategy } = req.body;
  
  // Find matching signal alerts
  const matchingAlerts = signalAlerts.filter(alert => {
    if (!alert.isActive || alert.userId !== req.userId) return false;
    if (alert.strategy !== 'all' && alert.strategy !== strategy) return false;
    if (alert.symbols.length > 0 && !alert.symbols.includes(symbol)) return false;
    if (!alert.signalTypes.includes(signal)) return false;
    if (confidence < alert.minConfidence) return false;
    return true;
  });

  const results = [];

  for (const alert of matchingAlerts) {
    const alertData = {
      type: 'signal',
      title: `${signal.toUpperCase()} Signal: ${symbol}`,
      message: `AI detected a ${signal} signal for ${symbol} using ${strategy} strategy`,
      symbol,
      confidence,
      strategy,
      timestamp: new Date().toISOString()
    };

    const settings = userSettings.get(req.userId);
    const userPrefs = {
      email: settings?.email || '',
      phone: settings?.phone || '',
      methods: alert.notificationMethod
    };

    try {
      const result = await notificationService.sendAlert(alertData, userPrefs);
      
      // Add to history
      alertHistory.push({
        id: Date.now().toString(),
        userId: req.userId,
        type: 'signal',
        title: alertData.title,
        message: alertData.message,
        timestamp: new Date().toISOString(),
        status: result.success ? 'sent' : 'failed',
        methods: result.methods
      });

      results.push({ alertId: alert.id, success: result.success, details: result });
    } catch (error) {
      results.push({ alertId: alert.id, success: false, error: error.message });
    }
  }

  res.json({ processed: results.length, results });
});

// Price monitoring simulation (runs every minute)
const simulatePriceMonitoring = () => {
  const activeAlerts = priceAlerts.filter(alert => alert.isActive);
  
  for (const alert of activeAlerts) {
    // Simulate price movement
    const priceChange = (Math.random() - 0.5) * 10; // +/- $5 change
    const newPrice = Math.max(1, alert.currentPrice + priceChange);
    
    // Check if alert should trigger
    let shouldTrigger = false;
    switch (alert.condition) {
      case 'above':
        shouldTrigger = newPrice > alert.targetPrice && alert.currentPrice <= alert.targetPrice;
        break;
      case 'below':
        shouldTrigger = newPrice < alert.targetPrice && alert.currentPrice >= alert.targetPrice;
        break;
      case 'crosses_above':
        shouldTrigger = alert.currentPrice <= alert.targetPrice && newPrice > alert.targetPrice;
        break;
      case 'crosses_below':
        shouldTrigger = alert.currentPrice >= alert.targetPrice && newPrice < alert.targetPrice;
        break;
    }

    alert.currentPrice = newPrice;

    if (shouldTrigger) {
      // Trigger alert
      const alertData = {
        type: 'price',
        title: `Price Alert: ${alert.symbol}`,
        message: `${alert.symbol} has ${alert.condition.replace('_', ' ')} $${alert.targetPrice}, currently at $${newPrice.toFixed(2)}`,
        symbol: alert.symbol,
        price: newPrice,
        timestamp: new Date().toISOString()
      };

      const settings = userSettings.get(alert.userId);
      if (settings) {
        const userPrefs = {
          email: settings.email,
          phone: settings.phone,
          methods: alert.notificationMethod
        };

        alertQueue.enqueue(alertData, userPrefs);
      }

      // Mark alert as triggered
      alert.triggeredAt = new Date().toISOString();
      alert.isActive = false;

      console.log(`Price alert triggered for ${alert.symbol} at $${newPrice.toFixed(2)}`);
    }
  }
};

// AI signal simulation (runs every 5 minutes)
const simulateAISignals = () => {
  const symbols = ['AAPL', 'MSFT', 'GOOGL', 'TSLA', 'AMZN'];
  const strategies = ['momentum', 'swing', 'scalp'];
  const signals = ['buy', 'sell', 'hold'];

  const symbol = symbols[Math.floor(Math.random() * symbols.length)];
  const strategy = strategies[Math.floor(Math.random() * strategies.length)];
  const signal = signals[Math.floor(Math.random() * signals.length)];
  const confidence = Math.floor(Math.random() * 40) + 60; // 60-100%

  // Find matching signal alerts
  const matchingAlerts = signalAlerts.filter(alert => {
    if (!alert.isActive) return false;
    if (alert.strategy !== 'all' && alert.strategy !== strategy) return false;
    if (alert.symbols.length > 0 && !alert.symbols.includes(symbol)) return false;
    if (!alert.signalTypes.includes(signal)) return false;
    if (confidence < alert.minConfidence) return false;
    return true;
  });

  for (const alert of matchingAlerts) {
    const alertData = {
      type: 'signal',
      title: `${signal.toUpperCase()} Signal: ${symbol}`,
      message: `AI detected a ${signal} signal for ${symbol} using ${strategy} strategy`,
      symbol,
      confidence,
      strategy,
      timestamp: new Date().toISOString()
    };

    const settings = userSettings.get(alert.userId);
    if (settings) {
      const userPrefs = {
        email: settings.email,
        phone: settings.phone,
        methods: alert.notificationMethod
      };

      alertQueue.enqueue(alertData, userPrefs);
    }

    console.log(`AI signal generated: ${signal} ${symbol} (${confidence}% confidence)`);
  }
};

// Start monitoring services
setInterval(simulatePriceMonitoring, 60000); // Every minute
setInterval(simulateAISignals, 300000); // Every 5 minutes

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    alerts: {
      priceAlerts: priceAlerts.length,
      signalAlerts: signalAlerts.length,
      alertHistory: alertHistory.length
    }
  });
});

// Error handling middleware
app.use((error, req, res, next) => {
  console.error('API Error:', error);
  res.status(500).json({ error: 'Internal server error' });
});

// Start server
app.listen(PORT, () => {
  console.log(`TradeMindIQ Alerts Backend running on port ${PORT}`);
  console.log(`Health check: http://localhost:${PORT}/api/health`);
});

export default app;
