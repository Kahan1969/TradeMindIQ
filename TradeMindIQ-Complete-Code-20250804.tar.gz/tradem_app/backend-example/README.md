# TradeMindIQ Reports Backend

This is the backend server implementation for TradeMindIQ's Export/Reporting Tools. It provides APIs for automated trade reports, email summaries, and data exports.

## Features

### 🔄 Automated Reporting
- **Scheduled Email Summaries**: Daily/weekly automated email reports
- **Auto Export**: Scheduled PDF/CSV exports with configurable frequency
- **Background Processing**: Cron-based scheduling for automated tasks

### 📊 Export APIs
- **PDF Reports**: Comprehensive trading performance reports
- **CSV Exports**: Trade history data in spreadsheet format
- **Custom Date Ranges**: Filter exports by specific time periods

### 📧 Notification System
- **Email Templates**: Professional HTML email templates
- **Multi-Provider Support**: Gmail, SendGrid, AWS SES integration
- **Test Notifications**: Send test emails to verify configuration

### 📈 Analytics
- **Performance Metrics**: Win rate, P&L, Sharpe ratio calculations
- **Trade Analysis**: Detailed trade breakdowns and summaries
- **Demo Data**: Built-in sample trade data for testing

## Quick Start

### Prerequisites
- Node.js 16+ 
- npm or yarn package manager

### Installation

1. **Install Dependencies**
   ```bash
   cd backend-example
   npm install
   ```

2. **Environment Setup**
   Create a `.env` file in the backend-example directory:
   ```env
   PORT=3002
   
   # Email Configuration (Choose one provider)
   EMAIL_PROVIDER=gmail
   GMAIL_USER=your-email@gmail.com
   GMAIL_PASS=your-app-password
   
   # Alternative: SendGrid
   # EMAIL_PROVIDER=sendgrid
   # SENDGRID_API_KEY=your-sendgrid-api-key
   
   # Alternative: AWS SES
   # EMAIL_PROVIDER=ses
   # AWS_REGION=us-east-1
   # AWS_ACCESS_KEY_ID=your-access-key
   # AWS_SECRET_ACCESS_KEY=your-secret-key
   
   # SMS Configuration (Optional)
   TWILIO_ACCOUNT_SID=your-twilio-sid
   TWILIO_AUTH_TOKEN=your-twilio-token
   TWILIO_PHONE_NUMBER=+1234567890
   ```

3. **Start the Server**
   ```bash
   # Development mode with auto-reload
   npm run dev
   
   # Production mode
   npm start
   ```

4. **Verify Installation**
   Visit: http://localhost:3002/api/reports/health

## API Endpoints

### Core APIs

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/trades/history` | Get trade history and performance metrics |
| `POST` | `/api/reports/export/pdf` | Generate and download PDF report |
| `POST` | `/api/reports/export/csv` | Generate and download CSV export |
| `GET` | `/api/reports/settings` | Get user report settings |
| `PUT` | `/api/reports/settings` | Update report settings |
| `POST` | `/api/reports/test-summary` | Send test email summary |
| `GET` | `/api/reports/exports` | Get export history |
| `GET` | `/api/reports/health` | Health check |

### Example Usage

#### Get Trade History
```bash
curl -H "user-id: demo-user" http://localhost:3002/api/trades/history
```

#### Export PDF Report
```bash
curl -X POST \
  -H "Content-Type: application/json" \
  -H "user-id: demo-user" \
  -d '{
    "trades": [...],
    "metrics": {...},
    "dateRange": {
      "startDate": "2024-01-01",
      "endDate": "2024-01-31"
    }
  }' \
  http://localhost:3002/api/reports/export/pdf
```

#### Update Report Settings
```bash
curl -X PUT \
  -H "Content-Type: application/json" \
  -H "user-id: demo-user" \
  -d '{
    "emailSummaries": {
      "enabled": true,
      "frequency": "daily",
      "time": "08:00",
      "email": "user@example.com"
    }
  }' \
  http://localhost:3002/api/reports/settings
```

## Configuration

### Email Provider Setup

#### Gmail
1. Enable 2-factor authentication on your Google account
2. Generate an App Password: Google Account → Security → App passwords
3. Use your Gmail address and app password in the environment variables

#### SendGrid
1. Create a SendGrid account at sendgrid.com
2. Generate an API key in Settings → API Keys
3. Verify your sender email address

#### AWS SES
1. Set up AWS SES in your preferred region
2. Verify your email address or domain
3. Configure AWS credentials with SES permissions

### Scheduled Reports Configuration

The server automatically sets up cron jobs based on user settings:

- **Daily Reports**: Sent at the specified time each day
- **Weekly Reports**: Sent on Mondays at the specified time
- **Auto Exports**: Generated at 2 AM based on frequency

## Integration with Frontend

This backend integrates seamlessly with the TradeMindIQ frontend Export/Reporting Tools component. The frontend makes API calls to these endpoints for:

1. **Live Data**: Fetching trade history and metrics
2. **Export Actions**: Generating PDF/CSV downloads
3. **Settings Management**: Configuring automated reports
4. **Test Functions**: Sending test emails

## Demo Data

The server includes built-in demo trade data for testing:
- 50 sample trades across multiple symbols (AAPL, MSFT, GOOGL, TSLA, AMZN)
- Realistic profit/loss calculations
- Multiple trading strategies (momentum, swing, scalp)
- Performance metrics calculation

## Monitoring and Logs

The server logs important events:
- Scheduled report generations
- Email sending attempts
- API request errors
- Cron job executions

Check the console output for real-time logging information.

## Production Deployment

### Recommendations

1. **Database Integration**: Replace in-memory storage with a proper database (PostgreSQL, MongoDB)
2. **File Storage**: Use cloud storage (AWS S3, Google Cloud) for generated reports
3. **Authentication**: Implement proper JWT-based authentication
4. **Rate Limiting**: Add API rate limiting for production use
5. **Error Monitoring**: Integrate with error monitoring services (Sentry, Rollbar)
6. **Load Balancing**: Use PM2 or similar for process management

### Environment Variables for Production
```env
NODE_ENV=production
PORT=3002
DATABASE_URL=postgresql://user:pass@host:port/db
REDIS_URL=redis://host:port
JWT_SECRET=your-jwt-secret
AWS_S3_BUCKET=your-reports-bucket
SENTRY_DSN=your-sentry-dsn
```

## Troubleshooting

### Common Issues

1. **Email not sending**: Verify email provider credentials and network connectivity
2. **Cron jobs not running**: Check server timezone and cron syntax
3. **PDF generation errors**: Ensure sufficient memory and disk space
4. **CORS issues**: Verify frontend URL is in CORS whitelist

### Health Check
Always check the health endpoint first:
```bash
curl http://localhost:3002/api/reports/health
```

### Logs
Check console output for detailed error messages and execution logs.

## Support

For technical support or questions about the TradeMindIQ Reports Backend:
1. Check the console logs for error details
2. Verify environment configuration
3. Test with the demo endpoints first
4. Review the API documentation above

## License

This software is part of the TradeMindIQ trading platform and is provided for demonstration purposes.
