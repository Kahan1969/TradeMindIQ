// Additional Sensitive Endpoints for TradeMindIQ
// These endpoints handle portfolio, orders, and financial data
const express = require('express');
const { authenticateToken, requireAdmin } = require('./auth');

const app = express();

// ========================
// Portfolio Management Endpoints (High Security)
// ========================

// Get user portfolio summary
app.get('/api/portfolio/summary', authenticateToken, (req, res) => {
  // Portfolio data is highly sensitive - requires authentication
  const portfolioData = {
    userId: req.user.id,
    totalValue: 125450.75,
    dailyPnL: 2845.32,
    positions: [
      { symbol: 'AAPL', quantity: 150, value: 28500.00, pnl: 450.25 },
      { symbol: 'TSLA', quantity: 75, value: 22125.50, pnl: -125.75 },
      { symbol: 'GOOGL', quantity: 50, value: 15750.25, pnl: 320.15 }
    ],
    timestamp: new Date().toISOString()
  };
  
  res.json(portfolioData);
});

// Get detailed position information
app.get('/api/portfolio/positions', authenticateToken, (req, res) => {
  // Detailed position data requires authentication
  const positions = [
    {
      symbol: 'AAPL',
      quantity: 150,
      avgCost: 185.50,
      currentPrice: 190.00,
      marketValue: 28500.00,
      unrealizedPnL: 675.00,
      dayChange: 2.25,
      dayChangePercent: 1.20
    },
    {
      symbol: 'TSLA',
      quantity: 75,
      avgCost: 297.50,
      currentPrice: 295.00,
      marketValue: 22125.00,
      unrealizedPnL: -187.50,
      dayChange: -5.25,
      dayChangePercent: -1.75
    }
  ];
  
  res.json({ positions, userId: req.user.id });
});

// ========================
// Order Management Endpoints (High Security)
// ========================

// Place new order
app.post('/api/orders/place', authenticateToken, (req, res) => {
  const { symbol, side, quantity, orderType, price } = req.body;
  
  // Validate order parameters
  if (!symbol || !side || !quantity || !orderType) {
    return res.status(400).json({ error: 'Missing required order parameters' });
  }
  
  // Simulate order placement
  const order = {
    orderId: `ORD-${Date.now()}`,
    userId: req.user.id,
    symbol: symbol.toUpperCase(),
    side: side.toLowerCase(), // 'buy' or 'sell'
    quantity: parseInt(quantity),
    orderType: orderType.toLowerCase(), // 'market', 'limit', 'stop'
    price: orderType === 'market' ? null : parseFloat(price),
    status: 'pending',
    timestamp: new Date().toISOString()
  };
  
  console.log(`📝 Order placed: ${JSON.stringify(order)}`);
  
  res.status(201).json({
    message: 'Order placed successfully',
    order: order
  });
});

// Get user orders
app.get('/api/orders/history', authenticateToken, (req, res) => {
  // Order history is sensitive financial data
  const orders = [
    {
      orderId: 'ORD-1754361001',
      symbol: 'AAPL',
      side: 'buy',
      quantity: 100,
      orderType: 'limit',
      price: 185.50,
      status: 'filled',
      fillPrice: 185.50,
      timestamp: '2025-08-04T10:30:00.000Z'
    },
    {
      orderId: 'ORD-1754361002',
      symbol: 'TSLA',
      side: 'sell',
      quantity: 25,
      orderType: 'market',
      price: null,
      status: 'filled',
      fillPrice: 295.75,
      timestamp: '2025-08-04T14:15:00.000Z'
    }
  ];
  
  res.json({ orders, userId: req.user.id });
});

// Cancel order
app.delete('/api/orders/:orderId', authenticateToken, (req, res) => {
  const { orderId } = req.params;
  
  console.log(`❌ Order cancellation requested: ${orderId} by user ${req.user.id}`);
  
  res.json({
    message: 'Order cancelled successfully',
    orderId: orderId,
    userId: req.user.id
  });
});

// ========================
// Account & Balance Endpoints (Critical Security)
// ========================

// Get account balance
app.get('/api/account/balance', authenticateToken, (req, res) => {
  // Account balance is highly sensitive financial information
  const balance = {
    userId: req.user.id,
    cashBalance: 25750.45,
    totalEquity: 125450.75,
    buyingPower: 51500.90,
    marginUsed: 15200.30,
    currency: 'USD',
    timestamp: new Date().toISOString()
  };
  
  res.json(balance);
});

// Get account statements
app.get('/api/account/statements', authenticateToken, (req, res) => {
  // Account statements contain sensitive financial history
  const statements = [
    {
      date: '2025-08-01',
      type: 'monthly',
      description: 'Monthly Statement - July 2025',
      downloadUrl: '/api/account/statements/202507/download'
    },
    {
      date: '2025-07-01',
      type: 'monthly',
      description: 'Monthly Statement - June 2025',
      downloadUrl: '/api/account/statements/202506/download'
    }
  ];
  
  res.json({ statements, userId: req.user.id });
});

// Download account statement
app.get('/api/account/statements/:period/download', authenticateToken, (req, res) => {
  const { period } = req.params;
  
  console.log(`📄 Statement download requested: ${period} by user ${req.user.id}`);
  
  // In production, this would generate or retrieve actual PDF statement
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="statement-${period}.pdf"`);
  res.send(`Mock PDF content for statement ${period}`);
});

// ========================
// Payment & Transfer Endpoints (Maximum Security)
// ========================

// Initiate fund transfer
app.post('/api/payments/transfer', authenticateToken, (req, res) => {
  const { amount, direction, bankAccountId } = req.body;
  
  // Additional validation for financial transactions
  if (!amount || !direction || amount <= 0) {
    return res.status(400).json({ error: 'Invalid transfer parameters' });
  }
  
  const transfer = {
    transferId: `TXN-${Date.now()}`,
    userId: req.user.id,
    amount: parseFloat(amount),
    direction: direction, // 'deposit' or 'withdrawal'
    bankAccountId: bankAccountId,
    status: 'pending',
    estimatedCompletion: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(), // 3 days
    timestamp: new Date().toISOString()
  };
  
  console.log(`💰 Transfer initiated: ${JSON.stringify(transfer)}`);
  
  res.status(201).json({
    message: 'Transfer initiated successfully',
    transfer: transfer
  });
});

// Get transfer history
app.get('/api/payments/history', authenticateToken, (req, res) => {
  // Payment history is sensitive financial data
  const transfers = [
    {
      transferId: 'TXN-1754360001',
      amount: 10000.00,
      direction: 'deposit',
      status: 'completed',
      timestamp: '2025-08-01T09:00:00.000Z'
    },
    {
      transferId: 'TXN-1754360002',
      amount: 2500.00,
      direction: 'withdrawal',
      status: 'completed',
      timestamp: '2025-07-28T15:30:00.000Z'
    }
  ];
  
  res.json({ transfers, userId: req.user.id });
});

// ========================
// Admin-Only Endpoints (Highest Security)
// ========================

// Get all users (admin only)
app.get('/api/admin/users', authenticateToken, requireAdmin, (req, res) => {
  console.log(`👑 Admin user list requested by ${req.user.id}`);
  
  // Mock user data (in production, fetch from database)
  const users = [
    { id: 'demo-user', email: 'demo@tradmindiq.com', role: 'trader', status: 'active' },
    { id: 'admin-user', email: 'admin@tradmindiq.com', role: 'admin', status: 'active' }
  ];
  
  res.json({ users, requestedBy: req.user.id });
});

// Get system metrics (admin only)
app.get('/api/admin/metrics', authenticateToken, requireAdmin, (req, res) => {
  console.log(`📊 System metrics requested by admin ${req.user.id}`);
  
  const metrics = {
    totalUsers: 1247,
    activeUsers: 892,
    totalTrades: 15632,
    systemUptime: '99.8%',
    totalVolume: 45672891.50,
    timestamp: new Date().toISOString()
  };
  
  res.json({ metrics, requestedBy: req.user.id });
});

// Export endpoint documentation
const sensitiveEndpoints = {
  portfolio: [
    'GET /api/portfolio/summary',
    'GET /api/portfolio/positions'
  ],
  orders: [
    'POST /api/orders/place',
    'GET /api/orders/history',
    'DELETE /api/orders/:orderId'
  ],
  account: [
    'GET /api/account/balance',
    'GET /api/account/statements',
    'GET /api/account/statements/:period/download'
  ],
  payments: [
    'POST /api/payments/transfer',
    'GET /api/payments/history'
  ],
  admin: [
    'GET /api/admin/users',
    'GET /api/admin/metrics'
  ]
};

module.exports = {
  app,
  sensitiveEndpoints
};
