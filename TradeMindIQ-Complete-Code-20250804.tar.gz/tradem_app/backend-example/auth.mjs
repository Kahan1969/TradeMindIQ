// ES Module version of JWT Authentication middleware for TradeMindIQ Backend
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';

// JWT Secret - In production, use environment variable
const JWT_SECRET = process.env.JWT_SECRET || 'tradmindiq-super-secret-key-2025';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '24h';

// In-memory user store for demo (in production, use database)
const users = new Map();

// Demo users for testing
const initDemoUsers = async () => {
  const demoUsers = [
    { 
      id: 'demo-user', 
      email: 'demo@tradmindiq.com', 
      password: 'demo123',
      name: 'Demo User',
      username: 'demo', // Add username alias
      role: 'trader',
      createdAt: new Date().toISOString()
    },
    { 
      id: 'admin-user', 
      email: 'admin@tradmindiq.com', 
      password: 'admin123',
      name: 'Admin User',
      username: 'admin', // Add username alias
      role: 'admin',
      createdAt: new Date().toISOString()
    }
  ];

  for (const user of demoUsers) {
    const hashedPassword = await bcrypt.hash(user.password, 10);
    users.set(user.email, {
      ...user,
      password: hashedPassword
    });
    // Also store by username for easy lookup
    users.set(user.username, {
      ...user,
      password: hashedPassword
    });
  }

  console.log('🔐 Demo users initialized for testing');
};

// Generate JWT token
const generateToken = (user) => {
  const payload = {
    id: user.id,
    email: user.email,
    role: user.role,
    name: user.name
  };

  return jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
};

// Verify JWT token
const verifyToken = (token) => {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      throw new Error('Token expired');
    } else if (error.name === 'JsonWebTokenError') {
      throw new Error('Invalid token');
    } else {
      throw new Error('Token verification failed');
    }
  }
};

// Authentication middleware
const authenticateToken = (req, res, next) => {
  // Check for token in Authorization header
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

  // Fallback to demo mode for development
  if (!token) {
    // Demo mode - create temporary demo user
    req.user = {
      id: 'demo-user',
      email: 'demo@tradmindiq.com',
      role: 'trader',
      name: 'Demo User',
      isDemoMode: true
    };
    req.userId = req.user.id; // Backward compatibility
    return next();
  }

  try {
    const decoded = verifyToken(token);
    req.user = decoded;
    req.userId = decoded.id; // Backward compatibility
    next();
  } catch (error) {
    return res.status(401).json({ 
      error: 'Access denied', 
      message: error.message,
      code: 'INVALID_TOKEN'
    });
  }
};

// Admin role middleware
const requireAdmin = (req, res, next) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ 
      error: 'Insufficient permissions', 
      message: 'Admin access required',
      code: 'INSUFFICIENT_PERMISSIONS'
    });
  }
  next();
};

// Rate limiting for authentication (simple in-memory implementation)
const authAttempts = new Map();
const MAX_ATTEMPTS = 10; // Increased for testing
const LOCKOUT_TIME = 5 * 60 * 1000; // 5 minutes (reduced for testing)

const checkAuthRateLimit = (req, res, next) => {
  const clientIP = req.ip || req.connection.remoteAddress || 'unknown';
  const now = Date.now();
  
  const attempts = authAttempts.get(clientIP) || { count: 0, lastAttempt: 0 };
  
  // Reset if lockout period has passed
  if (now - attempts.lastAttempt > LOCKOUT_TIME) {
    attempts.count = 0;
  }
  
  if (attempts.count >= MAX_ATTEMPTS) {
    const timeLeft = Math.ceil((LOCKOUT_TIME - (now - attempts.lastAttempt)) / 60000);
    return res.status(429).json({
      error: 'Too many authentication attempts',
      message: `Rate limit exceeded. Try again in ${timeLeft} minutes`,
      code: 'RATE_LIMIT_EXCEEDED'
    });
  }
  
  // Increment attempt count
  attempts.count += 1;
  attempts.lastAttempt = now;
  authAttempts.set(clientIP, attempts);
  
  next();
};

// User registration
const registerUser = async (userData) => {
  const { email, password, name } = userData;
  
  if (users.has(email)) {
    throw new Error('User already exists');
  }

  if (password.length < 6) {
    throw new Error('Password must be at least 6 characters long');
  }

  const hashedPassword = await bcrypt.hash(password, 10);
  const user = {
    id: `user-${Date.now()}`,
    email,
    password: hashedPassword,
    name: name || email.split('@')[0],
    role: 'trader',
    createdAt: new Date().toISOString(),
    lastLogin: null
  };

  users.set(email, user);

  // Return user without password
  const { password: _, ...userWithoutPassword } = user;
  return userWithoutPassword;
};

// User login
const loginUser = async (email, password) => {
  const user = users.get(email);
  
  if (!user) {
    throw new Error('Invalid credentials');
  }

  const isPasswordValid = await bcrypt.compare(password, user.password);
  
  if (!isPasswordValid) {
    throw new Error('Invalid credentials');
  }

  // Update last login
  user.lastLogin = new Date().toISOString();

  // Generate token
  const token = generateToken(user);

  // Return user without password and token
  const { password: _, ...userWithoutPassword } = user;
  return {
    user: userWithoutPassword,
    token,
    expiresIn: JWT_EXPIRES_IN
  };
};

// Get user profile
const getUserProfile = async (userId) => {
  const user = Array.from(users.values()).find(u => u.id === userId);
  if (!user) {
    throw new Error('User not found');
  }

  const { password: _, ...userWithoutPassword } = user;
  return userWithoutPassword;
};

// Update user profile
const updateUserProfile = async (userId, updateData) => {
  const user = Array.from(users.values()).find(u => u.id === userId);
  if (!user) {
    throw new Error('User not found');
  }

  // Allow updating name and email
  if (updateData.name) user.name = updateData.name;
  if (updateData.email && updateData.email !== user.email) {
    if (users.has(updateData.email)) {
      throw new Error('Email already in use');
    }
    // Update email key in map
    users.delete(user.email);
    user.email = updateData.email;
    users.set(user.email, user);
  }

  user.updatedAt = new Date().toISOString();

  const { password: _, ...userWithoutPassword } = user;
  return userWithoutPassword;
};

// Change password
const changePassword = async (userId, currentPassword, newPassword) => {
  const user = Array.from(users.values()).find(u => u.id === userId);
  if (!user) {
    throw new Error('User not found');
  }

  const isCurrentPasswordValid = await bcrypt.compare(currentPassword, user.password);
  if (!isCurrentPasswordValid) {
    throw new Error('Current password is incorrect');
  }

  if (newPassword.length < 6) {
    throw new Error('New password must be at least 6 characters long');
  }

  const hashedNewPassword = await bcrypt.hash(newPassword, 10);
  user.password = hashedNewPassword;
  user.updatedAt = new Date().toISOString();

  return { message: 'Password changed successfully' };
};

export {
  initDemoUsers,
  generateToken,
  verifyToken,
  authenticateToken,
  requireAdmin,
  checkAuthRateLimit,
  registerUser,
  loginUser,
  getUserProfile,
  updateUserProfile,
  changePassword,
  JWT_SECRET,
  JWT_EXPIRES_IN
};
