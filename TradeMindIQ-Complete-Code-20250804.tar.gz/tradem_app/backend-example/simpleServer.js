// Standalone Express.js backend for TradeMindIQ Export/Reporting Tools
// This runs independently and provides APIs for the frontend
const express = require('express');
const cors = require('cors');
const { 
  initDemoUsers,
  authenticateToken,
  requireAdmin,
  checkAuthRateLimit,
  registerUser,
  loginUser,
  getUserProfile,
  updateUserProfile,
  changePassword
} = require('./auth');

const app = express();
const PORT = process.env.PORT || 3002;

// Middleware
app.use(cors());
app.use(express.json());

// Initialize demo users on startup
initDemoUsers();

// In-memory storage for demo
let tradeHistory = [];
let reportSettings = new Map();
let exportHistory = [];
let userPreferences = new Map();

// Demo trade data generator
const generateDemoTrades = () => {
  const symbols = ['AAPL', 'MSFT', 'GOOGL', 'TSLA', 'AMZN'];
  const strategies = ['momentum', 'swing', 'scalp'];
  const trades = [];

  for (let i = 0; i < 50; i++) {
    const timestamp = new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000);
    const symbol = symbols[Math.floor(Math.random() * symbols.length)];
    const strategy = strategies[Math.floor(Math.random() * strategies.length)];
    const type = Math.random() > 0.5 ? 'buy' : 'sell';
    const quantity = Math.floor(Math.random() * 200) + 1;
    const price = Math.random() * 300 + 50;
    const commission = 1.00;
    const profit = type === 'sell' ? (Math.random() - 0.4) * 500 : undefined;

    trades.push({
      id: (i + 1).toString(),
      symbol,
      type,
      quantity,
      price,
      timestamp: timestamp.toISOString(),
      strategy,
      profit,
      commission,
      total: type === 'buy' ? quantity * price + commission : quantity * price - commission
    });
  }

  return trades.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
};

// Initialize demo data
tradeHistory = generateDemoTrades();

// Simple auth middleware
const authenticate = (req, res, next) => {
  const userId = req.headers['user-id'] || 'demo-user';
  req.userId = userId;
  next();
};

// Metrics calculation
const calculateMetrics = (trades) => {
  const completedTrades = trades.filter(t => t.profit !== undefined);
  const totalTrades = completedTrades.length;
  const winningTrades = completedTrades.filter(t => t.profit > 0);
  const losingTrades = completedTrades.filter(t => t.profit <= 0);
  
  const totalProfit = completedTrades.reduce((sum, t) => sum + (t.profit || 0), 0);
  const totalCommissions = trades.reduce((sum, t) => sum + t.commission, 0);
  const netProfit = totalProfit - totalCommissions;

  const winRate = totalTrades > 0 ? (winningTrades.length / totalTrades * 100) : 0;
  const avgTradeSize = trades.length > 0 ? trades.reduce((sum, t) => sum + t.total, 0) / trades.length : 0;
  const bestTrade = completedTrades.length > 0 ? Math.max(...completedTrades.map(t => t.profit)) : 0;
  const worstTrade = completedTrades.length > 0 ? Math.min(...completedTrades.map(t => t.profit)) : 0;
  
  const returns = completedTrades.map(t => t.profit / t.total);
  const avgReturn = returns.length > 0 ? returns.reduce((sum, r) => sum + r, 0) / returns.length : 0;
  const returnStdDev = returns.length > 1 ? Math.sqrt(returns.reduce((sum, r) => sum + Math.pow(r - avgReturn, 2), 0) / (returns.length - 1)) : 0;
  const sharpeRatio = returnStdDev > 0 ? avgReturn / returnStdDev : 0;

  return {
    totalTrades,
    winRate: Math.round(winRate * 100) / 100,
    netProfit: Math.round(netProfit * 100) / 100,
    sharpeRatio: Math.round(sharpeRatio * 100) / 100,
    bestTrade: Math.round(bestTrade * 100) / 100,
    worstTrade: Math.round(worstTrade * 100) / 100,
    avgTradeSize: Math.round(avgTradeSize * 100) / 100,
    totalCommissions: Math.round(totalCommissions * 100) / 100
  };
};

// ========================
// Authentication Routes
// ========================

// User registration
app.post('/api/auth/register', checkAuthRateLimit, registerUser);

// User login
app.post('/api/auth/login', checkAuthRateLimit, loginUser);

// Get user profile (protected)
app.get('/api/auth/profile', authenticateToken, getUserProfile);

// Update user profile (protected)
app.put('/api/auth/profile', authenticateToken, updateUserProfile);

// Change password (protected)
app.put('/api/auth/change-password', authenticateToken, changePassword);

// ========================
// Application Routes (Protected)
// ========================

// Health check
app.get('/api/reports/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    timestamp: new Date().toISOString(),
    trades: tradeHistory.length
  });
});

// Get trade history with metrics
app.get('/api/trades/history', authenticateToken, (req, res) => {
  const metrics = calculateMetrics(tradeHistory);
  
  res.json({
    trades: tradeHistory,
    metrics: metrics,
    message: 'Demo data loaded successfully'
  });
});

// Export to PDF
app.post('/api/reports/export/pdf', authenticateToken, async (req, res) => {
  try {
    const { trades, metrics, dateRange } = req.body;
    
    console.log(`📄 PDF Export requested for ${trades.length} trades`);
    
    // Generate demo PDF content
    const reportContent = generateTextReport(trades, metrics, dateRange);
    
    // Add to export history
    exportHistory.unshift({
      id: Date.now().toString(),
      userId: req.userId,
      type: 'pdf',
      filename: `TradeMindIQ_Report_${dateRange.startDate}_to_${dateRange.endDate}.txt`,
      createdAt: new Date().toISOString(),
      status: 'completed',
      downloadCount: 0
    });

    // Return as downloadable text file (demo)
    res.setHeader('Content-Type', 'application/octet-stream');
    res.setHeader('Content-Disposition', `attachment; filename="TradeMindIQ_Report_${dateRange.startDate}_to_${dateRange.endDate}.txt"`);
    res.send(reportContent);
    
  } catch (error) {
    console.error('PDF export error:', error);
    res.status(500).json({ error: 'Failed to generate PDF export' });
  }
});

// Export to CSV
app.post('/api/reports/export/csv', authenticateToken, (req, res) => {
  try {
    const { trades, dateRange } = req.body;
    
    console.log(`📊 CSV Export requested for ${trades.length} trades`);
    
    const csvContent = generateCSVContent(trades);
    
    // Add to export history
    exportHistory.unshift({
      id: Date.now().toString(),
      userId: req.userId,
      type: 'csv',
      filename: `TradeMindIQ_Trades_${dateRange.startDate}_to_${dateRange.endDate}.csv`,
      createdAt: new Date().toISOString(),
      status: 'completed',
      downloadCount: 0
    });

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="TradeMindIQ_Trades_${dateRange.startDate}_to_${dateRange.endDate}.csv"`);
    res.send(csvContent);
    
  } catch (error) {
    console.error('CSV export error:', error);
    res.status(500).json({ error: 'Failed to generate CSV export' });
  }
});

// Get report settings
app.get('/api/reports/settings', authenticateToken, (req, res) => {
  const settings = reportSettings.get(req.userId) || {
    emailSummaries: {
      enabled: false,
      frequency: 'daily',
      time: '08:00',
      email: '',
      includeCharts: true,
      includePerformance: true,
      includeTrades: true
    },
    autoExport: {
      enabled: false,
      frequency: 'weekly',
      format: 'csv',
      email: false,
      store: true
    }
  };

  res.json(settings);
});

// Update report settings
app.put('/api/reports/settings', authenticateToken, (req, res) => {
  reportSettings.set(req.userId, req.body);
  console.log(`⚙️ Settings updated for user: ${req.userId}`);
  res.json({ message: 'Settings updated successfully' });
});

// Test summary endpoint
app.post('/api/reports/test-summary', authenticateToken, async (req, res) => {
  try {
    const { email, trades, metrics } = req.body;
    
    console.log(`📧 Test email summary for: ${email}`);
    
    // Demo email content
    const emailContent = generateEmailContent(trades, metrics);
    
    res.json({
      message: `Test email summary sent to ${email}`,
      preview: emailContent,
      status: 'sent'
    });
    
  } catch (error) {
    console.error('Email test error:', error);
    res.status(500).json({ error: 'Failed to send test summary' });
  }
});

// Get export history
app.get('/api/reports/exports', authenticateToken, (req, res) => {
  const userExports = exportHistory.filter(exp => exp.userId === req.userId);
  res.json(userExports);
});

// User Preferences Endpoints
// Get user preferences
app.get('/api/user/preferences', authenticateToken, (req, res) => {
  try {
    const preferences = userPreferences.get(req.userId) || {
      general: {
        theme: 'light',
        timezone: 'America/New_York',
        autoRefreshInterval: 30,
        defaultSymbols: ['AAPL', 'TSLA', 'MSFT'],
        currency: 'USD',
        dateFormat: 'MM/DD/YYYY'
      },
      trading: {
        defaultStrategy: 'momentum',
        riskLevel: 'moderate',
        autoSaveEnabled: true,
        confirmTrades: true
      },
      notifications: {
        emailEnabled: true,
        smsEnabled: false,
        pushEnabled: true,
        soundEnabled: true,
        quietHours: {
          enabled: false,
          startTime: '22:00',
          endTime: '08:00'
        }
      },
      display: {
        compactMode: false,
        showPercentages: true,
        hideSmallBalances: false,
        animationsEnabled: true
      }
    };
    
    console.log(`📋 Preferences fetched for user: ${req.userId}`);
    res.json(preferences);
  } catch (error) {
    console.error('Get preferences error:', error);
    res.status(500).json({ error: 'Failed to fetch preferences' });
  }
});

// Update user preferences
app.put('/api/user/preferences', authenticateToken, (req, res) => {
  try {
    const preferences = req.body;
    
    // Validate preferences structure
    if (!preferences.general || !preferences.trading || !preferences.notifications || !preferences.display) {
      return res.status(400).json({ error: 'Invalid preferences structure' });
    }
    
    // Store preferences
    userPreferences.set(req.userId, preferences);
    
    console.log(`💾 Preferences saved for user: ${req.userId}`);
    console.log(`   Theme: ${preferences.general.theme}`);
    console.log(`   Symbols: ${preferences.general.defaultSymbols.join(', ')}`);
    console.log(`   Auto-refresh: ${preferences.general.autoRefreshInterval}s`);
    
    res.json({ 
      message: 'Preferences saved successfully',
      preferences: preferences 
    });
  } catch (error) {
    console.error('Save preferences error:', error);
    res.status(500).json({ error: 'Failed to save preferences' });
  }
});

// Reset user preferences to defaults
app.delete('/api/user/preferences', authenticateToken, (req, res) => {
  try {
    userPreferences.delete(req.userId);
    
    console.log(`🔄 Preferences reset for user: ${req.userId}`);
    res.json({ message: 'Preferences reset to defaults successfully' });
  } catch (error) {
    console.error('Reset preferences error:', error);
    res.status(500).json({ error: 'Failed to reset preferences' });
  }
});

// Utility functions
const generateTextReport = (trades, metrics, dateRange) => {
  return `
TradeMindIQ Trading Report
=========================

Period: ${dateRange.startDate} to ${dateRange.endDate}
Generated: ${new Date().toLocaleString()}

PERFORMANCE SUMMARY
------------------
Total Trades: ${metrics.totalTrades}
Win Rate: ${metrics.winRate}%
Net P/L: $${metrics.netProfit}
Sharpe Ratio: ${metrics.sharpeRatio}
Best Trade: $${metrics.bestTrade}
Worst Trade: $${metrics.worstTrade}
Average Trade Size: $${metrics.avgTradeSize}
Total Commissions: $${metrics.totalCommissions}

STRATEGY BREAKDOWN
-----------------
${getStrategyBreakdown(trades)}

TRADE DETAILS
------------
${trades.map(trade => 
  `${trade.timestamp.split('T')[0]} | ${trade.symbol} ${trade.type.toUpperCase()} | Qty: ${trade.quantity} | Price: $${trade.price.toFixed(2)} | P/L: $${(trade.profit || 0).toFixed(2)} | Strategy: ${trade.strategy}`
).join('\n')}

Report generated by TradeMindIQ Export/Reporting Tools
`;
};

const generateCSVContent = (trades) => {
  const headers = 'ID,Symbol,Type,Quantity,Price,Timestamp,Strategy,Profit,Commission,Total\n';
  const rows = trades.map(trade => 
    `${trade.id},${trade.symbol},${trade.type},${trade.quantity},${trade.price.toFixed(2)},${trade.timestamp},${trade.strategy},${(trade.profit || 0).toFixed(2)},${trade.commission.toFixed(2)},${trade.total.toFixed(2)}`
  ).join('\n');
  
  return headers + rows;
};

const generateEmailContent = (trades, metrics) => {
  return {
    subject: 'TradeMindIQ - Daily Trading Summary',
    html: `
<h2>📊 Daily Trading Summary</h2>
<p>Date: ${new Date().toLocaleDateString()}</p>
<h3>Performance Metrics</h3>
<ul>
  <li>Total Trades: <strong>${metrics.totalTrades}</strong></li>
  <li>Win Rate: <strong>${metrics.winRate}%</strong></li>
  <li>Net P/L: <strong style="color: ${metrics.netProfit >= 0 ? 'green' : 'red'}">$${metrics.netProfit.toFixed(2)}</strong></li>
</ul>
<h3>Recent Trades</h3>
${trades.slice(0, 5).map(trade => 
  `<p>${trade.symbol} ${trade.type.toUpperCase()} - P/L: $${(trade.profit || 0).toFixed(2)}</p>`
).join('')}
    `
  };
};

const getStrategyBreakdown = (trades) => {
  const strategies = {};
  trades.forEach(trade => {
    if (trade.strategy) {
      if (!strategies[trade.strategy]) {
        strategies[trade.strategy] = { count: 0, profit: 0 };
      }
      strategies[trade.strategy].count++;
      strategies[trade.strategy].profit += (trade.profit || 0);
    }
  });

  return Object.entries(strategies)
    .map(([strategy, data]) => `${strategy}: ${data.count} trades, $${data.profit.toFixed(2)} P/L`)
    .join('\n');
};

// Error handling
app.use((error, req, res, next) => {
  console.error('API Error:', error);
  res.status(500).json({ error: 'Internal server error' });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'API endpoint not found' });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 TradeMindIQ Reports Backend running on port ${PORT}`);
  console.log(`📊 Demo data: ${tradeHistory.length} trades loaded`);
  console.log(`🔗 Health check: http://localhost:${PORT}/api/reports/health`);
  console.log(`⚙️ User preferences: http://localhost:${PORT}/api/user/preferences`);
  console.log(`🌐 Frontend: http://localhost:3000`);
  console.log('✅ Ready for testing!');
});

module.exports = app;
