// Express.js backend example for TradeMindIQ Export/Reporting system
// This demonstrates the server-side implementation for automated reports and exports

import express from 'express';
import cors from 'cors';
import cron from 'node-cron';
import { createEmailTemplateService, EmailTemplateService, SummaryData } from '../src/utils/emailTemplateService';
import { createPDFReportService, PDFReportService, generateSampleCharts } from '../src/utils/pdfReportService';
import { createNotificationService, getNotificationConfig } from '../src/utils/notificationService';
import { authenticateToken } from './auth.mjs';

const app = express();
const PORT = process.env.PORT || 3002;

// Initialize services
const emailTemplateService = createEmailTemplateService();
const pdfReportService = createPDFReportService();
const notificationService = createNotificationService(getNotificationConfig());

// Middleware
app.use(cors());
app.use(express.json());

// In-memory storage for demo (use database in production)
let tradeHistory = [];
let reportSettings = new Map();
let exportHistory = [];
let scheduledReports = new Map();

// Demo trade data
const generateDemoTrades = () => {
  const symbols = ['AAPL', 'MSFT', 'GOOGL', 'TSLA', 'AMZN'];
  const strategies = ['momentum', 'swing', 'scalp'];
  const trades = [];

  for (let i = 0; i < 50; i++) {
    const timestamp = new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000);
    const symbol = symbols[Math.floor(Math.random() * symbols.length)];
    const strategy = strategies[Math.floor(Math.random() * strategies.length)];
    const type = Math.random() > 0.5 ? 'buy' : 'sell';
    const quantity = Math.floor(Math.random() * 200) + 1;
    const price = Math.random() * 300 + 50;
    const commission = 1.00;
    const profit = type === 'sell' ? (Math.random() - 0.4) * 500 : undefined;

    trades.push({
      id: (i + 1).toString(),
      symbol,
      type,
      quantity,
      price,
      timestamp: timestamp.toISOString(),
      strategy,
      profit,
      commission,
      total: type === 'buy' ? quantity * price + commission : quantity * price - commission
    });
  }

  return trades;
};

// Demo performance metrics calculation
const calculateMetrics = (trades) => {
  const completedTrades = trades.filter(t => t.profit !== undefined);
  const profits = completedTrades.map(t => t.profit);
  const winningTrades = profits.filter(p => p > 0);
  
  return {
    totalTrades: completedTrades.length,
    winRate: completedTrades.length > 0 ? (winningTrades.length / completedTrades.length) * 100 : 0,
    totalProfit: profits.reduce((sum, p) => sum + p, 0),
    totalCommissions: trades.reduce((sum, t) => sum + t.commission, 0),
    netProfit: profits.reduce((sum, p) => sum + p, 0) - trades.reduce((sum, t) => sum + t.commission, 0),
    avgTradeSize: trades.length > 0 ? trades.reduce((sum, t) => sum + t.total, 0) / trades.length : 0,
    bestTrade: Math.max(...profits, 0),
    worstTrade: Math.min(...profits, 0),
    sharpeRatio: 1.25 + Math.random() * 1.5, // Simulated
    maxDrawdown: Math.min(...profits, 0) * 2 // Simulated
  };
};

// Initialize demo data
tradeHistory = generateDemoTrades();

// Get trade history and metrics
app.get('/api/trades/history', authenticateToken, (req, res) => {
  const userTrades = tradeHistory; // In production, filter by userId
  const metrics = calculateMetrics(userTrades);
  
  res.json({
    trades: userTrades,
    metrics: metrics
  });
});

// Export to PDF
app.post('/api/reports/export/pdf', authenticateToken, async (req, res) => {
  try {
    const { trades, metrics, dateRange, filters } = req.body;
    
    // Generate PDF using the PDF service
    const reportOptions = {
      title: 'TradeMindIQ Trading Report',
      period: dateRange,
      includeHeader: true,
      includeFooter: true,
      includeCharts: true,
      includeSummary: true,
      includeTradeDetails: true
    };

    const charts = generateSampleCharts(trades, metrics);
    const pdfPath = await pdfReportService.generateTradingReport(trades, metrics, reportOptions, charts);
    
    // In a real implementation, you would:
    // 1. Generate the actual PDF file
    // 2. Store it temporarily or permanently
    // 3. Return the file as a download

    // For demo, create a text-based report
    const reportContent = generateTextReport(trades, metrics, dateRange);
    
    // Add to export history
    exportHistory.unshift({
      id: Date.now().toString(),
      userId: req.userId,
      type: 'pdf',
      filename: `TradeMindIQ_Report_${dateRange.startDate}_to_${dateRange.endDate}.pdf`,
      createdAt: new Date().toISOString(),
      status: 'completed',
      downloadCount: 0
    });

    // Return the report content as a downloadable file
    res.setHeader('Content-Type', 'application/octet-stream');
    res.setHeader('Content-Disposition', `attachment; filename="TradeMindIQ_Report_${dateRange.startDate}_to_${dateRange.endDate}.txt"`);
    res.send(reportContent);
    
  } catch (error) {
    console.error('PDF export error:', error);
    res.status(500).json({ error: 'Failed to generate PDF export' });
  }
});

// Export to CSV
app.post('/api/reports/export/csv', authenticateToken, (req, res) => {
  try {
    const { trades, dateRange } = req.body;
    
    const csvContent = generateCSVContent(trades);
    
    // Add to export history
    exportHistory.unshift({
      id: Date.now().toString(),
      userId: req.userId,
      type: 'csv',
      filename: `TradeMindIQ_Trades_${dateRange.startDate}_to_${dateRange.endDate}.csv`,
      createdAt: new Date().toISOString(),
      status: 'completed',
      downloadCount: 0
    });

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="TradeMindIQ_Trades_${dateRange.startDate}_to_${dateRange.endDate}.csv"`);
    res.send(csvContent);
    
  } catch (error) {
    console.error('CSV export error:', error);
    res.status(500).json({ error: 'Failed to generate CSV export' });
  }
});

// Get/Update report settings
app.get('/api/reports/settings', authenticateToken, (req, res) => {
  const settings = reportSettings.get(req.userId) || {
    emailSummaries: {
      enabled: false,
      frequency: 'daily',
      time: '08:00',
      email: '',
      includeCharts: true,
      includePerformance: true,
      includeTrades: true
    },
    autoExport: {
      enabled: false,
      frequency: 'weekly',
      format: 'pdf',
      email: true,
      store: true
    }
  };
  
  res.json(settings);
});

app.put('/api/reports/settings', authenticateToken, (req, res) => {
  const settings = req.body;
  reportSettings.set(req.userId, settings);
  
  // Update scheduled reports
  updateScheduledReports(req.userId, settings);
  
  res.json({ success: true, settings });
});

// Send test summary
app.post('/api/reports/test-summary', authenticateToken, async (req, res) => {
  try {
    const { email, trades, metrics } = req.body;
    
    const summaryData = {
      period: 'daily',
      startDate: new Date().toISOString(),
      endDate: new Date().toISOString(),
      trades: trades.slice(0, 10),
      metrics,
      includeCharts: true,
      includePerformance: true,
      includeTrades: true
    };

    const emailContent = emailTemplateService.generateDailySummary(summaryData);
    
    // Send email using notification service
    const success = await notificationService.sendEmail(
      email,
      emailContent.subject,
      emailContent.html,
      emailContent.text
    );

    if (success) {
      res.json({ success: true, message: 'Test summary sent successfully' });
    } else {
      // For demo, always succeed
      res.json({ success: true, message: 'Demo: Test summary would be sent to ' + email });
    }
    
  } catch (error) {
    console.error('Test summary error:', error);
    res.status(500).json({ error: 'Failed to send test summary' });
  }
});

// Get export history
app.get('/api/reports/exports', authenticateToken, (req, res) => {
  const userExports = exportHistory.filter(exp => exp.userId === req.userId);
  res.json(userExports);
});

// Download export file
app.get('/api/reports/exports/:id/download', authenticateToken, (req, res) => {
  const exportItem = exportHistory.find(exp => exp.id === req.params.id && exp.userId === req.userId);
  
  if (!exportItem) {
    return res.status(404).json({ error: 'Export not found' });
  }

  // Increment download count
  exportItem.downloadCount++;
  
  // In production, serve the actual file
  res.json({ 
    message: 'Download would start',
    filename: exportItem.filename,
    downloadUrl: `/downloads/${exportItem.filename}`
  });
});

// Scheduled report functions
const updateScheduledReports = (userId, settings) => {
  // Remove existing scheduled reports for this user
  if (scheduledReports.has(userId)) {
    scheduledReports.get(userId).forEach(task => task.destroy());
    scheduledReports.delete(userId);
  }

  const userTasks = [];

  // Schedule email summaries
  if (settings.emailSummaries.enabled) {
    const [hour, minute] = settings.emailSummaries.time.split(':');
    let cronPattern;

    if (settings.emailSummaries.frequency === 'daily') {
      cronPattern = `${minute} ${hour} * * *`;
    } else if (settings.emailSummaries.frequency === 'weekly') {
      cronPattern = `${minute} ${hour} * * 1`; // Every Monday
    }

    const task = cron.schedule(cronPattern, () => {
      sendScheduledSummary(userId, settings.emailSummaries);
    }, { scheduled: false });

    userTasks.push(task);
    task.start();
  }

  // Schedule auto exports
  if (settings.autoExport.enabled) {
    let cronPattern;
    
    switch (settings.autoExport.frequency) {
      case 'daily':
        cronPattern = '0 2 * * *'; // 2 AM daily
        break;
      case 'weekly':
        cronPattern = '0 2 * * 1'; // 2 AM Monday
        break;
      case 'monthly':
        cronPattern = '0 2 1 * *'; // 2 AM first day of month
        break;
    }

    const task = cron.schedule(cronPattern, () => {
      performScheduledExport(userId, settings.autoExport);
    }, { scheduled: false });

    userTasks.push(task);
    task.start();
  }

  if (userTasks.length > 0) {
    scheduledReports.set(userId, userTasks);
  }
};

const sendScheduledSummary = async (userId, emailSettings) => {
  try {
    console.log(`Sending scheduled summary for user ${userId}`);
    
    const userTrades = tradeHistory; // In production, filter by userId
    const metrics = calculateMetrics(userTrades);
    
    const summaryData = {
      period: emailSettings.frequency,
      startDate: emailSettings.frequency === 'daily' 
        ? new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString()
        : new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
      endDate: new Date().toISOString(),
      trades: userTrades.slice(0, 15),
      metrics,
      includeCharts: emailSettings.includeCharts,
      includePerformance: emailSettings.includePerformance,
      includeTrades: emailSettings.includeTrades
    };

    const emailContent = emailSettings.frequency === 'daily'
      ? emailTemplateService.generateDailySummary(summaryData)
      : emailTemplateService.generateWeeklySummary(summaryData);
    
    await notificationService.sendEmail(
      emailSettings.email,
      emailContent.subject,
      emailContent.html,
      emailContent.text
    );

    console.log(`Summary sent successfully to ${emailSettings.email}`);
    
  } catch (error) {
    console.error('Scheduled summary error:', error);
  }
};

const performScheduledExport = async (userId, exportSettings) => {
  try {
    console.log(`Performing scheduled export for user ${userId}`);
    
    const userTrades = tradeHistory; // In production, filter by userId
    const metrics = calculateMetrics(userTrades);
    
    const dateRange = {
      startDate: exportSettings.frequency === 'daily' 
        ? new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString().split('T')[0]
        : exportSettings.frequency === 'weekly'
        ? new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
        : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      endDate: new Date().toISOString().split('T')[0]
    };

    const exportPaths = [];

    // Generate exports based on format settings
    if (exportSettings.format === 'pdf' || exportSettings.format === 'both') {
      const reportOptions = {
        title: `Automated ${exportSettings.frequency} Report`,
        period: dateRange,
        includeHeader: true,
        includeFooter: true,
        includeCharts: true,
        includeSummary: true,
        includeTradeDetails: true
      };

      const charts = generateSampleCharts(userTrades, metrics);
      const pdfPath = await pdfReportService.generateTradingReport(userTrades, metrics, reportOptions, charts);
      exportPaths.push(pdfPath);
    }

    if (exportSettings.format === 'csv' || exportSettings.format === 'both') {
      // Generate CSV
      exportPaths.push(`trades_${dateRange.startDate}_to_${dateRange.endDate}.csv`);
    }

    // Store exports if enabled
    if (exportSettings.store) {
      exportPaths.forEach(path => {
        exportHistory.unshift({
          id: Date.now().toString() + Math.random().toString(),
          userId,
          type: path.includes('.pdf') ? 'pdf' : 'csv',
          filename: path,
          createdAt: new Date().toISOString(),
          status: 'completed',
          downloadCount: 0,
          automated: true
        });
      });
    }

    // Email exports if enabled
    if (exportSettings.email) {
      const userSettings = reportSettings.get(userId);
      if (userSettings?.emailSummaries?.email) {
        const emailContent = notificationService.generateExportNotification(
          exportSettings.format,
          `${exportSettings.frequency} (${dateRange.startDate} to ${dateRange.endDate})`,
          exportPaths
        );

        await notificationService.sendEmail(
          userSettings.emailSummaries.email,
          emailContent.subject,
          emailContent.html,
          emailContent.text
        );
      }
    }

    console.log(`Automated export completed for user ${userId}`);
    
  } catch (error) {
    console.error('Scheduled export error:', error);
  }
};

// Utility functions
const generateTextReport = (trades, metrics, dateRange) => {
  return `
TradeMindIQ Trading Report
=========================

Period: ${dateRange.startDate} to ${dateRange.endDate}
Generated: ${new Date().toLocaleString()}

PERFORMANCE SUMMARY
------------------
Total Trades: ${metrics.totalTrades}
Win Rate: ${metrics.winRate.toFixed(1)}%
Net P&L: $${metrics.netProfit.toFixed(2)}
Sharpe Ratio: ${metrics.sharpeRatio.toFixed(2)}

RECENT TRADES
-------------
${trades.slice(0, 10).map(trade => 
  `${new Date(trade.timestamp).toLocaleDateString()} | ${trade.symbol} | ${trade.type.toUpperCase()} ${trade.quantity} @ $${trade.price.toFixed(2)} | P/L: $${(trade.profit || 0).toFixed(2)}`
).join('\n')}

This is a demo report generated by TradeMindIQ.
  `;
};

const generateCSVContent = (trades) => {
  const headers = ['Date', 'Symbol', 'Type', 'Quantity', 'Price', 'Total', 'Commission', 'Profit/Loss', 'Strategy'];
  const rows = trades.map(trade => [
    new Date(trade.timestamp).toLocaleDateString(),
    trade.symbol,
    trade.type.toUpperCase(),
    trade.quantity,
    trade.price.toFixed(2),
    trade.total.toFixed(2),
    trade.commission.toFixed(2),
    (trade.profit || 0).toFixed(2),
    trade.strategy || ''
  ]);
  
  return [headers, ...rows].map(row => row.join(',')).join('\n');
};

// Health check
app.get('/api/reports/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    scheduledReports: scheduledReports.size,
    exportHistory: exportHistory.length,
    services: {
      emailTemplate: 'active',
      pdfGeneration: 'active',
      notifications: 'active'
    }
  });
});

// Error handling
app.use((error, req, res, next) => {
  console.error('Reports API Error:', error);
  res.status(500).json({ error: 'Internal server error' });
});

// Start server
app.listen(PORT, () => {
  console.log(`TradeMindIQ Reports Backend running on port ${PORT}`);
  console.log(`Health check: http://localhost:${PORT}/api/reports/health`);
  console.log('Scheduled reporting system initialized');
});

export default app;
