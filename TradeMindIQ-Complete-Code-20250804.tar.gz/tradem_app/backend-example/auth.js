// JWT Authentication middleware for TradeMindIQ Backend
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

// JWT Secret - In production, use environment variable
const JWT_SECRET = process.env.JWT_SECRET || 'tradmindiq-super-secret-key-2025';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '24h';

// In-memory user store for demo (in production, use database)
const users = new Map();

// Demo users for testing
const initDemoUsers = async () => {
  const demoUsers = [
    { 
      id: 'demo-user', 
      email: 'demo@tradmindiq.com', 
      password: 'demo123',
      name: 'Demo User',
      username: 'demo', // Add username alias
      role: 'trader',
      createdAt: new Date().toISOString()
    },
    { 
      id: 'admin-user', 
      email: 'admin@tradmindiq.com', 
      password: 'admin123',
      name: 'Admin User',
      username: 'admin', // Add username alias
      role: 'admin',
      createdAt: new Date().toISOString()
    }
  ];

  for (const user of demoUsers) {
    const hashedPassword = await bcrypt.hash(user.password, 10);
    users.set(user.email, {
      ...user,
      password: hashedPassword
    });
    // Also store by username for easy lookup
    users.set(user.username, {
      ...user,
      password: hashedPassword
    });
  }

  console.log('🔐 Demo users initialized for testing');
};

// Generate JWT token
const generateToken = (user) => {
  const payload = {
    id: user.id,
    email: user.email,
    role: user.role,
    name: user.name
  };

  return jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
};

// Verify JWT token
const verifyToken = (token) => {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      throw new Error('Token expired');
    } else if (error.name === 'JsonWebTokenError') {
      throw new Error('Invalid token');
    } else {
      throw new Error('Token verification failed');
    }
  }
};

// Authentication middleware
const authenticateToken = (req, res, next) => {
  // Check for token in Authorization header
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

  // Fallback to demo mode for development
  if (!token) {
    // Demo mode - create temporary demo user
    req.user = {
      id: 'demo-user',
      email: 'demo@tradmindiq.com',
      role: 'trader',
      name: 'Demo User',
      isDemoMode: true
    };
    req.userId = req.user.id; // Backward compatibility
    return next();
  }

  try {
    const decoded = verifyToken(token);
    req.user = decoded;
    req.userId = decoded.id; // Backward compatibility
    next();
  } catch (error) {
    return res.status(401).json({ 
      error: 'Access denied', 
      message: error.message,
      code: 'INVALID_TOKEN'
    });
  }
};

// Admin-only middleware
const requireAdmin = (req, res, next) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ 
      error: 'Access denied', 
      message: 'Admin privileges required',
      code: 'INSUFFICIENT_PRIVILEGES'
    });
  }
  next();
};

// Rate limiting for authentication (simple in-memory implementation)
const authAttempts = new Map();
const MAX_ATTEMPTS = 10; // Increased for testing
const LOCKOUT_TIME = 5 * 60 * 1000; // 5 minutes (reduced for testing)

const checkAuthRateLimit = (req, res, next) => {
  const clientIP = req.ip || req.connection.remoteAddress || 'unknown';
  const now = Date.now();
  
  const attempts = authAttempts.get(clientIP) || { count: 0, lastAttempt: 0 };
  
  // Reset if lockout period has passed
  if (now - attempts.lastAttempt > LOCKOUT_TIME) {
    attempts.count = 0;
  }
  
  if (attempts.count >= MAX_ATTEMPTS) {
    const timeLeft = Math.ceil((LOCKOUT_TIME - (now - attempts.lastAttempt)) / 60000);
    return res.status(429).json({
      error: 'Too many authentication attempts',
      message: `Rate limit exceeded. Try again in ${timeLeft} minutes`,
      code: 'RATE_LIMIT_EXCEEDED'
    });
  }
  
  // Increment attempt count
  attempts.count += 1;
  attempts.lastAttempt = now;
  authAttempts.set(clientIP, attempts);
  
  next();
};

// User registration
const registerUser = async (userData) => {
  const { email, password, name, role = 'trader' } = userData;

  // Validate input
  if (!email || !password || !name) {
    throw new Error('Email, password, and name are required');
  }

  if (password.length < 6) {
    throw new Error('Password must be at least 6 characters long');
  }

  if (users.has(email)) {
    throw new Error('User already exists with this email');
  }

  // Hash password
  const hashedPassword = await bcrypt.hash(password, 10);

  // Create user
  const user = {
    id: `user-${Date.now()}`,
    email,
    password: hashedPassword,
    name,
    role,
    createdAt: new Date().toISOString(),
    lastLogin: null
  };

  users.set(email, user);

  // Return user without password
  const { password: _, ...userWithoutPassword } = user;
  return userWithoutPassword;
};

// User login
const loginUser = async (email, password) => {
  const user = users.get(email);
  
  if (!user) {
    throw new Error('Invalid credentials');
  }

  const isPasswordValid = await bcrypt.compare(password, user.password);
  
  if (!isPasswordValid) {
    throw new Error('Invalid credentials');
  }

  // Update last login
  user.lastLogin = new Date().toISOString();

  // Generate token
  const token = generateToken(user);

  // Return user without password and token
  const { password: _, ...userWithoutPassword } = user;
  return {
    user: userWithoutPassword,
    token,
    expiresIn: JWT_EXPIRES_IN
  };
};

// Get user profile
const getUserProfile = (userId) => {
  const user = Array.from(users.values()).find(u => u.id === userId);
  if (!user) {
    throw new Error('User not found');
  }

  const { password: _, ...userWithoutPassword } = user;
  return userWithoutPassword;
};

// Update user profile
const updateUserProfile = async (userId, updates) => {
  const user = Array.from(users.values()).find(u => u.id === userId);
  if (!user) {
    throw new Error('User not found');
  }

  // Validate updates
  const allowedUpdates = ['name', 'email'];
  const updateKeys = Object.keys(updates);
  const isValidUpdate = updateKeys.every(key => allowedUpdates.includes(key));

  if (!isValidUpdate) {
    throw new Error('Invalid update fields');
  }

  // Check if email is already taken (if updating email)
  if (updates.email && updates.email !== user.email) {
    if (users.has(updates.email)) {
      throw new Error('Email already in use');
    }
  }

  // Update user
  Object.assign(user, updates);
  user.updatedAt = new Date().toISOString();

  // Update map key if email changed
  if (updates.email && updates.email !== user.email) {
    users.delete(user.email);
    users.set(updates.email, user);
  }

  const { password: _, ...userWithoutPassword } = user;
  return userWithoutPassword;
};

// Change password
const changePassword = async (userId, currentPassword, newPassword) => {
  const user = Array.from(users.values()).find(u => u.id === userId);
  if (!user) {
    throw new Error('User not found');
  }

  const isCurrentPasswordValid = await bcrypt.compare(currentPassword, user.password);
  if (!isCurrentPasswordValid) {
    throw new Error('Current password is incorrect');
  }

  if (newPassword.length < 6) {
    throw new Error('New password must be at least 6 characters long');
  }

  const hashedNewPassword = await bcrypt.hash(newPassword, 10);
  user.password = hashedNewPassword;
  user.updatedAt = new Date().toISOString();

  return { message: 'Password changed successfully' };
};

// Express route handlers
const registerHandler = async (req, res) => {
  try {
    const { username, email, password, name } = req.body;
    
    if (!username || !email || !password) {
      return res.status(400).json({ message: 'Username, email, and password are required' });
    }

    // Use email as primary key, but allow username for login
    const userData = { email, password, name: name || username };
    const result = await registerUser(userData);
    const token = generateToken(result);

    res.status(201).json({
      message: 'User registered successfully',
      user: result,
      token,
      expiresIn: JWT_EXPIRES_IN
    });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

const loginHandler = async (req, res) => {
  try {
    const { username, password } = req.body;
    
    if (!username || !password) {
      return res.status(400).json({ message: 'Username and password are required' });
    }

    // Try to find user by username or email
    let userEmail = username;
    
    // First, check if it's a direct lookup (email or username)
    if (!users.has(username)) {
      // If not found directly, it might be an email
      if (username.includes('@')) {
        userEmail = username;
      } else {
        // Try to find by username alias
        const userByUsername = Array.from(users.values()).find(u => 
          u.username === username || 
          u.name?.toLowerCase() === username.toLowerCase() ||
          u.email.split('@')[0] === username
        );
        if (userByUsername) {
          userEmail = userByUsername.email;
        }
      }
    } else {
      // Direct username lookup found
      const userData = users.get(username);
      if (userData && userData.email) {
        userEmail = userData.email;
      }
    }

    const result = await loginUser(userEmail, password);
    res.json({
      message: 'Login successful',
      ...result
    });
  } catch (error) {
    res.status(401).json({ message: error.message });
  }
};

const profileHandler = async (req, res) => {
  try {
    const profile = await getUserProfile(req.user.id);
    res.json(profile);
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

const updateProfileHandler = async (req, res) => {
  try {
    const result = await updateUserProfile(req.user.id, req.body);
    res.json(result);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

const changePasswordHandler = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    
    if (!currentPassword || !newPassword) {
      return res.status(400).json({ message: 'Current password and new password are required' });
    }

    const result = await changePassword(req.user.id, currentPassword, newPassword);
    res.json(result);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

module.exports = {
  initDemoUsers,
  generateToken,
  verifyToken,
  authenticateToken,
  requireAdmin,
  checkAuthRateLimit,
  registerUser: registerHandler,
  loginUser: loginHandler,
  getUserProfile: profileHandler,
  updateUserProfile: updateProfileHandler,
  changePassword: changePasswordHandler,
  JWT_SECRET,
  JWT_EXPIRES_IN
};
